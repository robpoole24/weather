// WeatherTV Server — updated 2026-10-09T04:30:00Z build.1791730000
const express = require('express');
const compression = require('compression');
const { applySecurityMiddleware, applyErrorHandler } = require('./security-middleware');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const radar = require('./radar');
const http = require('http');
const { WebSocketServer, WebSocket } = require('ws');
const { createLiveVerifier } = require('./live-verifier');

// Load .env file if present
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  fs.readFileSync(envPath, 'utf8').split('\n').forEach(line => {
    const [key, ...val] = line.split('=');
    if (key && !key.startsWith('#') && val.length) {
      process.env[key.trim()] = val.join('=').trim();
    }
  });
}

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'channels.json');

// gzip/deflate every compressible response (HTML, JS, CSS, JSON, KML, m3u8).
// Railway bills bytes sent to Cloudflare, and Cloudflare only compresses what
// it sends onward to visitors — so without this, every cache miss left
// Railway uncompressed. Images and video segments are skipped automatically
// (already compressed). Registered first so it covers every route.
app.use(compression());

applySecurityMiddleware(app);
app.use(express.json({ limit: '5mb' })); // 5MB covers the full appData payload sent by saveAll()

// ── WS4KP dynamic music playlist ──────────────────────────────────────────
// Scans the actual music folder so any MP3 pushed to GitHub is auto-included.
// Must be before express.static so it takes precedence over any static file.
app.get('/weatherstar/playlist.json', (req, res) => {
  const fs = require('fs');
  const musicRoot = path.join(__dirname, 'public', 'weatherstar', 'music');
  const files = [];
  // 🎃 Haddonfield easter egg: music/haddonfield/ plays ONLY for Haddonfield
  // (the normal list below never reads that folder, so no other city hears it)
  if (req.query.town === 'haddonfield') {
    try {
      fs.readdirSync(path.join(musicRoot, 'haddonfield')).filter(f => /\.mp3$/i.test(f)).forEach(f => files.push(`haddonfield/${f}`));
    } catch (_) {}
    if (files.length) return res.json({ availableFiles: files });
  }
  // Root music/ folder
  try {
    fs.readdirSync(musicRoot)
      .filter(f => /\.mp3$/i.test(f))
      .forEach(f => files.push(f));
  } catch (_) {}
  // music/default/ subfolder (WS4KP's built-in location)
  try {
    fs.readdirSync(path.join(musicRoot, 'default'))
      .filter(f => /\.mp3$/i.test(f))
      .forEach(f => files.push(`default/${f}`));
  } catch (_) {}
  res.json({ availableFiles: files });
});

// ── Admin Authentication ──
// HTTP Basic Auth gates the entire admin panel and all /api/admin/* routes.
// Without this, ANYONE who finds /admin can read the YouTube API key (via
// GET /api/admin/config, which returns the full data store including
// config.apiKey), overwrite the entire channel database (POST /api/admin/restore
// accepts arbitrary JSON with no validation beyond shape), mark channels
// live/offline, burn API quota on demand, etc.
//
// Set ADMIN_USER and ADMIN_PASSWORD as Railway environment variables to enable.
// If ADMIN_PASSWORD is not set, admin routes remain OPEN (fail-open) so local
// dev isn't broken by default -- but a loud warning is logged on every request
// so this can't go unnoticed in production logs.
function adminAuth(req, res, next) {
  const expectedUser = process.env.ADMIN_USER || 'admin';
  const expectedPass = process.env.ADMIN_PASSWORD;

  if (!expectedPass) {
    console.warn('[WeatherTV] WARNING: ADMIN_PASSWORD not set -- admin panel is UNPROTECTED. Set ADMIN_USER and ADMIN_PASSWORD env vars to secure it.');
    return next();
  }

  const authHeader = req.headers.authorization || '';
  const [scheme, encoded] = authHeader.split(' ');

  if (scheme === 'Basic' && encoded) {
    try {
      const decoded = Buffer.from(encoded, 'base64').toString('utf8');
      const sepIdx = decoded.indexOf(':');
      const user = decoded.slice(0, sepIdx);
      const pass = decoded.slice(sepIdx + 1);

      // Timing-safe comparison -- pad to equal length first since
      // timingSafeEqual throws on mismatched buffer lengths.
      const userBuf = Buffer.from(user);
      const expectedUserBuf = Buffer.from(expectedUser);
      const passBuf = Buffer.from(pass);
      const expectedPassBuf = Buffer.from(expectedPass);

      const userMatch = userBuf.length === expectedUserBuf.length && crypto.timingSafeEqual(userBuf, expectedUserBuf);
      const passMatch = passBuf.length === expectedPassBuf.length && crypto.timingSafeEqual(passBuf, expectedPassBuf);

      if (userMatch && passMatch) return next();
    } catch (e) { /* fall through to 401 */ }
  }

  res.set('WWW-Authenticate', 'Basic realm="WeatherTV Admin"');
  return res.status(401).send('Authentication required');
}

// /admin and /api/admin must be registered BEFORE the general public static
// middleware below. express.static() serves a matching file and never calls
// next() -- if public/admin/ exists for any reason (e.g. leftover from an
// earlier project layout), the general static handler would serve it directly
// and adminAuth would never run, regardless of whether ADMIN_PASSWORD is set.
app.use('/admin', adminAuth, express.static(path.join(__dirname, 'admin')));
app.use('/api/admin', adminAuth);
app.use(express.static(path.join(__dirname, 'public')));

// ── Load / Save data ──
// In-memory data store — loaded from Redis or file on startup
let appDataStore = null;

function loadData() {
  if (appDataStore) return appDataStore;
  // Fall back to file if Redis hasn't loaded yet
  if (fs.existsSync(DATA_FILE)) {
    try {
      appDataStore = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
      return appDataStore;
    } catch(e) {}
  }
  appDataStore = getDefaultData();
  return appDataStore;
}

function saveData(data) {
  // Update in-memory store
  appDataStore = data;

  // Write to Redis (primary persistent store)
  rSet('wt:appData', data);

  // Also write to file as backup
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch(e) {
    console.warn('[WeatherTV] Could not write channels.json:', e.message);
  }
}

// Load app data from Redis into memory on startup
async function restoreAppDataFromRedis() {
  if (!redis) return;
  try {
    const stored = await rGet('wt:appData');
    if (stored && stored.groups && stored.groups.length > 0) {
      // Validate structure — must have proper groups with channels arrays
      const valid = stored.groups.every(g => g.id && g.label && Array.isArray(g.channels));
      if (!valid) {
        console.error('[Redis] Stored data has invalid structure — using defaults');
        return;
      }

      // Use Redis data directly — it was saved by admin and is authoritative
      // New channels added via code will appear after admin does Save All Changes
      appDataStore = stored;
      const chCount = stored.groups.reduce((s, g) => s + (g.channels||[]).length, 0);
      console.log('[Redis] App data restored — ' + stored.groups.length + ' groups, ' + chCount + ' channels');
    } else {
      console.log('[Redis] No app data in Redis — using defaults');
    }
  } catch(e) {
    console.error('[Redis] App data restore error:', e.message);
  }
}

function getDefaultData() {
  return {
    config: {
      playlistId: 'PLNDLR7JhLYhOdX-lSyjsgUSkwcd55UuiI',
      apiKey: process.env.YOUTUBE_API_KEY || '',
      liveCheckIntervalHours: 2,    // 2 hours between live polls — set to 0.25 after quota increase to 50k
      recentFetchHourEST: 12,       // hour (0-23) in EST for first daily fetch -- noon, after most forecasters post their daily forecast
      recentFetchHour2EST: 18,      // hour (0-23) in EST for second daily fetch -- 6pm, catches afternoon/evening storm content
    },
    groups: [
      {
        id: 'forecasters',
        label: 'Weather Forecasters',
        icon: '⛅',
        channels: [
              { id: 'max-chasers', label: 'Exclusive Chasers', enabled: false }
            ]
          },
              { id: 'ryan-chasers', label: 'Exclusive Chasers', enabled: false }
            ]
          },
          { id: 'UCuYqi3hOfz6-3Hdp6tEJjAg', name: 'AccuWeather',         hasLive: true,  enabled: true },
          { id: 'UCp2G_jHO53yj2NVjv8zbDmQ', name: 'Evan Fryberger',    hasLive: true,  enabled: true },
          { id: 'UCvBVK2ymNzPLRJrgip2GeQQ', name: 'Max Velocity',      hasLive: true,  enabled: true,
            collections: [
          { id: 'UCJHAT3Uvv-g3I8H3GhHWV7w', name: "Ryan Hall Y'all",   hasLive: true,  enabled: true,
            collections: [
          { id: 'UCBtR7ynKM9odz-PW_7uyzDw', name: 'Severe Studios',    hasLive: true,  enabled: true },
        ]
      },
      {
        id: 'chasers',
        label: 'Storm Chasers',
        icon: '🌪',
        channels: [
          { id: 'UC8QZ-OIqfWKek1CpMvs2O3g', name: 'Aaron Jayjack',          hasLive: true,  enabled: true },
          { id: 'UCf8dNCufHlKZp-CgU8NPryw', name: 'Adam Lucio',             hasLive: true,  enabled: true },
          { id: 'UCXQYQMwU9wc584i7ecZzm_A', name: 'Adri Mozeris',           hasLive: false, enabled: true },
          { id: 'UCW-db9uRShMINgICqQeyt1Q', name: 'Alexander Spahn',        hasLive: false, enabled: true },
          { id: 'UCT1IIkU3Yafr6nfNxQlWuSQ', name: 'Andrew Pritchard',       hasLive: true,  enabled: true },
          { id: 'UCXZJRhrMbtXqjZCZUGp5CTg', name: 'Bamawxcom',              hasLive: false, enabled: true },
          { id: 'UCj6aoh3tZuQoqfHs4ZWpHcA', name: 'Brad Arnold',            hasLive: true,  enabled: true },
          { id: 'UCD3KREyo3IqCLBC-4khGgIw', name: 'Brandon Clement',        hasLive: true,  enabled: true },
          { id: 'UCniY5-9rLWSE6c3iA4fh73w', name: 'Brandon Copic Archive',  hasLive: false, enabled: true },
          { id: 'UCPqLI_AohMn1jnFg8ocMyHA', name: 'Brandon Copic Live',     hasLive: true,  enabled: true },
          { id: 'UC0xEzjGJ6waQPoHwAdhYD7Q', name: 'Brandon Ivey', hasLive: true, enabled: true },
          { id: 'UCMmlV4B6Bx2GuYtIaxpLcfw', name: 'Brittney Richardson',    hasLive: true,  enabled: true },
          { id: 'UCLfN3U2O0sEYabjo2lxIttw', name: 'Celton Henderson',       hasLive: false, enabled: true },
          { id: 'UCvIqVAaqpx1Q_e9DzIxgk1A', name: 'CF Productions',         hasLive: true,  enabled: true },
          { id: 'UCGpPbdVAtTUgW_w98lXC9nw', name: 'Chris Riske',            hasLive: true,  enabled: true },
          { id: 'UCx_mcHxMvZ8PBmVTtg6Ddtw', name: 'CJ Ziegler',             hasLive: true,  enabled: true },
          { id: 'UCb0U1g5r4kH_NDMGiGRhysA', name: 'Connor Croff',           hasLive: true,  enabled: true },
          { id: 'UCRYYy0UrfyGmMKQDU1N1R3g', name: 'Convective Chronicles',  hasLive: true,  enabled: true },
          { id: 'UCx5ex9rJumpj-oKgVJrP4hA', name: 'Corey Gerken',           hasLive: true,  enabled: true },
          { id: 'UC1dcRoXHbZ0QFOBB6DKPmdg', name: 'Dan Robinson',            hasLive: false, enabled: true },
          { id: 'UCemyFpFfu55JvAP_eWW1NdA', name: 'Daniel Shaw',            hasLive: true,  enabled: true },
          { id: 'UCixgOrfusZuPt_FVO1sIXAw', name: 'Dilly Dilly Dalton',      hasLive: true,  enabled: true },
          { id: 'UChZ_VT3MrHB53bSqFiVf4eg', name: "Edgar O'Neal",           hasLive: true,  enabled: true },
          { id: 'UCZSDkxJS7PRw9V0_Sm6U7jg', name: 'Freddy McKinney',        hasLive: true,  enabled: true },
          { id: 'UC6lUxl1KxmI7TWnAA6go1EQ', name: 'Jaden Pappenheim',       hasLive: true,  enabled: true },
          { id: 'UCPgskHnT1cT_hpfbq9nUK7w', name: 'Jakob McMillin',         hasLive: true,  enabled: true },
          { id: 'UCgHiLhzivmLjWTnYerF8E9A', name: 'James Hammett', hasLive: false, enabled: true },
          { id: 'UCWMRFAo3Cvd7W8yQpQwsOQA', name: 'John McKinney',          hasLive: true,  enabled: true },
          { id: 'UCSoEfOMuGNjrrhD4iLTKo_A', name: 'Jonas Piontek',          hasLive: false, enabled: true },
          { id: 'UC86mOt7YnKgRUQxblDpsN-g', name: 'Jordan Hall',            hasLive: true,  enabled: true },
          { id: 'UCvRBXkjHG0vbDrO-03ZIWxw', name: 'Justin Noonan',          hasLive: false, enabled: true },
          { id: 'UClIZx2ESMJVocfMIbji_ujg', name: 'Justin Poublon',         hasLive: true,  enabled: true },
          { id: 'UCPtizAsfQaJktz0tw9YuKLQ', name: 'Kannon Kalton',          hasLive: true,  enabled: true },
          { id: 'UC1nJElGcVcTpeZJVyxEbzJw', name: 'Live Storms Media',      hasLive: true,  enabled: true },
          { id: 'UC9Y_sKyerjEGdywnoB0XrXg', name: 'Mark Peyton', hasLive: true, enabled: true },
          { id: 'UCeE90n3GWO1XZcwt8xpNRtw', name: 'Melanie Metz',           hasLive: true,  enabled: true },
          { id: 'UCXUU-_dJ-eGBh3-bjPNsalQ', name: 'Nathan Moore',            hasLive: true,  enabled: true },
          { id: 'UC-uBgtNjd3V0ngd7-IZbphQ', name: 'Nick Stewart', hasLive: true, enabled: true },
          { id: 'UCy5cFthFcECu6DMSBcOX5AQ', name: 'Oklahoma Weather Couple', hasLive: false, enabled: true },
          { id: 'UCV6hWxB0-u_IX7e-h4fEBAw', name: 'Reed Timmer',            hasLive: true,  enabled: true },
          { id: 'UChxsy558HhpaqnB1Hk6tHkw', name: 'Reilly Dibble',          hasLive: true,  enabled: true },
          { id: 'UCY4Vj4lQZ-TSrz66RDi-DJA', name: 'Ryan Miller',             hasLive: true,  enabled: true },
          { id: 'UCSQH3qItz0gZ5oXw8cSNR2w', name: 'Ryan Scholl',            hasLive: true,  enabled: true },
          { id: 'UCIQ1bii18GuNOICBA86HUMQ', name: 'Sawyer Spiral',           hasLive: false, enabled: true },
          { id: 'UCqsI0A7OlQTnwPFOUZaISMA', name: 'Scott Currens',          hasLive: false, enabled: true },
          { id: 'UCqAWcfd0BJBgCW8iyOLOF3g', name: 'Scott Peake',            hasLive: true,  enabled: true },
          { id: 'UCkB7RBehEqHvsD60C1yfAAg', name: 'Skip Talbot', hasLive: false, enabled: true },
          { id: 'UCddpbBha4DGhxy5KI9smjow', name: 'Storm Chase HQ',        hasLive: true,  enabled: true },
          { id: 'UCdSMdTFOfqmOXP-1vD2cxAA', name: 'Storm Chase TV',         hasLive: true,  enabled: true },
          { id: 'UCrqV52vTW5wksR-8vCZgAyA', name: 'Storm Chaser Dana',     hasLive: true,  enabled: true },
          { id: 'UCWAN-rRJFLosqgiiIFVpkEQ', name: 'Storm Chasing Video',    hasLive: true,  enabled: true },
          { id: 'UCapcjkwRd5jNJ6vbE7NWIkw', name: 'Storm Hunters',           hasLive: true,  enabled: true },
          { id: 'UCGS82m2ORvg1nfeAJsFqWDg', name: 'Storm of Passion', hasLive: true, enabled: true },
          { id: 'UCAnSuGYTjwbGoBMgF_aBpnQ', name: 'Stormgasm',              hasLive: true,  enabled: true },
          { id: 'UCBmOfiL9LC3dT4Ps2veVCoQ', name: 'Stormrunner Media',      hasLive: true,  enabled: true },
          { id: 'UCAdsKTAapDXhosiq7B237SA', name: 'Tanner Charles',           hasLive: true,  enabled: true },
          { id: 'UCaS1PyCKSyoDlel7iVOI2Vw', name: 'Tornado Crew Storm Chasers', hasLive: true, enabled: true },
          { id: 'UCCzfjxXs0o9h1cOgnnmc2Zw', name: 'Tornado Paigeyy',        hasLive: true,  enabled: true },
          { id: 'UCuer9Sw2UAD5LWZpVXbgKTA', name: 'Tornado TRX',            hasLive: false, enabled: true },
          { id: 'UCTWhf2uDTdr3pVNKUCdgnDQ', name: 'Twister Chasers', hasLive: true, enabled: true },
          { id: 'UC-4XLQqaY8y7K2aNGbOAJfQ', name: 'White Weather', hasLive: false, enabled: true },
          { id: 'UCuDoeT6EEdOTtuZh0s_gcpQ', name: 'DL Scales', hasLive: true, enabled: true },
          { id: 'UCMARQE2OVE9a6kzOMhKuPVw', name: 'Moderate Motley', hasLive: true, enabled: true },
          { id: 'UCqSk-ojoH2rgAuYadPLJgJA', name: 'Vince Waelti', hasLive: true, enabled: true },
          { id: 'UCG6jXdmfKUqR_OiPsRLDAnw', name: 'The UK Storm Chaser', hasLive: true, enabled: true },
        ]
      },
      {
        id: 'creators',
        label: 'Other Weather Creators',
        icon: '🎬',
        channels: [
          { id: 'UCBJXCq0V3EdcbQWwZ7HO7tQ', name: 'Alexander Androshchuk', hasLive: false, enabled: true },
          { id: 'UCuFxM1HTY6SONb_FICAl6gQ', name: 'Carly Anna WX',          hasLive: false, enabled: true },
          { id: 'UCGEZlX4V82wv7_Z2LsXtjPA', name: 'June First',             hasLive: true,  enabled: true },
          { id: 'UCy4Zv53jpdE_FfNh3bmtKiA', name: 'Michigan Storm Chasers', hasLive: true, enabled: true },
          { id: 'UCpYQmszu4IP37xyt3RQb2gw', name: 'More Max Velocity',      hasLive: true,  enabled: true },
          { id: 'UCTRPdC_jSFKsBVOUFQ52jGg', name: 'Out of the Whirlwind',   hasLive: false, enabled: true },
          { id: 'UCo-3ThNQmPmQSQL9WPjMaUQ', name: 'Pecos Hank',             hasLive: false, enabled: true },
          { id: 'UClEH97oWJjrm1PX6ZCEcafQ', name: 'Sky Whisper', hasLive: false, enabled: true },
          { id: 'UCCP12NYSDa9KL26PW1zokcA', name: 'Storm Channel Coaching', hasLive: false, enabled: true },
          { id: 'UCz2BWcrW-njx_py1FR0447A', name: 'Storm Reel',             hasLive: false, enabled: true },
          { id: 'UCZTme3vf6kXmXfSsIr06lvQ', name: 'Swegle Studios',         hasLive: false, enabled: true },
          { id: 'UCVdfIdcYEQfUJ9bpmGMaK4Q', name: 'The Old Callisto', hasLive: false, enabled: true },
          { id: 'UCbxfONPDpv4r3IXwppgcTdA', name: 'The Twister Archives',   hasLive: false, enabled: true },
          { id: 'UCGTUbwceCMibvpbd2NaIP7A', name: 'The Weather Channel', hasLive: false, enabled: true },
          { id: 'UC0CPqIPMHCELm208KiwBwdw', name: 'Tornado Forensics',      hasLive: false, enabled: true },
          { id: 'UC9c4E_DWmPMel1MelOBTznw', name: 'Tornado Video Library',  hasLive: false, enabled: true },
          { id: 'UCgGTo_tNrWxArxh3c3aI6bw', name: 'Tornado Warned',         hasLive: false, enabled: true },
          { id: 'UCZOxO3O5KWC4FvSL3d-U_8w', name: 'Weather Beat', hasLive: false, enabled: true },
          { id: 'UCCtYdNBm-8C_wZk0n6u8VnQ', name: 'Weatherbox Studios',     hasLive: false, enabled: true },
          { id: 'UCHf2fy0H-GJNrdVO3KxDV5Q', name: 'WorldStorm',             hasLive: false, enabled: true },
        ]
      }
    ],
    apps: [
      { name: 'WeatherFront',        img: 'images/weatherfront.webp',    ios: 'https://apps.apple.com/us/app/weatherfront-radar-models/id6739154126',            iosSoon: false, android: null,                                                                          androidSoon: true,  enabled: true },
      { name: 'Weather Wise',        img: 'images/weather-wise.webp',    ios: 'https://apps.apple.com/us/app/weatherwise-app/id6736407724',                     iosSoon: false, android: 'https://play.google.com/store/apps/details?id=com.interactiveweather.weatherwise', androidSoon: false, enabled: true },
      { name: 'Radar Omega',         img: 'images/radar-omega.webp',     ios: 'https://apps.apple.com/us/app/radaromega-doppler-radar-app/id1439881811',         iosSoon: false, android: 'https://play.google.com/store/apps/details?id=com.radarx.stormmapping.stormmapping', androidSoon: false, enabled: true },
      { name: 'Windy',               img: 'images/windy.webp',           ios: 'https://apps.apple.com/app/windy-wind-weather-forecast/id1161387262',             iosSoon: false, android: 'https://play.google.com/store/apps/details?id=com.windyty.android',          androidSoon: false, enabled: true },
      { name: 'The Weather Channel', img: 'images/weather-channel.webp', ios: 'https://apps.apple.com/app/the-weather-channel/id295646461',                     iosSoon: false, android: 'https://play.google.com/store/apps/details?id=com.weather.Weather',          androidSoon: false, enabled: true },
      { name: 'AccuWeather',         img: 'images/accuweather.webp',     ios: 'https://apps.apple.com/app/accuweather/id300048137',                              iosSoon: false, android: 'https://play.google.com/store/apps/details?id=com.accuweather.android',      androidSoon: false, enabled: true, collectionRef: 'UCuYqi3hOfz6-3Hdp6tEJjAg::col-1780335893616' },
    ],
    highlights: [],
    chaserMap: {},
    // Accumulating registry of every Spotter Network chaser we've ever seen
    // in a poll, keyed by their Spotter Network ID. The live feed only
    // shows who's currently broadcasting a position, so this persists names
    // across polls — without it, suggestions/matching would be at the mercy
    // of whoever happens to be active in any given 2-minute window.
    // Shape: { [spotterNetworkId]: { name, firstSeenAt, lastSeenAt, youtubeUrl } }
    knownChasers: {},
    // Spotter Network IDs the admin has explicitly said are NOT a match for
    // anything (dismissed from Suggestions) or NOT worth adding (dismissed
    // from New Chasers Found) — excluded from those lists going forward so
    // a "no" answer doesn't keep resurfacing every refresh.
    dismissedSuggestions: [], // array of "spotterNetworkId::channelId" pairs
    dismissedNewChasers: [],  // array of spotterNetworkId
    playlists: [
      { id: 'playlist-1', title: 'Weather Playlist', playlistId: 'PLNDLR7JhLYhOdX-lSyjsgUSkwcd55UuiI' }
    ]
  };
}

// ── API Routes ──

// Get all data
app.get('/api/data', (req, res) => {
  const data = loadData();
  // Strip API key from public response
  const safe = { ...data, config: { ...data.config, apiKey: '***' } };
  res.json(safe);
});

// Get config (admin only — protect this in production!)
app.get('/api/admin/config', (req, res) => {
  // Prevent Cloudflare (and any other proxy) from caching admin API responses.
  // Without this, a POST to /api/admin/restore followed immediately by a GET
  // here could return a stale cached version, making edits appear to revert.
  res.set('Cache-Control', 'no-store');
  res.json(loadData());
});

// Export full config as downloadable JSON backup
app.get('/api/admin/backup', (req, res) => {
  const data = loadData();
  const filename = 'weathertv-backup-' + new Date().toISOString().split('T')[0] + '.json';
  res.setHeader('Content-Disposition', 'attachment; filename="' + filename + '"');
  res.setHeader('Content-Type', 'application/json');
  res.json(data);
});

// Restore from JSON backup — overwrites current data
app.post('/api/admin/restore', async (req, res) => {
  const data = req.body;
  if (!data || !data.groups || !data.config) {
    return res.status(400).json({ error: 'Invalid backup file — must contain groups and config' });
  }
  // Update in-memory immediately
  appDataStore = data;
  // Wait for Redis to confirm save before responding
  await rSet('wt:appData', data);
  // Also write to filesystem
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch(e) {}
  const totalChannels = data.groups.reduce((s,g) => s + (g.channels||[]).length, 0);
  res.json({ ok: true, message: 'Restored — ' + data.groups.length + ' groups, ' + totalChannels + ' channels loaded' });
});

// Update config
app.put('/api/admin/config', (req, res) => {
  const data = loadData();
  data.config = { ...data.config, ...req.body };
  saveData(data);
  res.json({ ok: true });
});

// Get all groups
app.get('/api/groups', (req, res) => {
  res.json(loadData().groups);
});

// ── Highlights routes ──

// Public — frontend fetches on page load
app.get('/api/highlights', (req, res) => {
  const data = loadData();
  res.json(data.highlights || []);
});

// Admin — get highlights
app.get('/api/admin/highlights', (req, res) => {
  const data = loadData();
  res.json(data.highlights || []);
});

// Admin — add highlight
app.post('/api/admin/highlights', (req, res) => {
  const { channelId, videoId, title, thumbnail } = req.body;
  if (!channelId || !videoId) return res.status(400).json({ error: 'channelId and videoId required' });
  const data = loadData();
  if (!data.highlights) data.highlights = [];
  data.highlights.push({ channelId, videoId, title: title || '', thumbnail: thumbnail || '' });
  saveData(data);
  res.json({ ok: true });
});

// Admin — remove highlight by index
app.delete('/api/admin/highlights/:index', (req, res) => {
  const idx = parseInt(req.params.index, 10);
  const data = loadData();
  if (!data.highlights || idx < 0 || idx >= data.highlights.length) {
    return res.status(404).json({ error: 'Highlight not found' });
  }
  data.highlights.splice(idx, 1);
  saveData(data);
  res.json({ ok: true });
});

// Admin — reorder highlights (swap by index, direction up/down)
app.put('/api/admin/highlights/reorder', (req, res) => {
  const { index, direction } = req.body;
  const data = loadData();
  if (!data.highlights) return res.json({ ok: true });
  const newIdx = direction === 'up' ? index - 1 : index + 1;
  if (newIdx < 0 || newIdx >= data.highlights.length) return res.json({ ok: true });
  const tmp = data.highlights[index];
  data.highlights[index] = data.highlights[newIdx];
  data.highlights[newIdx] = tmp;
  saveData(data);
  res.json({ ok: true });
});

// ── Playlists routes ──

// Public — frontend fetches on page load
app.get('/api/playlists', (req, res) => {
  const data = loadData();
  res.json(data.playlists || []);
});

// Admin — add playlist
app.post('/api/admin/playlists', (req, res) => {
  const { title, playlistId } = req.body;
  if (!title || !playlistId) return res.status(400).json({ error: 'title and playlistId required' });
  const data = loadData();
  if (!data.playlists) data.playlists = [];
  data.playlists.push({ id: 'playlist-' + Date.now(), title, playlistId });
  saveData(data);
  res.json({ ok: true });
});

// Admin — reorder playlists (must be before /:id to avoid Express matching 'reorder' as a param)
app.put('/api/admin/playlists/reorder', (req, res) => {
  const { id, direction } = req.body;
  const data = loadData();
  if (!data.playlists) return res.json({ ok: true });
  const idx = data.playlists.findIndex(p => p.id === id);
  if (idx === -1) return res.json({ ok: true });
  const newIdx = direction === 'up' ? idx - 1 : idx + 1;
  if (newIdx < 0 || newIdx >= data.playlists.length) return res.json({ ok: true });
  const tmp = data.playlists[idx];
  data.playlists[idx] = data.playlists[newIdx];
  data.playlists[newIdx] = tmp;
  saveData(data);
  res.json({ ok: true });
});

// Admin — update playlist
app.put('/api/admin/playlists/:id', (req, res) => {
  const data = loadData();
  if (!data.playlists) return res.status(404).json({ error: 'Not found' });
  const idx = data.playlists.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Playlist not found' });
  data.playlists[idx] = { ...data.playlists[idx], ...req.body };
  saveData(data);
  res.json({ ok: true });
});

// Admin — remove playlist
app.delete('/api/admin/playlists/:id', (req, res) => {
  const data = loadData();
  if (!data.playlists) return res.json({ ok: true });
  data.playlists = data.playlists.filter(p => p.id !== req.params.id);
  saveData(data);
  res.json({ ok: true });
});

// Update a group
app.put('/api/admin/groups/:id', (req, res) => {
  const data = loadData();
  const idx = data.groups.findIndex(g => g.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Group not found' });
  data.groups[idx] = { ...data.groups[idx], ...req.body };
  saveData(data);
  res.json({ ok: true });
});

// Add channel to group
app.post('/api/admin/groups/:groupId/channels', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  const newChannel = { enabled: true, hasLive: true, ...req.body };
  group.channels.push(newChannel);
  saveData(data);
  res.json({ ok: true, channel: newChannel });
});

// Update channel
app.put('/api/admin/groups/:groupId/channels/reorder', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  const { channelId, direction } = req.body;
  const idx = group.channels.findIndex(c => c.id === channelId);
  if (idx === -1) return res.status(404).json({ error: 'Channel not found' });
  const newIdx = direction === 'up' ? idx - 1 : idx + 1;
  if (newIdx < 0 || newIdx >= group.channels.length) return res.json({ ok: true });
  const tmp = group.channels[idx];
  group.channels[idx] = group.channels[newIdx];
  group.channels[newIdx] = tmp;
  saveData(data);
  res.json({ ok: true });
});

// Set full channel order for a group (used by A-Z sort and drag-drop).
// Accepts an array of channel IDs in the desired order; reorders the
// channels array in place without touching any other channel fields.
app.put('/api/admin/groups/:groupId/channels/order', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  const { orderedIds } = req.body;
  if (!Array.isArray(orderedIds)) return res.status(400).json({ error: 'orderedIds must be an array' });
  const byId = Object.fromEntries(group.channels.map(c => [c.id, c]));
  const reordered = orderedIds.map(id => byId[id]).filter(Boolean);
  // Preserve any channels not in orderedIds (edge case safety)
  const included = new Set(orderedIds);
  group.channels.find(c => !included.has(c.id)) && reordered.push(...group.channels.filter(c => !included.has(c.id)));
  group.channels = reordered;
  saveData(data);
  res.json({ ok: true });
});

app.put('/api/admin/groups/:groupId/channels/:channelId', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  const idx = group.channels.findIndex(c => c.id === req.params.channelId);
  if (idx === -1) return res.status(404).json({ error: 'Channel not found' });
  group.channels[idx] = { ...group.channels[idx], ...req.body };
  saveData(data);
  res.json({ ok: true });
});

// Delete channel
app.delete('/api/admin/groups/:groupId/channels/:channelId', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  group.channels = group.channels.filter(c => c.id !== req.params.channelId);
  saveData(data);
  res.json({ ok: true });
});

// Reorder channels within a group
// Add group
app.post('/api/admin/groups', (req, res) => {
  const data = loadData();
  const newGroup = {
    id: req.body.id || 'group-' + Date.now(),
    label: req.body.label || 'New Group',
    icon: req.body.icon || '📺',
    channels: []
  };
  data.groups.push(newGroup);
  saveData(data);
  res.json({ ok: true, group: newGroup });
});

// Delete group
app.delete('/api/admin/groups/:groupId', (req, res) => {
  const data = loadData();
  data.groups = data.groups.filter(g => g.id !== req.params.groupId);
  saveData(data);
  res.json({ ok: true });
});

// Reorder groups
app.put('/api/admin/groups/reorder', (req, res) => {
  const data = loadData();
  const { groupId, direction } = req.body;
  const idx = data.groups.findIndex(g => g.id === groupId);
  if (idx === -1) return res.status(404).json({ error: 'Group not found' });
  const newIdx = direction === 'up' ? idx - 1 : idx + 1;
  if (newIdx < 0 || newIdx >= data.groups.length) return res.json({ ok: true });
  const tmp = data.groups[idx];
  data.groups[idx] = data.groups[newIdx];
  data.groups[newIdx] = tmp;
  saveData(data);
  res.json({ ok: true });
});

// ── Collection (sub-group) routes ──

// Add collection to a channel
app.post('/api/admin/groups/:groupId/channels/:channelId/collections', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  const channel = group.channels.find(c => c.id === req.params.channelId);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });
  if (!channel.collections) channel.collections = [];
  const col = {
    id: req.body.id || 'col-' + Date.now(),
    label: req.body.label || 'New Collection',
    enabled: req.body.enabled !== false
    // No channelIds — channels declare membership via their own collectionId field
  };
  channel.collections.push(col);
  saveData(data);
  res.json({ ok: true, collection: col });
});

// Update collection
app.put('/api/admin/groups/:groupId/channels/:channelId/collections/:colId', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  const channel = group.channels.find(c => c.id === req.params.channelId);
  if (!channel || !channel.collections) return res.status(404).json({ error: 'Not found' });
  const colIdx = channel.collections.findIndex(c => c.id === req.params.colId);
  if (colIdx === -1) return res.status(404).json({ error: 'Collection not found' });
  // Only update label and enabled — membership managed via channel's collectionId
  const { label, enabled } = req.body;
  if (label !== undefined) channel.collections[colIdx].label = label;
  if (enabled !== undefined) channel.collections[colIdx].enabled = enabled;
  saveData(data);
  res.json({ ok: true });
});

// Update a channel's collection memberships (supports multiple)
app.put('/api/admin/groups/:groupId/channels/:channelId/collection-membership', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  const channel = group.channels.find(c => c.id === req.params.channelId);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });
  const ids = req.body.collectionIds || [];
  channel.collectionIds = ids;
  channel.collectionId = ids.length > 0 ? ids[0] : null;
  // hiddenInGroup: hide this channel from the main group list
  // Only visible through its collection button on the parent channel card
  if (req.body.hiddenInGroup !== undefined) {
    channel.hiddenInGroup = req.body.hiddenInGroup;
  }
  saveData(data);
  res.json({ ok: true });
});

// Delete collection
app.delete('/api/admin/groups/:groupId/channels/:channelId/collections/:colId', (req, res) => {
  const data = loadData();
  const group = data.groups.find(g => g.id === req.params.groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });
  const channel = group.channels.find(c => c.id === req.params.channelId);
  if (!channel || !channel.collections) return res.status(404).json({ error: 'Not found' });
  channel.collections = channel.collections.filter(c => c.id !== req.params.colId);
  saveData(data);
  res.json({ ok: true });
});

// Update apps
app.put('/api/admin/apps', (req, res) => {
  if (!Array.isArray(req.body)) {
    return res.status(400).json({ error: 'Expected an array of apps' });
  }
  const data = loadData();
  data.apps = req.body;
  saveData(data);
  res.json({ ok: true });
});

// ── App logo upload ──
// Accepts a base64 data URL from the admin panel's file picker, decodes it,
// and writes it to public/images/apps/<slug>.<ext>. Returns the relative path
// to store in app.img -- index.html's buildAppsPanel() and the collection-button
// logo (height:10px, auto width) both render whatever this points to, so any
// reasonably square image works without further resizing.
app.post('/api/admin/upload-app-logo', (req, res) => {
  try {
    const { name, dataUrl } = req.body;
    if (!name || !dataUrl) return res.status(400).json({ error: 'name and dataUrl required' });

    const match = dataUrl.match(/^data:image\/(png|jpeg|jpg|webp|svg\+xml);base64,(.+)$/);
    if (!match) return res.status(400).json({ error: 'Unsupported image format -- use PNG, JPEG, WEBP, or SVG' });

    let ext = match[1] === 'jpeg' ? 'jpg' : match[1] === 'svg+xml' ? 'svg' : match[1];
    const buffer = Buffer.from(match[2], 'base64');
    if (buffer.length > 3 * 1024 * 1024) return res.status(400).json({ error: 'Image too large -- 3MB max' });

    const slug = String(name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'app';
    const dir = path.join(__dirname, 'public', 'images', 'apps');
    fs.mkdirSync(dir, { recursive: true });

    const filename = `${slug}-${Date.now()}.${ext}`;
    fs.writeFileSync(path.join(dir, filename), buffer);

    res.json({ ok: true, path: `images/apps/${filename}` });
  } catch (e) {
    console.error('[WeatherTV] App logo upload failed:', e.message);
    res.status(500).json({ error: 'Upload failed' });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// ── YouTube API Proxy with Server-Side Caching ──
// The server checks live status on a schedule and caches all results.
// Browser clients get cached data instantly — no extra API calls per user.
// This means 1 user or 1000 users costs the same quota.

const https = require('https');

// ── Quota Guard ──
// Primary key (YOUTUBE_API_KEY): 60,000 units/day — handles all normal
// operations: WebSub live confirmations, recent video fetches (via
// playlistItems.list at 1 unit/channel), and manual checks.
//
// Archive key (YOUTUBE_API_KEY_2): 10,000 units/day — kept configured as
// emergency standby only. Never used on a normal day. Activates automatically
// if the primary key somehow hits its limit (e.g. an unusual spike in
// WebSub confirmations or a manual admin fetch run on top of scheduled ones).
//
// Estimated normal daily usage on primary key:
//   2x recent fetch × 146 channels × 1 unit = ~292 units
//   WebSub confirmations (videos.list, 1 unit each, ~30/day) = ~30 units
//   Total: ~320 units/day — well under 60,000 unit limit.
//
// These pools are independent — the archive key running out must NOT also
// halt WebSub-based live detection on the primary key, which is the
// safety-critical path.
let primaryQuotaExceeded = false;
let archiveQuotaExceeded = false;
let primaryQuotaResetTimer = null;
let archiveQuotaResetTimer = null;

function markQuotaExceeded(isPrimary = true) {
  const label = isPrimary ? 'primary' : 'archive';
  const already = isPrimary ? primaryQuotaExceeded : archiveQuotaExceeded;
  if (already) return;
  if (isPrimary) primaryQuotaExceeded = true; else archiveQuotaExceeded = true;
  console.warn(`[WeatherTV] YouTube ${label} key quota exceeded — pausing ${label}-key calls until midnight Pacific`);
  logEvent({ type: 'quota', severity: 'warn', source: label + '-key', message: `YouTube ${label} key quota exceeded — pausing until midnight Pacific` });
  const now = new Date();
  const pacific = new Date(now.toLocaleString('en-US', { timeZone: 'America/Los_Angeles' }));
  const midnight = new Date(pacific);
  midnight.setHours(24, 0, 30, 0);
  const msUntilReset = midnight - pacific;
  console.log(`[WeatherTV] ${label} key quota will reset in ${Math.round(msUntilReset / 60000)} minutes`);
  const resetFn = () => {
    if (isPrimary) primaryQuotaExceeded = false; else archiveQuotaExceeded = false;
    console.log(`[WeatherTV] ${label} key quota reset — resuming ${label}-key calls`);
    logEvent({ type: 'quota', severity: 'info', source: label + '-key', message: `${label} key quota reset at midnight Pacific — resuming calls` });
    if (isPrimary) scheduledLiveCheck();
  };
  if (isPrimary) {
    if (primaryQuotaResetTimer) clearTimeout(primaryQuotaResetTimer);
    primaryQuotaResetTimer = setTimeout(resetFn, msUntilReset);
  } else {
    if (archiveQuotaResetTimer) clearTimeout(archiveQuotaResetTimer);
    archiveQuotaResetTimer = setTimeout(resetFn, msUntilReset);
  }
}

function getApiKey() {
  return process.env.YOUTUBE_API_KEY || loadData().config.apiKey;
}

// Archive key (YOUTUBE_API_KEY_2) — used for recent video fetches and playlist access
// Falls back to primary key if not configured
function getArchiveApiKey() {
  return process.env.YOUTUBE_API_KEY_2 || getApiKey();
}

function ytFetch(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch(e) { reject(e); }
      });
    }).on('error', reject);
  });
}

function checkQuotaError(data) {
  return data.error && data.error.errors && data.error.errors[0].reason === 'quotaExceeded';
}

// ── Redis Persistent Cache ──
const Redis = require('ioredis');

let redis = null;
if (process.env.REDIS_URL) {
  redis = new Redis(process.env.REDIS_URL, { lazyConnect: true, maxRetriesPerRequest: 2 });
  redis.on('connect', () => console.log('[Redis] Connected — cache persists across deploys'));
  redis.on('error', (e) => console.error('[Redis] Error:', e.message));
} else {
  console.warn('[Redis] No REDIS_URL — using in-memory cache only');
}

// ── Server start time ────────────────────────────────────────────────────────
const SERVER_START_TIME = Date.now();

// In-memory mirrors (fast reads, Redis for persistence)
const cache = {
  liveStatuses: {},
  recentVideos: {},
  playlist: {},
  channelActivity: {}, // { channelId: { lastVideoDate, lastLiveDate, nextFetchDue } }
  lastLiveCheck: null,
  lastNotificationReceived: null, // last WebSub push from YouTube (free, 0 units)
  lastRecentFetch: null,
  websubActive: false,
};

// ── Daily quota burn tracker ─────────────────────────────────────────────────
// Tracks estimated total API units used per day, per key.
// Resets automatically at midnight by checking today's date.
const burnTracker = { date: '', primaryUnits: 0, archiveUnits: 0 };

function trackBurn(isPrimary, units = 100) {
  const today = new Date().toISOString().split('T')[0];
  if (burnTracker.date !== today) {
    burnTracker.date = today;
    burnTracker.primaryUnits = 0;
    burnTracker.archiveUnits = 0;
  }
  if (isPrimary) burnTracker.primaryUnits += units;
  else burnTracker.archiveUnits += units;
}

// ── Storm Chaser Tracker (Spotter Network) ──────────────────────────────────
// Polls the public Spotter Network KML feed every 2 minutes and caches the
// parsed result in memory. No API key required — this is a public feed.
// Source: https://www.spotternetwork.org/feeds/earth-all.txt
//
// Each chaser record looks like:
// { id, name, lat, lng, status, movement, heading, note, positionTime, youtubeUrl }
//
// youtubeUrl is auto-detected from the free-text `Note` field when a chaser
// has self-reported their channel — this lets us flag chasers we don't have
// in our Groups yet (see /api/admin/chasers/unmapped-youtube below).

const SPOTTER_NETWORK_FEED_URL = 'https://www.spotternetwork.org/feeds/earth-all.txt';

let chaserCache = { updatedAt: null, chasers: [] };

function fetchTextOverHttp(url, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https://') ? https : require('http');
    const opts = new URL(url);
    const reqOptions = {
      hostname: opts.hostname,
      path: opts.pathname + opts.search,
      headers: { 'User-Agent': 'WeatherTV/1.0', ...extraHeaders },
    };
    lib.get(reqOptions, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchTextOverHttp(res.headers.location, extraHeaders).then(resolve, reject);
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

// Extracts a YouTube channel/handle/video URL from free text, if present.
function extractYouTubeUrl(text) {
  if (!text) return null;
  const match = text.match(/https?:\/\/(www\.)?(youtube\.com|youtu\.be)\/[^\s<>"']+/i);
  if (match) return match[0].replace(/[.,)]+$/, ''); // trim trailing punctuation
  return null;
}

// Parses the Spotter Network KML text into an array of chaser objects.
// Regex-based rather than a full XML parser — the feed's structure is flat
// and consistent (one <Placemark> per chaser), so this avoids adding a
// dependency for a one-off parse.
function parseSpotterNetworkKML(kmlText) {
  const chasers = [];
  const placemarkRegex = /<Placemark id="(\d+)">([\s\S]*?)<\/Placemark>/g;
  let pm;
  while ((pm = placemarkRegex.exec(kmlText)) !== null) {
    const id = pm[1];
    const block = pm[2];

    const iconMatch = block.match(/<href>([^<]+)<\/href>/);
    const icon = iconMatch ? iconMatch[1] : '';
    let status = 'active';
    let mobile = false;
    if (icon.includes('red_house')) status = 'inactive';
    if (icon.includes('mobile')) mobile = true;
    if (icon.includes('inactive_mobile')) status = 'inactive';

    const nameMatch = block.match(/<name>([^<]*)<\/name>/);
    const name = nameMatch ? nameMatch[1].trim() : 'Unknown';

    const descMatch = block.match(/<description><!\[CDATA\[([\s\S]*?)\]\]><\/description>/);
    const descRaw = descMatch ? descMatch[1] : '';

    const posTimeMatch = descRaw.match(/Position Time:\s*([^<]+)</);
    const positionTime = posTimeMatch ? posTimeMatch[1].trim() : null;

    const movementMatch = descRaw.match(/Movement:\s*([^<]+)</);
    const movement = movementMatch ? movementMatch[1].trim() : 'Stationary';

    const noteMatch = descRaw.match(/Note:\s*([^<]+)</);
    const note = noteMatch ? noteMatch[1].trim() : null;

    const coordMatch = block.match(/<coordinates>([^<]+)<\/coordinates>/);
    let lat = null, lng = null;
    if (coordMatch) {
      const parts = coordMatch[1].split(',');
      lng = parseFloat(parts[0]);
      lat = parseFloat(parts[1]);
    }

    if (lat === null || lng === null || isNaN(lat) || isNaN(lng)) continue;

    chasers.push({
      id,
      name,
      lat,
      lng,
      status,           // 'active' | 'inactive'
      mobile,           // true if currently moving
      movement,         // e.g. 'NNW (321)' or 'Stationary'
      note,
      positionTime,
      youtubeUrl: extractYouTubeUrl(note)
    });
  }
  return chasers;
}

async function refreshChaserCache() {
  try {
    const text = await fetchTextOverHttp(SPOTTER_NETWORK_FEED_URL);
    const chasers = parseSpotterNetworkKML(text);
    chaserCache = { updatedAt: new Date().toISOString(), chasers };
    console.log(`[Chasers] Refreshed Spotter Network feed: ${chasers.length} positions`);
    mergeIntoKnownChasers(chasers);
  } catch (e) {
    console.warn('[Chasers] Failed to refresh Spotter Network feed:', e.message);
  }
}

// Merges this poll's live positions into the persisted, accumulating
// registry (data.knownChasers). This is what lets suggestions/matching work
// against everyone we've EVER seen broadcast, not just whoever happens to
// be active in this specific 2-minute window. Saved to Redis via saveData
// so it survives restarts and keeps growing over days/weeks.
function mergeIntoKnownChasers(chasers) {
  if (!chasers.length) return;
  const data = loadData();
  if (!data.knownChasers) data.knownChasers = {};
  const now = Date.now();
  let added = 0;

  chasers.forEach(c => {
    const existing = data.knownChasers[c.id];
    if (existing) {
      existing.name = c.name; // keep name current in case they update it
      existing.lastSeenAt = now;
      if (c.youtubeUrl) existing.youtubeUrl = c.youtubeUrl; // pick up a newly-added link
    } else {
      data.knownChasers[c.id] = {
        name: c.name,
        firstSeenAt: now,
        lastSeenAt: now,
        youtubeUrl: c.youtubeUrl || null
      };
      added++;
    }
  });

  if (added > 0) console.log(`[Chasers] Added ${added} newly-seen chaser(s) to known registry (total: ${Object.keys(data.knownChasers).length})`);
  saveData(data);
}

// Public — all current chaser positions, with our channel mapping applied
app.get('/api/chasers', (req, res) => {
  const data = loadData();
  const chaserMap = data.chaserMap || {}; // { spotterNetworkId: channelId }
  // Build reverse lookup: channelId -> name, for attaching to mapped chasers
  const channelById = {};
  (data.groups || []).forEach(g => {
    (g.channels || []).forEach(ch => { channelById[ch.id] = ch; });
  });

  const enriched = chaserCache.chasers.map(c => {
    const mappedChannelId = chaserMap[c.id] || null;
    const mappedChannel = mappedChannelId ? channelById[mappedChannelId] : null;
    return {
      ...c,
      channelId: mappedChannelId,
      channelName: mappedChannel ? mappedChannel.name : null
    };
  });

  res.json({ updatedAt: chaserCache.updatedAt, chasers: enriched });
});

// ── Live near this warning ───────────────────────────────────────────────────
// GET /api/live-near-warnings — active storm warnings that have a LIVE WeatherTV
// chaser inside them or within 10 miles, sorted by severity.
// Chasers need a Spotter Network ↔ channel mapping (admin) to be placed.
// Each chaser appears under ONE warning: the one they're inside (or closest
// to), so three chasers on three storms show up as three separate entries.
const NEAR_WARNING_MI = 10;
const WARNING_RANK = { 'TORNADO EMERGENCY': 0, 'PDS Tornado Warning': 1, 'Tornado Warning': 2, 'FLASH FLOOD EMERGENCY': 3,
                       'Extreme Wind Warning': 4, 'Severe Thunderstorm Warning': 5, 'Flash Flood Warning': 6 };
let _nearWarnCache = { data: null, ts: 0 };

function _rings(geom) {
  if (!geom) return [];
  if (geom.type === 'Polygon') return [geom.coordinates[0]];
  if (geom.type === 'MultiPolygon') return geom.coordinates.map(p => p[0]);
  return [];
}
function _inRing(lat, lng, ring) {           // ring: [[lng,lat],…]
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, yi] = ring[i], [xj, yj] = ring[j];
    if (((yi > lat) !== (yj > lat)) && (lng < (xj - xi) * (lat - yi) / (yj - yi) + xi)) inside = !inside;
  }
  return inside;
}
function _milesToRing(lat, lng, ring) {       // shortest distance to the outline, miles
  const kx = 69.17 * Math.cos(lat * Math.PI / 180), ky = 69.05;
  let best = Infinity;
  for (let i = 0; i < ring.length - 1; i++) {
    const ax = (ring[i][0] - lng) * kx, ay = (ring[i][1] - lat) * ky;
    const bx = (ring[i + 1][0] - lng) * kx, by = (ring[i + 1][1] - lat) * ky;
    const dx = bx - ax, dy = by - ay, len2 = dx * dx + dy * dy;
    const t = len2 ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / len2)) : 0;
    best = Math.min(best, Math.hypot(ax + t * dx, ay + t * dy));
  }
  return best;
}

function buildLiveNearWarnings() {
  const { list: warnings, updatedAt } = radar.getActiveStormWarnings();
  const data = loadData();
  const chaserMap = data.chaserMap || {};
  const channelById = {};
  (data.groups || []).forEach(g => (g.channels || []).forEach(ch => { channelById[ch.id] = ch; }));

  // Live WeatherTV chasers who have a Spotter Network position right now
  const liveChasers = chaserCache.chasers.map(c => {
    const channelId = chaserMap[c.id];
    const live = channelId && cache.liveStatuses[channelId];
    if (!live || !live.isLive) return null;
    return { snId: c.id, lat: c.lat, lng: c.lng, channelId, channelName: channelById[channelId]?.name || c.name,
             videoId: live.videoId || null, movement: c.movement, positionTime: c.positionTime };
  }).filter(Boolean);

  const byWarning = new Map();
  for (const ch of liveChasers) {
    let best = null;
    for (const w of warnings) {
      const rings = _rings(w.geometry);
      if (!rings.length) continue;
      const inside = rings.some(r => _inRing(ch.lat, ch.lng, r));
      const miles = inside ? 0 : Math.min(...rings.map(r => _milesToRing(ch.lat, ch.lng, r)));
      if (!inside && miles > NEAR_WARNING_MI) continue;
      const rank = WARNING_RANK[w.displayEvent] ?? 9;
      // inside beats nearby; then the more dangerous warning; then the closer one
      const score = (inside ? 0 : 1000) + rank * 50 + miles;
      if (!best || score < best.score) best = { w, inside, miles, score };
    }
    if (!best) continue;
    const entry = byWarning.get(best.w.id) || { ...best.w, chasers: [] };
    entry.chasers.push({ channelId: ch.channelId, name: ch.channelName, videoId: ch.videoId, inside: best.inside,
                         distanceMi: Math.round(best.miles * 10) / 10, lat: ch.lat, lng: ch.lng, movement: ch.movement });
    byWarning.set(best.w.id, entry);
  }
  const out = [...byWarning.values()]
    .map(w => ({ ...w, chasers: w.chasers.sort((a, b) => a.distanceMi - b.distanceMi) }))
    .sort((a, b) => (WARNING_RANK[a.displayEvent] ?? 9) - (WARNING_RANK[b.displayEvent] ?? 9) || b.chasers.length - a.chasers.length);
  return { updatedAt, activeWarnings: warnings.length, liveMappedChasers: liveChasers.length, warnings: out };
}

app.get('/api/live-near-warnings', (req, res) => {
  if (!_nearWarnCache.data || Date.now() - _nearWarnCache.ts > 60 * 1000) {
    try { _nearWarnCache = { data: buildLiveNearWarnings(), ts: Date.now() }; }
    catch (e) { console.warn('[NearWarnings]', e.message); if (!_nearWarnCache.data) return res.status(500).json({ error: 'unavailable' }); }
  }
  res.set('Cache-Control', 'public, max-age=60');
  res.json(_nearWarnCache.data);
});

// ── Timing-based chaser matching (chaser-timing.js) ─────────────────────────
function _spotterTimeMs(t) {
  if (!t) return NaN;
  const iso = String(t).trim().replace(' UTC', 'Z').replace(/^(\d{4}-\d{2}-\d{2}) /, '$1T');
  return Date.parse(iso);
}
require('./chaser-timing')(app, {
  rGet, rSet, loadData, saveData,
  getLiveChannelIds: () => Object.entries(cache.liveStatuses || {}).filter(([, v]) => v && v.isLive).map(([id]) => id),
  // Active = pinged within the last 30 min (or present in the live feed when its time can't be read)
  getActiveTrackerIds: () => chaserCache.chasers.filter(c => {
    const t = _spotterTimeMs(c.positionTime);
    return !Number.isFinite(t) || Date.now() - t < 30 * 60 * 1000;
  }).map(c => String(c.id)),
});

// Admin — same data, used by the Chaser Mapping panel
app.get('/api/admin/chasers', (req, res) => {
  const data = loadData();
  res.json({
    updatedAt: chaserCache.updatedAt,
    chasers: chaserCache.chasers,
    chaserMap: data.chaserMap || {},
    knownChasersCount: Object.keys(data.knownChasers || {}).length
  });
});

// Admin — full accumulated registry of every chaser we've ever seen, for
// browsing directly (the "All Known" tab). The Suggestions matcher is
// intentionally conservative to avoid false positives, so this gives the
// admin a way to manually catch anything the matcher missed — e.g. a
// channel name that's a stage name with zero token overlap with the
// chaser's real name on Spotter Network.
app.get('/api/admin/chasers/known', (req, res) => {
  const data = loadData();
  const knownChasers = data.knownChasers || {};
  const chaserMap = data.chaserMap || {};
  const dismissedNew = new Set(data.dismissedNewChasers || []);
  const liveIds = new Set(chaserCache.chasers.map(c => c.id));

  const all = Object.entries(knownChasers).map(([spotterNetworkId, c]) => ({
    spotterNetworkId,
    name: c.name,
    firstSeenAt: c.firstSeenAt,
    lastSeenAt: c.lastSeenAt,
    youtubeUrl: c.youtubeUrl || null,
    isLiveNow: liveIds.has(spotterNetworkId),
    mappedChannelId: chaserMap[spotterNetworkId] || null,
    dismissedAsNew: dismissedNew.has(spotterNetworkId)
  }));

  res.json({ total: all.length, chasers: all });
});

// ── Canadian Radar (MSC GeoMet) GetCapabilities proxy ───────────────────────
// The WMS tile images themselves (RADAR_1KM_RRAI) load fine directly from
// the browser via Leaflet's <img>-based tile layer — <img> tags aren't
// subject to CORS. The one call that IS subject to CORS is the
// GetCapabilities XML fetch radar.html uses to discover available frame
// timestamps, since that goes through fetch(), which browsers do enforce
// CORS on. Rather than depend on whether geo.weather.gc.ca happens to send
// permissive CORS headers (unverified, and out of our control either way),
// this proxies that one XML request through our own server — server-to-
// server requests are never subject to CORS, so this removes the
// uncertainty entirely regardless of the answer.
//
// LAYER ID NOTE: the originally-used RADAR_1KM_RDBR does not appear in MSC
// GeoMet's current official documentation and was almost certainly the
// reason nothing rendered. RADAR_1KM_RRAI ("Radar precipitation rate for
// rain [mm/hr]") is the confirmed correct ID per ECCC's own readme:
// https://eccc-msc.github.io/open-data/msc-data/obs_radar/readme_radar_geomet_en/
// GET /api/firebase-config
// Serves the PUBLIC Firebase web app config to the client.
// These values identify the Firebase project but are NOT secret — they are
// safe to expose to browsers (this is how Firebase is designed to work).
// Store these in Railway env vars rather than hardcoding in index.html so
// the source code doesn't need to change if the Firebase project changes.
//
// Required Railway env vars:
//   FIREBASE_WEB_API_KEY         — Firebase Console → Project Settings → Web app → apiKey
//   FIREBASE_MESSAGING_SENDER_ID — Firebase Console → Project Settings → Web app → messagingSenderId
//   FIREBASE_APP_ID              — Firebase Console → Project Settings → Web app → appId
//   FIREBASE_VAPID_KEY           — Firebase Console → Cloud Messaging → Web Push certificates → Key pair
app.get('/api/firebase-config', (req, res) => {
  const apiKey      = process.env.FIREBASE_WEB_API_KEY;
  const senderId    = process.env.FIREBASE_MESSAGING_SENDER_ID;
  const appId       = process.env.FIREBASE_APP_ID;
  const vapidKey    = process.env.FIREBASE_VAPID_KEY;

  // If none of the vars are set, return a signal the client can detect
  if (!apiKey && !senderId && !appId && !vapidKey) {
    return res.json({ configured: false });
  }

  res.set('Cache-Control', 'public, max-age=3600'); // config rarely changes
  res.json({
    configured: true,
    config: {
      apiKey:            apiKey            || '',
      authDomain:        'weather-tv-radar.firebaseapp.com',
      projectId:         'weather-tv-radar',
      storageBucket:     'weather-tv-radar.firebasestorage.app',
      messagingSenderId: senderId          || '',
      appId:             appId             || '',
    },
    vapidKey: vapidKey || '',
  });
});

// GET /api/nhc-storms
// Proxies NHC CurrentStorms.json — nhc.noaa.gov does not send CORS headers so
// browsers (including the WeatherStar iframe) cannot fetch it directly.
// Cached 10 minutes — storm positions update roughly every 3-6 hours.
const _nhcCache = { data: null, ts: 0 };
const NHC_TTL = 10 * 60 * 1000;

app.get('/api/nhc-storms', async (req, res) => {
  if (_nhcCache.data && Date.now() - _nhcCache.ts < NHC_TTL) {
    res.set('Cache-Control', 'public, max-age=600');
    return res.json(_nhcCache.data);
  }
  try {
    const text = await fetchTextOverHttp('https://www.nhc.noaa.gov/CurrentStorms.json');
    const data = JSON.parse(text);
    _nhcCache.data = data;
    _nhcCache.ts = Date.now();
    res.set('Cache-Control', 'public, max-age=600');
    res.json(data);
  } catch(e) {
    console.warn('[NHC] Proxy error:', e.message);
    if (_nhcCache.data) return res.json(_nhcCache.data);
    res.status(502).json({ activeStorms: [], error: 'NHC unavailable' });
  }
});

// GET /api/river-gauges?xmin=&ymin=&xmax=&ymax=
// Proxies NOAA NWPS gauge API — api.water.noaa.gov does not send CORS headers.
// Cached 5 minutes per bbox (gauges update every 15 min).
const _gaugeCache = new Map();
const GAUGE_TTL = 5 * 60 * 1000;

app.get('/api/river-gauges', async (req, res) => {
  const { xmin, ymin, xmax, ymax } = req.query;
  if (!xmin || !ymin || !xmax || !ymax) {
    return res.status(400).json({ error: 'Missing bbox params: xmin, ymin, xmax, ymax' });
  }
  const key = [xmin, ymin, xmax, ymax].map(v => parseFloat(v).toFixed(2)).join(',');
  const cached = _gaugeCache.get(key);
  if (cached && Date.now() - cached.ts < GAUGE_TTL) {
    res.set('Cache-Control', 'public, max-age=300');
    return res.json(cached.data);
  }
  try {
    const url = `https://api.water.noaa.gov/nwps/v1/gauges?` +
      `bbox.xmin=${xmin}&bbox.ymin=${ymin}&bbox.xmax=${xmax}&bbox.ymax=${ymax}` +
      `&srid=EPSG_4326&count=200`;
    const text = await fetchTextOverHttp(url);
    const data = JSON.parse(text);
    _gaugeCache.set(key, { data, ts: Date.now() });
    if (_gaugeCache.size > 50) {
      const oldest = [..._gaugeCache.entries()].sort((a, b) => a[1].ts - b[1].ts)[0];
      _gaugeCache.delete(oldest[0]);
    }
    res.set('Cache-Control', 'public, max-age=300');
    res.json(data);
  } catch(e) {
    console.warn('[River Gauges] Proxy error:', e.message);
    const stale = _gaugeCache.get(key);
    if (stale) return res.json(stale.data);
    res.status(502).json({ gauges: [], error: 'NWPS unavailable' });
  }
});

// GET /api/canada-alerts
// Proxies Environment Canada's national weather alert ATOM feed and returns
// structured JSON. EC's ATOM feed gives us event type, headline, province/
// territory, severity, and expiry time. We also fetch GeoMet's WFS features
// for the ALERTS layer to get geographic polygons where available.
// Cached 5 minutes — EC typically updates alerts every 5–15 minutes.
const _caAlertsCache = { data: null, ts: 0 };
const CA_ALERTS_TTL = 5 * 60 * 1000;

const EC_SEVERITY = {
  'warning':  { color: '#ff0000', rank: 3 },
  'watch':    { color: '#ff8c00', rank: 2 },
  'advisory': { color: '#ffff00', rank: 1 },
  'statement':{ color: '#6699cc', rank: 0 },
  'ended':    { color: '#888888', rank: -1 },
};

function parseECAtom(xml) {
  const entries = [];
  const entryBlocks = xml.match(/<entry[\s\S]*?<\/entry>/g) || [];
  entryBlocks.forEach(block => {
    const title    = (block.match(/<title[^>]*>([^<]+)<\/title>/)  || [])[1] || '';
    const summary  = (block.match(/<summary[^>]*>([\s\S]*?)<\/summary>/) || [])[1] || '';
    const updated  = (block.match(/<updated>([^<]+)<\/updated>/)   || [])[1] || '';
    const link     = (block.match(/<link[^>]+href="([^"]+)"/)      || [])[1] || '';
    const category = (block.match(/<category[^>]+term="([^"]+)"/)  || [])[1] || '';
    const id       = (block.match(/<id>([^<]+)<\/id>/)             || [])[1] || '';

    // Parse "Event Type in effect - Location, Province" pattern
    const titleMatch = title.match(/^(.+?)\s+in\s+effect\s*[-–]\s*(.+)$/i);
    const eventType  = titleMatch ? titleMatch[1].trim() : title.trim();
    const location   = titleMatch ? titleMatch[2].trim() : '';

    // Derive severity from event name
    const lower = eventType.toLowerCase();
    let severity = 'statement';
    if (lower.includes('warning') || lower.includes('watch')) {
      severity = lower.includes('warning') ? 'warning' : 'watch';
    } else if (lower.includes('advisory')) {
      severity = 'advisory';
    }
    if (lower.includes('ended') || lower.includes('cancel')) severity = 'ended';

    entries.push({ id, eventType, location, severity, summary: summary.replace(/<[^>]+>/g,'').trim().slice(0,300), updated, link, category });
  });
  // Sort by severity rank (warnings first)
  entries.sort((a,b) => (EC_SEVERITY[b.severity]?.rank||0) - (EC_SEVERITY[a.severity]?.rank||0));
  return entries;
}

app.get('/api/canada-alerts', async (req, res) => {
  if (_caAlertsCache.data && Date.now() - _caAlertsCache.ts < CA_ALERTS_TTL) {
    res.set('Cache-Control', 'public, max-age=300');
    return res.json(_caAlertsCache.data);
  }
  // EC has several URL patterns for their alert feeds — try each until one works
  const EC_ALERT_URLS = [
    'https://weather.gc.ca/rss/battleboard/can_e.xml',
    'https://www.weather.gc.ca/rss/battleboard/can_e.xml',
    'https://weather.gc.ca/en/warnings/rss/can_e.xml',
  ];
  let xml = null;
  for (const feedUrl of EC_ALERT_URLS) {
    try {
      const text = await fetchTextOverHttp(feedUrl);
      if (text.includes('<entry') || text.includes('<item')) { xml = text; break; }
      console.log(`[CA Alerts] ${feedUrl} returned no entries`);
    } catch(e) {
      console.warn(`[CA Alerts] ${feedUrl} failed:`, e.message);
    }
  }
  if (!xml) {
    console.warn('[CA Alerts] All EC feed URLs failed');
    if (_caAlertsCache.data) return res.json(_caAlertsCache.data);
    return res.status(502).json({ error: 'Environment Canada alerts unavailable', alerts: [] });
  }
  try {
    const alerts = parseECAtom(xml);
    console.log(`[CA Alerts] Parsed ${alerts.length} alerts from EC feed`);
    const result = { alerts, generatedAt: Date.now(), source: 'Environment Canada / ECCC' };
    _caAlertsCache.data = result;
    _caAlertsCache.ts = Date.now();
    res.set('Cache-Control', 'public, max-age=300');
    res.json(result);
  } catch(e) {
    console.warn('[CA Alerts] Parse failed:', e.message);
    if (_caAlertsCache.data) return res.json(_caAlertsCache.data);
    res.status(502).json({ error: 'Environment Canada alerts unavailable', alerts: [] });
  }
});

app.get('/api/canada-radar/capabilities', async (req, res) => {
  const layer = (req.query.layer || 'RADAR_1KM_RRAI').replace(/[^A-Z0-9_]/gi, ''); // basic allowlist sanitization
  const url = `https://geo.weather.gc.ca/geomet?service=WMS&version=1.3.0&request=GetCapabilities&layer=${layer}&t=${Date.now()}`;
  try {
    const xml = await fetchTextOverHttp(url);
    res.set('Content-Type', 'application/xml');
    res.set('Cache-Control', 'public, max-age=120'); // capabilities don't change every second
    res.send(xml);
  } catch (e) {
    console.warn('[CanadaRadar] GetCapabilities proxy failed:', e.message);
    res.status(502).json({ error: 'Could not reach geo.weather.gc.ca' });
  }
});

// GET /api/geomet/precip-layers
// GeoMet renames model layers over time (e.g. RDPS.ETA_* → RDPS_10km_*), so
// instead of hard-coding names we read GeoMet's own layer list once a day and
// return every precipitation layer for the Canadian models. The full list is
// ~40 MB, so it's STREAMED: only Name/Title pairs mentioning precipitation are
// kept (a few KB), never the whole document.
let _geometPrecip = { data: null, ts: 0, pending: null };
function _scanGeometCapabilities() {
  return new Promise((resolve, reject) => {
    const https = require('https');
    const found = new Map();
    let tail = '';
    const re = /<Name>([^<]{2,120})<\/Name>\s*<Title>([^<]{2,300})<\/Title>/g;
    const req = https.get('https://geo.weather.gc.ca/geomet?service=WMS&version=1.3.0&request=GetCapabilities&lang=en',
      { headers: { 'User-Agent': 'WeatherTV/1.0 (+https://watchweathertv.com)' }, timeout: 90000 }, r => {
        if (r.statusCode !== 200) { r.resume(); return reject(new Error('GeoMet HTTP ' + r.statusCode)); }
        r.setEncoding('utf8');
        r.on('data', chunk => {
          const buf = tail + chunk;
          let m, last = 0;
          re.lastIndex = 0;
          while ((m = re.exec(buf))) {
            last = re.lastIndex;
            const [, name, title] = m;
            if (/^(RDPS|HRDPS|GDPS)/i.test(name) && /precip|rain|taux|pr[ée]cip/i.test(title + ' ' + name)) found.set(name.trim(), title.trim());
          }
          tail = buf.slice(Math.max(last, buf.length - 2000));   // keep a little overlap for tags split across chunks
        });
        r.on('end', () => resolve([...found].map(([name, title]) => ({ name, title }))));
        r.on('error', reject);
      });
    req.on('timeout', () => req.destroy(new Error('GeoMet capabilities timeout')));
    req.on('error', reject);
  });
}
app.get('/api/geomet/precip-layers', async (req, res) => {
  const fresh = _geometPrecip.data && Date.now() - _geometPrecip.ts < 24 * 3600 * 1000;
  if (!fresh) {
    if (!_geometPrecip.pending) {
      _geometPrecip.pending = _scanGeometCapabilities()
        .then(list => { if (list.length) _geometPrecip = { data: list, ts: Date.now(), pending: null }; else _geometPrecip.pending = null; return list; })
        .catch(e => { _geometPrecip.pending = null; throw e; });
    }
    try { await _geometPrecip.pending; } catch (e) {
      if (!_geometPrecip.data) return res.status(502).json({ error: 'GeoMet layer list unavailable', detail: e.message });
    }
  }
  res.set('Cache-Control', 'public, max-age=3600');
  res.json({ layers: _geometPrecip.data || [], fetchedAt: _geometPrecip.ts });
});

// ── TRAFFIC CAMERAS ─────────────────────────────────────────────────────────
// Merges two sources into one normalised feed:
//   1. OpenTrafficCamMap (OTC) — MIT-licensed static JSON on GitHub,
//      ~7,500 US cameras, no API key required. Fetched once and cached for
//      60 min since it's a static file that rarely changes.
//   2. Road511 — normalised 511 feed, 10,000+ cameras, requires API key
//      (ROAD511_API_KEY env var). Queried per bounding-box viewport so
//      we only pull what's visible. Cached 3 min per viewport cell.
//
// The client sees ONE endpoint, ONE schema. Source attribution is invisible
// to users. Road511 data is preferred when both sources have a camera at
// the same physical location (deduplicated within 100m).
//
// CORS handling: DOT camera image URLs almost universally block direct
// browser requests. We don't proxy the images themselves (that would
// massively increase bandwidth costs) — instead, the client fetches
// images via /api/camera-image?url=... which pipes them back with the
// right CORS headers. Cached 25s so a 30-second refresh cycle stays fresh.

const OTC_JSON_URL = 'https://raw.githubusercontent.com/AidanWelch/OpenTrafficCamMap/master/cameras/USA.json';
let _otcCache = null;       // parsed flat array of cameras
let _otcCacheTime = 0;
const OTC_TTL = 60 * 60 * 1000; // 60 min — static file, rarely changes

// Road511 viewport cache: key = `${bbox}` -> { cameras, ts }
const _road511Cache = new Map();
const ROAD511_TTL = 3 * 60 * 1000; // 3 min

// Image proxy cache: key = url -> { buf, ct, ts }
const _imgCache = new Map();
const IMG_TTL = 25 * 1000; // 25s — keeps refresh cycle fresh

// ── STATE DOT CAMERA SOURCES ─────────────────────────────────────────────────
// The IBI Group / Skyline 511 platform is used by the majority of US state
// DOTs. Every state on this platform uses the IDENTICAL JSON schema:
//   GET /api/v2/get/cameras?key={key}&format=json
//   → [ { Id, Latitude, Longitude, Location, Roadway, Direction,
//          Views: [{ Id, Url, VideoUrl, Status }] } ]
//
// Adding a new state DOT is a single entry in STATE_DOTS — no new parse
// logic, no new edge cases, no code changes beyond this array. The generic
// _loadStateDOT() loader handles fetch, cache, parse, and error handling
// uniformly for every entry.
//
// To add a state:
//   1. Sign up for a developer key at their 511 portal (or confirm it's public)
//   2. Add { id, label, url, envKey, cacheTTL } below
//   3. Add the env var to Railway — that's it
//
// envKey: Railway env var name that holds the API key.
//         Set to null for public endpoints that need no key.
//
// CONFIRMED ON SAME PLATFORM (can add immediately once you have a key):
//   Arizona:   https://az511.com/api/v2/get/cameras   (AZDOT_511_KEY)
//   Georgia:   https://511ga.org/api/v2/get/cameras   (GA_511_KEY)
//   Louisiana: https://511la.org/api/v2/get/cameras   (LA_511_KEY)
//   (any other state 511 site running the IBI/Skyline platform)

const STATE_DOTS = [
  // ── IBI Group / Skyline 511 platform ────────────────────────────────────
  // All these states use the IDENTICAL API schema. Adding any new state on
  // this platform: copy an entry, update id/label/url/envKey, done.
  // Env var convention: {STATE}_511_KEY  (e.g. WI_511_KEY, GA_511_KEY)
  {
    id: 'wi',
    label: 'Wisconsin DOT',
    url: 'https://511wi.gov/api/v2/get/cameras?format=json',
    envKey: 'WI_511_KEY',
    cacheTTL: 10 * 60 * 1000,
    parse: _parseIBI511,
  },
  {
    id: 'ny',
    label: 'New York DOT',
    url: 'https://511ny.org/api/v2/get/cameras?format=json',
    envKey: 'NY_511_KEY',
    cacheTTL: 10 * 60 * 1000,
    parse: _parseIBI511,
  },
  {
    id: 'ga',
    label: 'Georgia DOT',
    url: 'https://511ga.org/api/v2/get/cameras?format=json',
    envKey: 'GA_511_KEY',
    cacheTTL: 10 * 60 * 1000,
    parse: _parseIBI511,
  },
  {
    id: 'la',
    label: 'Louisiana DOTD',
    url: 'https://www.511la.org/api/v2/get/cameras?format=json',
    envKey: 'LA_511_KEY',
    cacheTTL: 10 * 60 * 1000,
    parse: _parseIBI511,
  },
  {
    id: 'az',
    label: 'Arizona DOT',
    url: 'https://az511.com/api/v2/get/cameras?format=json',
    envKey: 'AZ_511_KEY',
    cacheTTL: 10 * 60 * 1000,
    parse: _parseIBI511,
  },

  // ── North Carolina ───────────────────────────────────────────────────────
  // DriveNC (drivenc.gov) — confirmed IBI/Skyline platform, same schema.
  // Env var: NC_511_KEY (key obtained via drivenc.gov developer portal)
  {
    id: 'nc',
    label: 'North Carolina DOT',
    url: 'https://www.drivenc.gov/api/v2/get/cameras?format=json',
    envKey: 'NC_511_KEY',
    cacheTTL: 10 * 60 * 1000,
    parse: _parseIBI511,
  },

  // ── Waiting on keys: these stay OFF until their variable is set ─────────
  // New York — 511NY (older v1 API: Url/VideoUrl on each camera). NY_511_KEY
  { id:'ny', label:'New York 511', url:'https://511ny.org/api/getcameras?format=json', envKey:'NY_511_KEY', cacheTTL:10*60*1000, parse:_parseIBI511 },
  // Virginia — VDOT SmarterRoads. The camera feed address is shown in your
  // SmarterRoads account once approved: set VA_511_URL to it and VA_511_KEY to
  // the token (sent as ?token=, change with VA_511_AUTH_PARAM). Fields are
  // detected automatically.
  { id:'va', label:'Virginia DOT (SmarterRoads)', cacheTTL:10*60*1000,
    load: async (dot) => {
      const key = process.env.VA_511_KEY, url = process.env.VA_511_URL;
      if (!key || !url) return [];
      const param = process.env.VA_511_AUTH_PARAM || 'token';
      const full = url + (url.includes('?') ? '&' : '?') + `${param}=${encodeURIComponent(key)}`;
      return _parseGenericCameraJSON(JSON.parse(await fetchTextOverHttp(full)), dot);
    } },

  // ── ArcGIS open-data layers (no key) ───────────────────────────────────
  // Florida: statewide from FL511 once FL_511_KEY is set (same platform as
  // GA/NC). Until then, a public ArcGIS copy of FL511 cameras (partial —
  // mostly east-central/southeast Florida, last updated July 2026).
  { id:'fl', label:'Florida 511', cacheTTL:15*60*1000,
    load: async (dot) => {
      if (process.env.FL_511_KEY) {
        const txt = await fetchTextOverHttp(`https://fl511.com/api/v2/get/cameras?format=json&key=${encodeURIComponent(process.env.FL_511_KEY)}`);
        return _parseIBI511(JSON.parse(txt), 'fl', { url: 'https://fl511.com/api/v2/get/cameras' });
      }
      return _loadArcGISLayer({ id: 'fl', arcgisLayer: 'https://services.arcgis.com/3wFbqsFPLeKqOlIK/arcgis/rest/services/FL511_Traffic_Cameras/FeatureServer/0' });
    } },
  // Illinois: IDOT Open Data "Gateway Traffic Camera Locations" (SnapShot = public image; TooOld skipped)
  { id:'il', label:'Illinois DOT', cacheTTL:15*60*1000, arcgisItem:'8a885da23dfb46caaa1827ad920fb5b1', load: _loadArcGISLayer },
  // Iowa: Iowa DOT Open Data "Traffic Cameras" (static image + video where available; list updated daily)
  { id:'ia', label:'Iowa DOT', cacheTTL:60*60*1000, arcgisItem:'c4063f200a7b4da5826e2ac86c677cf5', load: _loadArcGISLayer },

  // ── Pennsylvania ─────────────────────────────────────────────────────────
  // PA uses ASP.NET map layer markers per Road511's article — non-standard
  // format, needs investigation before building a parser.
  // { id:'pa', label:'Pennsylvania DOT', url:'CONFIRM_URL',
  //   envKey:'PA_511_KEY', cacheTTL:10*60*1000, parse:_parsePADOT },

  // ── Additional IBI/Skyline states (same _parseIBI511, just needs a key) ─
  { id:'id', label:'Idaho DOT',   url:'https://511.idaho.gov/api/v2/get/cameras?format=json',     envKey:'ID_511_KEY', cacheTTL:10*60*1000, parse:_parseIBI511 },
  { id:'nv', label:'Nevada DOT',  url:'https://www.nvroads.com/api/v2/get/cameras?format=json',    envKey:'NV_511_KEY', cacheTTL:10*60*1000, parse:_parseIBI511 },
  { id:'ut', label:'Utah DOT',    url:'https://prod-ut.ibi511.com/api/v2/get/cameras?format=json', envKey:'UT_511_KEY', cacheTTL:10*60*1000, parse:_parseIBI511 },
  // Same IBI/Skyline platform — keys: AK_511_KEY, CT_511_KEY
  { id:'ak', label:'Alaska DOT&PF', url:'https://511.alaska.gov/api/v2/get/cameras?format=json',   envKey:'AK_511_KEY', cacheTTL:10*60*1000, parse:_parseIBI511 },
  { id:'ct', label:'Connecticut DOT', url:'https://ctroads.org/api/v2/get/cameras?format=json',    envKey:'CT_511_KEY', cacheTTL:10*60*1000, parse:_parseIBI511 },

  // ── Florida ──────────────────────────────────────────────────────────────
  // FL511 (fl511.com) runs on FDOT's proprietary SunGuide ATMS platform,
  // built entirely in-house. There is NO public developer API — no endpoint
  // docs, no key signup, no documented REST interface. The camera images
  // are publicly viewable on fl511.com but the data comes from internal
  // SunGuide feeds that aren't exposed externally. Would require
  // reverse-engineering the FL511 web app's network requests, which is
  // fragile, against their ToS, and not worth maintaining.
  // Florida is one of the few states Road511 had to handle with custom
  // scraping rather than an official API — if we ever want FL coverage,
  // Road511 Starter ($29/mo) is the realistic path.

  // ── Minnesota DOT ────────────────────────────────────────────────────────
  // Public endpoint, no key required. Different platform from IBI/Skyline.
  // Schema verified defensively — see _parseMnDOT below.
  {
    id: 'mn',
    label: 'Minnesota DOT',
    url: 'https://tr.511mn.org/tgcameras/api/cameras',
    envKey: null,
    cacheTTL: 10 * 60 * 1000,
    parse: _parseMnDOT,
  },

  // ── Illinois DOT (Gateway system) ────────────────────────────────────────
  // Illinois uses IDOT's ArcGIS Hub (public open data portal) for the
  // Gateway camera dataset. gis-idot.opendata.arcgis.com is IDOT's PUBLIC
  // data sharing site — NOT the same system as gis1.dot.illinois.gov
  // (their private internal ArcGIS Server for infrastructure/permits).
  //
  // The IL_ARCGIS_KEY obtained from gis1.dot.illinois.gov almost certainly
  // does NOT authenticate against the public Hub — but the Hub dataset is
  // likely publicly accessible without any key at all, since that's the
  // whole point of an open data portal. Setting envKey to null so this
  // always loads without requiring a key.
  //
  // If the public endpoint starts returning 401/403, revisit whether IDOT
  // has added auth to this specific dataset — at that point contact
  // travelmidwest.com directly for data feed credentials (which Road511's
  // article identified as the real upstream for IL camera images).
  {
    id: 'il',
    label: 'Illinois DOT (Gateway)',
    url: 'https://gis-idot.opendata.arcgis.com/datasets/IDOT::illinois-gateway-traffic-cameras/FeatureServer/0/query?where=1%3D1&outFields=*&f=json',
    envKey: null,                  // public open data Hub — no key required
    cacheTTL: 10 * 60 * 1000,
    parse: _parseILGateway,
  },

  // ── To add more states ───────────────────────────────────────────────────
  // IBI/Skyline platform (most US state 511 sites):
  //   { id:'xx', label:'State DOT', url:'https://511xx.gov/api/v2/get/cameras?format=json',
  //     envKey:'XX_511_KEY', cacheTTL: 10*60*1000, parse: _parseIBI511 }
  //
  // Other platforms: write a new parse function following the same pattern
  // as _parseILGateway, then use it here.
];

// Cache for state DOT data: id -> { cameras, ts }
const _stateDOTCache = new Map();

// Standard IBI Group / Skyline 511 platform parser.
// Used by WI and confirmed identical on AZ, GA, LA, and most US state DOTs.
function _parseIBI511(raw, sourceId, dot) {
  if (!Array.isArray(raw)) return [];
  let baseUrl = '';
  try { if (dot?.url) baseUrl = new URL(dot.url).origin; } catch(_) {}
  const cameras = [];
  for (const cam of raw) {
    const lat = parseFloat(cam.Latitude), lng = parseFloat(cam.Longitude);
    if (!isFinite(lat) || !isFinite(lng)) continue;
    // v2: cam.Views[] · v1 (e.g. 511NY /api/getcameras): Url/VideoUrl on the camera itself
    const views = Array.isArray(cam.Views) ? cam.Views
      : (cam.Url || cam.VideoUrl) ? [{ Id: cam.ID || cam.Id, Url: cam.Url, VideoUrl: cam.VideoUrl,
          Status: (cam.Disabled || cam.Blocked) ? 'Disabled' : 'Enabled', Description: cam.Name }] : [];
    const view = views.find(v => v.Status === 'Enabled') || views[0];
    if (!view) continue;
    // Skip cameras where ALL views are disabled — their images redirect to /notfound
    if (view.Status === 'Disabled' && !views.some(v => v.Status === 'Enabled')) continue;
    const videoUrl = view.VideoUrl || null;
    const key = (dot?.envKey && process.env[dot.envKey]) ? process.env[dot.envKey] : null;
    // The v2 API gives each view's image link as `Url` (e.g. https://511ga.org/map/Cctv/24698).
    // The old fallback built /Cctv/GetCctvImage?viewId=… — a path these sites
    // don't have, so every image 404'd (GA, NC, AZ, ID, UT). /map/Cctv/{id}
    // is the public image path on this platform.
    void key;
    const imageUrl = view.Url || view.ImageUrl
      || (baseUrl && view.Id ? `${baseUrl}/map/Cctv/${view.Id}` : null);
    cameras.push({
      id: `${sourceId}-${cam.Id}`,
      name: cam.Location || cam.Name || cam.Roadway || cam.RoadwayName || 'Traffic Camera',
      lat, lng,
      imageUrl,
      videoUrl,
      direction: (cam.Direction && cam.Direction !== 'Unknown') ? cam.Direction : null,
      source: sourceId,
    });
  }
  return cameras;
}

// Minnesota DOT parser (tr.511mn.org/tgcameras/api/cameras).
// Schema unverified from official docs — written defensively to handle
// whatever actually comes back. Will log the raw schema on first load so
// we can refine this if the field names differ from the IBI standard.
function _parseMnDOT(raw, sourceId) {
  if (!Array.isArray(raw)) {
    // Some MN endpoints wrap the array in a container object
    if (raw && Array.isArray(raw.cameras)) raw = raw.cameras;
    else if (raw && Array.isArray(raw.features)) {
      // GeoJSON FeatureCollection fallback
      return raw.features.map((f, i) => {
        const p = f.properties || {};
        const coords = f.geometry && f.geometry.coordinates;
        if (!coords) return null;
        return {
          id: `${sourceId}-${p.id || p.ID || i}`,
          name: p.location || p.name || p.roadway || 'MN Traffic Camera',
          lat: coords[1], lng: coords[0],
          imageUrl: p.imageUrl || p.image_url || null,
          videoUrl: p.videoUrl || p.video_url || null,
          direction: p.direction || null,
          source: sourceId,
        };
      }).filter(Boolean);
    }
    else { console.warn('[Cameras] MN DOT: unexpected schema', typeof raw); return []; }
  }
  // Log first entry on first load so we can see the real field names
  if (raw.length > 0 && !_stateDOTCache.has('mn')) {
    console.log('[Cameras] MN DOT first entry schema:', JSON.stringify(raw[0], null, 2).slice(0, 500));
  }
  return raw.map((cam, i) => {
    // Try the IBI field names first, then common MN-specific variants
    const lat = parseFloat(cam.Latitude ?? cam.latitude ?? cam.lat ?? cam.Y ?? cam.y);
    const lng = parseFloat(cam.Longitude ?? cam.longitude ?? cam.lng ?? cam.X ?? cam.x);
    if (!isFinite(lat) || !isFinite(lng)) return null;
    const views = cam.Views || cam.views || [];
    const view = (Array.isArray(views) ? views : []).find(v => (v.Status || v.status) === 'Enabled') || views[0];
    const videoUrl = (view && (view.VideoUrl || view.videoUrl)) || cam.videoUrl || cam.VideoUrl || null;
    const imageUrl = (view && (view.ImageUrl || view.imageUrl)) || cam.imageUrl || cam.url || null;
    const name = cam.Location || cam.location || cam.name || cam.description || cam.Roadway || cam.roadway || 'MN Traffic Camera';
    return {
      id: `${sourceId}-${cam.Id || cam.id || cam.cameraId || i}`,
      name, lat, lng, imageUrl, videoUrl,
      direction: cam.Direction || cam.direction || null,
      source: sourceId,
    };
  }).filter(Boolean);
}

// Illinois Gateway system parser.
// ArcGIS FeatureServer response; field names: y (lat), x (lng),
// CameraLocation, CameraDirection, SnapShot (direct image URL).
// The ArcGIS token goes in the query string as `token=`.
function _parseILGateway(raw, sourceId) {
  // ArcGIS query responses wrap features in { features: [{ attributes, geometry }] }
  const features = raw.features || [];
  return features.map((f, i) => {
    const a = f.attributes || {};
    // Geometry coordinates come in the feature's geometry block if outSR=4326,
    // but we also have explicit lat/lng attributes from this layer.
    const lat = parseFloat(a.y ?? (f.geometry && f.geometry.y));
    const lng = parseFloat(a.x ?? (f.geometry && f.geometry.x));
    if (!isFinite(lat) || !isFinite(lng)) return null;
    return {
      id: `${sourceId}-${a.OBJECTID || a.FID || i}`,
      name: a.CameraLocation || a.ImgPath || 'IL Traffic Camera',
      lat, lng,
      imageUrl: a.SnapShot || null,   // direct JPEG URL, suitable for <img>
      videoUrl: null,                  // Gateway is image-only, no HLS streams
      direction: a.CameraDirection !== 'NONE' ? a.CameraDirection : null,
      source: sourceId,
    };
  }).filter(Boolean);
}

// ── Generic camera-record reader (ArcGIS layers, and feeds like VA SmarterRoads)
// Works out which field is the latitude, longitude, image, video, name and
// direction by name and by value, so a new state's layer usually needs no code.
function _pickField(obj, keyRe, valueTest) {
  let best = null, bestScore = -1;
  for (const [k, v] of Object.entries(obj || {})) {
    if (v == null || v === '') continue;
    let score = keyRe.test(k) ? 2 : 0;
    if (valueTest) { const t = valueTest(v, k); if (t < 0) continue; score += t; }
    if (score > bestScore && score > 0) { best = k; bestScore = score; }
  }
  return best;
}
const _isHttp = (v) => typeof v === 'string' && /^https?:\/\//i.test(v.trim());
function _detectCamFields(sample) {
  const imgTest = (v, k) => {
    if (!_isHttp(v) || /\.m3u8(\?|$)/i.test(v) || /\.(jsp|html?|aspx?|php)(\?|$)/i.test(v)) return -1;
    let t = /\.(jpe?g|png|gif|webp)(\?|$)/i.test(v) ? 3 : 0;
    if (/snap|image|img|still|photo|jpg|cctv|cam/i.test(v)) t += 1;
    if (/snap ?shot/i.test(k)) t += 2;
    return t;
  };
  return {
    // Latitude/longitude fields must be NAMED like one (a small number such as
    // OBJECTID would otherwise pass); without one, the record's map point is used.
    lat: _pickField(sample, /^(lat|latitude|y|lat_dd|ycoord)$/i, (v, k) => (/^(lat|latitude|y|lat_dd|ycoord)$/i.test(k) && Number.isFinite(+v) && Math.abs(+v) <= 90 ? 0.5 : -1)),
    lng: _pickField(sample, /^(lon|lng|long|longitude|x|lon_dd|xcoord)$/i, (v, k) => (/^(lon|lng|long|longitude|x|lon_dd|xcoord)$/i.test(k) && Number.isFinite(+v) && Math.abs(+v) <= 180 ? 0.5 : -1)),
    image: _pickField(sample, /snap ?shot|image|img|still|photo|picture|jpeg|jpg/i, imgTest),
    video: _pickField(sample, /video|stream|hls|m3u8/i, (v) => (_isHttp(v) && /\.m3u8(\?|$)/i.test(v) ? 3 : -1)),
    name: _pickField(sample, /^(name|title|label|descript(ion)?|location|cameralocation|camera_name|cameraname|site|description1)$/i,
                     (v) => (typeof v === 'string' && !_isHttp(v) && v.length >= 3 ? 0.5 : -1)),
    dir: _pickField(sample, /direction|facing|^dir$|cameradirection|heading/i, (v) => (typeof v === 'string' && v.length <= 20 ? 0.2 : -1)),
  };
}
function _recordsToCameras(records, prefix, stateCode) {
  if (!records.length) return [];
  // Detect fields across a few records (the first may have blanks)
  const merged = Object.assign({}, ...records.slice(0, 25).reverse());
  const f = _detectCamFields(merged);
  if (!f.image && !f.video) { console.warn(`[Cameras] ${prefix}: no image or video field found in: ${Object.keys(merged).join(', ')}`); return []; }
  console.log(`[Cameras] ${prefix}: fields → lat=${f.lat || 'geometry'} lng=${f.lng || 'geometry'} image=${f.image} video=${f.video} name=${f.name} dir=${f.dir}`);
  const out = [];
  records.forEach((r, i) => {
    if (String(r.TooOld).toLowerCase() === 'true') return;               // Illinois: image over 30 min old
    // Map point first (always correct for ArcGIS/GeoJSON), then the named fields
    let lat = parseFloat(r.__lat), lng = parseFloat(r.__lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) { lat = parseFloat(f.lat && r[f.lat]); lng = parseFloat(f.lng && r[f.lng]); }
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || (lat === 0 && lng === 0)) return;
    const img = f.image && _isHttp(r[f.image]) ? r[f.image].trim() : null;
    const vid = f.video && _isHttp(r[f.video]) ? r[f.video].trim() : null;
    if (!img && !vid) return;
    out.push({ id: `${prefix}-${r.OBJECTID || r.OBJECTID_1 || r.ID || r.id || i}`, name: String((f.name && r[f.name]) || 'Traffic camera').slice(0, 120),
               lat, lng, imageUrl: img, videoUrl: vid, direction: (f.dir && r[f.dir]) || null, source: stateCode.toLowerCase() });
  });
  return out;
}

// ArcGIS Feature/Map layer → cameras. Accepts a layer URL, or an ArcGIS item id
// (resolved through ArcGIS Online's public catalog — survives service renames).
const _arcgisItemUrl = new Map();
async function _loadArcGISLayer(dot) {
  let layerUrl = dot.arcgisLayer;
  if (!layerUrl && dot.arcgisItem) {
    if (!_arcgisItemUrl.has(dot.arcgisItem)) {
      const it = JSON.parse(await fetchTextOverHttp(`https://www.arcgis.com/sharing/rest/content/items/${dot.arcgisItem}?f=json`));
      if (!it.url) throw new Error(`ArcGIS item ${dot.arcgisItem} has no service URL`);
      _arcgisItemUrl.set(dot.arcgisItem, it.url.replace(/\/+$/, ''));
    }
    const base = _arcgisItemUrl.get(dot.arcgisItem);
    layerUrl = /\/\d+$/.test(base) ? base : `${base}/${dot.arcgisLayerIndex || 0}`;
  }
  const records = [];
  for (let offset = 0, page = 0; page < 20; page++) {
    const q = `${layerUrl}/query?where=1%3D1&outFields=*&returnGeometry=true&outSR=4326&f=json&resultOffset=${offset}&resultRecordCount=1000`;
    const j = JSON.parse(await fetchTextOverHttp(q));
    if (j.error) throw new Error(j.error.message || 'ArcGIS query failed');
    for (const ft of j.features || []) {
      const a = { ...(ft.attributes || {}) };
      if (ft.geometry && Number.isFinite(ft.geometry.x)) { a.__lng = ft.geometry.x; a.__lat = ft.geometry.y; }
      records.push(a);
    }
    if (!j.exceededTransferLimit || !(j.features || []).length) break;
    offset += (j.features || []).length;
  }
  return _recordsToCameras(records, dot.id, dot.id);
}

// Any JSON feed (array, {data:[…]}, GeoJSON) → cameras, with field detection
function _parseGenericCameraJSON(raw, dot) {
  let recs = Array.isArray(raw) ? raw : raw && (raw.features || raw.data || raw.cameras || raw.items || raw.results || []);
  if (!Array.isArray(recs)) recs = [];
  recs = recs.map(r => {
    if (r && r.type === 'Feature') {
      const a = { ...(r.properties || {}) };
      if (r.geometry && Array.isArray(r.geometry.coordinates)) { a.__lng = r.geometry.coordinates[0]; a.__lat = r.geometry.coordinates[1]; }
      return a;
    }
    return r;
  });
  return _recordsToCameras(recs, dot.id, dot.id);
}

async function _loadStateDOT(dot) {
  const cached = _stateDOTCache.get(dot.id);
  if (cached && Date.now() - cached.ts < dot.cacheTTL) return cached.cameras;

  // Custom loaders (ArcGIS layers, key-or-fallback states)
  if (dot.load) {
    let cameras = [];
    try { cameras = await dot.load(dot); console.log(`[Cameras] ${dot.label}: ${cameras.length} cameras loaded`); }
    catch (e) { console.warn(`[Cameras] ${dot.label} failed:`, e.message); }
    _stateDOTCache.set(dot.id, { cameras, ts: Date.now() });
    return cameras;
  }

  // Skip if this DOT requires a key and it's not configured
  if (dot.envKey && !process.env[dot.envKey]) return [];

  let url = dot.url;
  if (dot.envKey && process.env[dot.envKey]) {
    // 511 IBI/Skyline platforms use `key=`, ArcGIS services use `token=`.
    // Each DOT config can specify authParam to override; default is 'key'.
    const paramName = dot.authParam || 'key';
    url += (url.includes('?') ? '&' : '?') + `${paramName}=${encodeURIComponent(process.env[dot.envKey])}`;
  }

  let cameras = [];
  try {
    const text = await fetchTextOverHttp(url);
    const raw = JSON.parse(text);
    cameras = dot.parse(raw, dot.id, dot);
    console.log(`[Cameras] ${dot.label}: ${cameras.length} cameras loaded`);
  } catch (e) {
    console.warn(`[Cameras] ${dot.label} failed:`, e.message);
  }

  _stateDOTCache.set(dot.id, { cameras, ts: Date.now() });
  return cameras;
}

function _haversineM(lat1, lng1, lat2, lng2) {
  const R = 6371000, r = Math.PI / 180;
  const dLat = (lat2 - lat1) * r, dLng = (lng2 - lng1) * r;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

// Full-name → 2-letter code map for OTC state keys
const OTC_STATE_CODES = {
  'Alabama':'AL','Alaska':'AK','Arizona':'AZ','Arkansas':'AR','California':'CA',
  'Colorado':'CO','Connecticut':'CT','Delaware':'DE','Florida':'FL','Georgia':'GA',
  'Hawaii':'HI','Idaho':'ID','Illinois':'IL','Indiana':'IN','Iowa':'IA',
  'Kansas':'KS','Kentucky':'KY','Louisiana':'LA','Maine':'ME','Maryland':'MD',
  'Massachusetts':'MA','Michigan':'MI','Minnesota':'MN','Mississippi':'MS',
  'Missouri':'MO','Montana':'MT','Nebraska':'NE','Nevada':'NV','New Hampshire':'NH',
  'New Jersey':'NJ','New Mexico':'NM','New York':'NY','North Carolina':'NC',
  'North Dakota':'ND','Ohio':'OH','Oklahoma':'OK','Oregon':'OR','Pennsylvania':'PA',
  'Rhode Island':'RI','South Carolina':'SC','South Dakota':'SD','Tennessee':'TN',
  'Texas':'TX','Utah':'UT','Vermont':'VT','Virginia':'VA','Washington':'WA',
  'West Virginia':'WV','Wisconsin':'WI','Wyoming':'WY',
};

async function _loadOTC() {
  if (_otcCache && Date.now() - _otcCacheTime < OTC_TTL) return _otcCache;
  console.log('[Cameras] Fetching OpenTrafficCamMap USA.json…');
  const text = await fetchTextOverHttp(OTC_JSON_URL);
  const raw = JSON.parse(text);
  const cameras = [];

  // OTC has two known schemas:
  // v1/old master: { "Wisconsin": { "county": [{latitude, longitude, url, ...}] } }
  // new master: may be a flat array or restructured — handle gracefully
  const addCam = (cam, stateCode) => {
    // Support both old field names (latitude/longitude) and new (lat/lng or location.*)
    const lat = parseFloat(cam.latitude ?? cam.lat ?? cam.location?.latitude);
    const lng = parseFloat(cam.longitude ?? cam.lng ?? cam.location?.longitude);
    const url = cam.url ?? cam.imageUrl ?? cam.image_url ?? null;
    if (!isFinite(lat) || !isFinite(lng)) return;
    if (Math.abs(lat) < 1 && Math.abs(lng) < 1) return;
    if (!url) return; // skip cameras with no feed URL
    const isHLS = (cam.format ?? '').toUpperCase().includes('M3U');
    cameras.push({
      id: 'otc-' + cameras.length,
      name: cam.description ?? cam.name ?? cam.title ?? 'Traffic Camera',
      lat, lng,
      imageUrl: isHLS ? null : url,
      videoUrl: isHLS ? url : null,
      direction: cam.direction ?? null,
      source: 'otc',
      state: stateCode,
    });
  };

  if (Array.isArray(raw)) {
    // Flat array schema
    raw.forEach(cam => addCam(cam, OTC_STATE_CODES[cam.state] || cam.state || null));
  } else if (typeof raw === 'object') {
    // Nested state→county schema (original format)
    for (const [stateName, counties] of Object.entries(raw)) {
      const stateCode = OTC_STATE_CODES[stateName] || null;
      if (Array.isArray(counties)) {
        counties.forEach(cam => addCam(cam, stateCode));
      } else if (typeof counties === 'object') {
        for (const countyArr of Object.values(counties)) {
          if (Array.isArray(countyArr)) countyArr.forEach(cam => addCam(cam, stateCode));
        }
      }
    }
  }
  _otcCache = cameras;
  _otcCacheTime = Date.now();
  console.log(`[Cameras] OTC loaded: ${cameras.length} cameras`);
  return cameras;
}

async function _loadRoad511(bbox) {
  const key = bbox;
  const cached = _road511Cache.get(key);
  if (cached && Date.now() - cached.ts < ROAD511_TTL) return cached.cameras;

  const apiKey = process.env.ROAD511_API_KEY;
  if (!apiKey) return [];

  const url = `https://api.road511.com/api/v1/features/geojson?type=cameras&bbox=${encodeURIComponent(bbox)}&limit=500`;
  let cameras = [];
  try {
    const text = await fetchTextOverHttp(url, { 'X-API-Key': apiKey });
    const gj = JSON.parse(text);
    cameras = (gj.features || []).map(f => {
      const p = f.properties || {};
      return {
        id: 'r511-' + (p.id || ''),
        name: p.name || 'Traffic Camera',
        lat: f.geometry.coordinates[1],
        lng: f.geometry.coordinates[0],
        imageUrl: p.image_url || null,
        videoUrl: p.video_url || null,
        direction: p.direction || null,
        source: 'road511',
      };
    }).filter(c => isFinite(c.lat) && isFinite(c.lng));
  } catch (e) {
    console.warn('[Cameras] Road511 fetch failed:', e.message);
  }
  _road511Cache.set(key, { cameras, ts: Date.now() });
  return cameras;
}


// ── Windy Webcams Integration ─────────────────────────────────────────────────
// Approximate bounding boxes [N, W, S, E] for all 50 states + DC.
// Used to query Windy's bounding-box API when a user selects a state.
const STATE_BBOX = {
  AL:[35.0,-88.5,30.1,-84.8], AK:[71.5,-168.0,54.5,-130.0],
  AZ:[37.0,-114.8,31.3,-109.0], AR:[36.5,-94.6,33.0,-89.6],
  CA:[42.0,-124.5,32.5,-114.1], CO:[41.0,-109.1,36.9,-102.0],
  CT:[42.1,-73.7,40.9,-71.8],  DE:[39.8,-75.8,38.4,-75.0],
  FL:[31.0,-87.6,24.4,-80.0],  GA:[35.0,-85.6,30.4,-80.8],
  HI:[22.2,-160.2,18.9,-154.8],ID:[49.0,-117.2,41.9,-111.0],
  IL:[42.5,-91.5,36.9,-87.0],  IN:[41.8,-88.1,37.8,-84.7],
  IA:[43.5,-96.6,40.4,-90.1],  KS:[40.0,-102.1,36.9,-94.6],
  KY:[39.1,-89.6,36.5,-81.9],  LA:[33.0,-94.0,28.9,-88.8],
  ME:[47.5,-71.1,43.0,-66.9],  MD:[39.7,-79.5,37.9,-75.0],
  MA:[42.9,-73.5,41.2,-69.9],  MI:[48.3,-90.4,41.7,-82.4],
  MN:[49.4,-97.2,43.5,-89.5],  MS:[35.0,-91.7,30.2,-88.1],
  MO:[40.6,-95.8,35.9,-89.1],  MT:[49.0,-116.0,44.4,-104.0],
  NE:[43.0,-104.1,40.0,-95.3], NV:[42.0,-120.0,35.0,-114.0],
  NH:[45.3,-72.6,42.7,-70.6],  NJ:[41.4,-75.6,38.9,-73.9],
  NM:[37.0,-109.1,31.3,-103.0],NY:[45.0,-79.8,40.5,-71.9],
  NC:[36.6,-84.3,33.8,-75.5],  ND:[49.0,-104.1,45.9,-96.6],
  OH:[42.3,-84.8,38.4,-80.5],  OK:[37.0,-103.0,33.6,-94.4],
  OR:[46.3,-124.6,41.9,-116.5],PA:[42.3,-80.5,39.7,-74.7],
  RI:[42.0,-71.9,41.1,-71.1],  SC:[35.2,-83.4,32.0,-78.5],
  SD:[45.9,-104.1,42.5,-96.4], TN:[36.7,-90.3,34.9,-81.6],
  TX:[36.5,-106.6,25.8,-93.5], UT:[42.0,-114.1,36.9,-109.0],
  VT:[45.0,-73.4,42.7,-71.5],  VA:[39.5,-83.7,36.5,-75.2],
  WA:[49.0,-124.7,45.5,-116.9],WV:[40.6,-82.6,37.2,-77.7],
  WI:[47.1,-92.9,42.5,-86.8],  WY:[45.0,-111.1,40.9,-104.0],
  DC:[39.0,-77.1,38.8,-77.0],
  // Territories — Caribbean coverage for tropical storms
  PR:[18.6,-67.95,17.85,-65.2], VI:[18.45,-65.1,17.65,-64.55],
  // Camera-only regions outside the US (Community Cams) — the whole world is covered
  CAN:[60.0,-141.0,41.6,-52.6], CAR:[27.3,-86.0,10.0,-59.4], MEX:[33.0,-118.0,5.0,-77.0],
  SAM:[13.0,-82.0,-56.0,-34.0], EUR:[72.0,-25.0,34.0,45.0], MEA:[42.0,-20.0,-35.0,63.0],
  ASI:[60.0,45.0,-11.0,150.0], OCE:[0.0,110.0,-50.0,180.0], WLD:[75.0,-180.0,-60.0,180.0],
};
const CAMERA_REGIONS = new Set(['CAN', 'CAR', 'MEX', 'SAM', 'EUR', 'MEA', 'ASI', 'OCE', 'WLD']);

function _windyPlayerUrl(w) {
  const p = w.player || {};
  const pick = (v) => (typeof v === 'string' ? v : (v && typeof v.embed === 'string' ? v.embed : null));
  for (const view of ['live', 'day', 'month', 'year', 'lifetime']) {
    const u = pick(p[view]);
    if (u && /^https:\/\//.test(u) && !u.includes('/we_player/')) return u;   // skip old v2-style links
  }
  return w.webcamId ? `https://webcams.windy.com/webcams/public/embed/player/${w.webcamId}/day` : null;
}

const _windyCache = new Map();
// Camera LOCATIONS barely change, so the list is cached 6 h. The popup uses
// Windy's player embed (doesn't expire); preview images are left out because
// free-tier image tokens expire after 10 min.
const WINDY_TTL = 6 * 60 * 60 * 1000;

async function _loadWindy(stateCode) {
  const key = process.env.WINDY_WEBCAM_KEY;
  if (!key) { console.log('[Cameras] Windy skipped — WINDY_WEBCAM_KEY not set'); return []; }

  const cached = _windyCache.get(stateCode);
  if (cached && Date.now() - cached.ts < WINDY_TTL) {
    console.log(`[Cameras] Windy ${stateCode}: serving ${cached.cameras.length} from cache`);
    return cached.cameras;
  }
  console.log(`[Cameras] Windy ${stateCode}: fetching fresh data...`);

  const bbox = STATE_BBOX[stateCode];
  if (!bbox) return [];
  const [N, W, S, E] = bbox;

  // Windy v3 searches around a point (nearby=lat,lon,radiusKm, max 250 km) and
  // returns the CLOSEST cameras first. One search from the state's center
  // missed every metro more than 250 km out (NYC, Detroit, Dallas, Houston,
  // Las Vegas, Philadelphia…). So the state is covered with a grid of ~2°
  // cells, one search each, and results are merged.
  const CELL = 2.0, MAX_CALLS = 64;
  const cells = [];   // [lat, lng, radiusKm, halfSizeDeg, depth]
  for (let la = S; la < N; la += CELL) {
    for (let lo = W; lo < E; lo += CELL) {
      const cLa = (la + Math.min(la + CELL, N)) / 2, cLo = (lo + Math.min(lo + CELL, E)) / 2;   // center of this (possibly partial) cell
      const hLat = Math.min(CELL, N - la) * 111 / 2, hLng = Math.min(CELL, E - lo) * 111 * Math.cos(cLa * Math.PI / 180) / 2;
      cells.push([cLa, cLo, Math.min(250, Math.ceil(Math.hypot(hLat, hLng)) + 5), CELL / 2, 0]);
    }
  }
  const allCameras = [];
  const seen = new Set();
  let calls = 0;
  // A search that comes back FULL (50) means a dense area (NYC, Miami, LA…) —
  // split it into 4 smaller searches so the city itself gets covered.
  while (cells.length) {
    const [cLa, cLo, radiusKm, half, depth] = cells.shift();
    if (calls >= MAX_CALLS) { console.warn(`[Cameras] Windy ${stateCode}: stopped at ${MAX_CALLS} searches`); break; }
    calls++;
    const url = `https://api.windy.com/webcams/api/v3/webcams`
      + `?nearby=${cLa.toFixed(4)},${cLo.toFixed(4)},${radiusKm}`
      + `&include=location,player&limit=50`;
    try {
      const text = await fetchTextOverHttp(url, { 'x-windy-api-key': key });
      const data = JSON.parse(text);
      const batch = data.webcams || data.data || [];
      if (batch.length >= 50 && depth < 2) {
        const q = half / 2;
        for (const [dy, dx] of [[-q, -q], [-q, q], [q, -q], [q, q]]) {
          const la = cLa + dy, lo = cLo + dx;
          const r = Math.ceil(Math.hypot(q * 111, q * 111 * Math.cos(la * Math.PI / 180))) + 3;
          cells.push([la, lo, r, q, depth + 1]);
        }
      }
      batch.forEach(w => {
        const lat = w.location?.latitude, lng = w.location?.longitude;
        if (!isFinite(lat) || !isFinite(lng) || seen.has(w.webcamId)) return;
        if (lat < S || lat > N || lng < W || lng > E || !_inState(stateCode, lat, lng)) return;   // this state only (real outline)
        seen.add(w.webcamId);
        allCameras.push({
          id: 'windy-' + w.webcamId,
          name: w.title || 'Webcam',
          lat, lng,
          imageUrl: null,
          videoUrl: null,
          playerUrl: _windyPlayerUrl(w),
          windyId: w.webcamId,
          direction: null,
          source: 'windy',
          state: stateCode,
        });
      });
    } catch (e) {
      console.warn(`[Cameras] Windy ${stateCode} cell ${cLa.toFixed(1)},${cLo.toFixed(1)} failed:`, e.message);
    }
    await new Promise(r => setTimeout(r, 120));   // be gentle with Windy's rate limits
  }
  console.log(`[Cameras] Windy ${stateCode}: ${calls} grid searches`);

  _windyCache.set(stateCode, { cameras: allCameras, ts: Date.now() });
  console.log(`[Cameras] Windy ${stateCode}: ${allCameras.length} webcams`);
  return allCameras;
}

// GET /api/cameras/coverage
// Learn camera-proxy allowlist hosts (see camera proxy section below)
// from every camera list this server returns. Must be registered BEFORE the
// /api/cameras routes or it never runs.
// Learn hosts from every camera list this server returns
app.use('/api/cameras', (req, res, next) => {
  const origJson = res.json.bind(res);
  res.json = (body) => { try { _collectCamUrls(body); } catch {} return origJson(body); };
  next();
});

// Returns which state codes have camera data available (used by the client
// to build the state dropdown and mark states as covered vs. unavailable).
// STATE_DOTS states are included if their key is configured (or no key required).
// OTC states are always included since the file is always loaded.
app.get('/api/cameras/coverage', async (req, res) => {
  const covered = new Set();

  // OTC states (always available once the file loads)
  Object.keys(OTC_STATE_CODES).forEach(name => {
    // We'll only mark a state as covered if OTC actually has cameras there
  });
  // Fetch OTC to know which states have entries
  try {
    const otc = await _loadOTC();
    otc.forEach(c => { if (c.state) covered.add(c.state); });
  } catch (e) { /* OTC unavailable, skip */ }

  // STATE_DOTS states: covered if key is configured (or envKey is null = public)
  STATE_DOTS.forEach(dot => {
    if (!dot.envKey || process.env[dot.envKey]) covered.add(dot.id.toUpperCase());
  });

  res.set('Cache-Control', 'public, max-age=300'); // 5 min — coverage rarely changes
  // If Windy key is configured, all 50 states have webcam coverage
  // (Windy is global — every state has at least some cameras indexed)
  if (process.env.WINDY_WEBCAM_KEY) {
    Object.keys(STATE_BBOX).forEach(s => covered.add(s));
  }

  res.json({ covered: [...covered].sort() });
});

// GET /api/cameras/state/:code
// Returns all cameras for a specific US state code (e.g. WI, CA, MN).
// ── Real state outlines (data/us-states.json: 50 states + DC + PR + VI) ──────
// Rectangles overlap neighbours (Georgia's box covers western South Carolina),
// so cameras are placed by the actual outline. Coasts are simplified (~2 km),
// so a camera within 3 km of the state's edge — a beach or harbour cam — counts
// as long as it isn't inside a different state.
let _stateShapes = {};
try { _stateShapes = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'us-states.json'), 'utf8')); }
catch (e) { console.warn('[Cameras] data/us-states.json missing — falling back to rectangles'); }
function _inPolyRing(lat, lng, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, yi] = ring[i], [xj, yj] = ring[j];
    if (((yi > lat) !== (yj > lat)) && (lng < (xj - xi) * (lat - yi) / (yj - yi) + xi)) inside = !inside;
  }
  return inside;
}
function _stateOf(lat, lng) {
  for (const [code, rings] of Object.entries(_stateShapes)) if (rings.some(r => _inPolyRing(lat, lng, r))) return code;
  return null;
}
function _inState(code, lat, lng, edgeMi = 8, allowOtherState = false) {
  const rings = _stateShapes[code];
  if (!rings) {                                          // no outline: use the rectangle
    const bb = STATE_BBOX[code];
    return !bb || (lat <= bb[0] && lat >= bb[2] && lng >= bb[1] && lng <= bb[3]);
  }
  if (rings.some(r => _inPolyRing(lat, lng, r))) return true;
  // Inside a DIFFERENT state → not ours (unless it's this state's own DOT camera
  // just over the line). On the water/coast (no state) → ours if close enough.
  const other = _stateOf(lat, lng);
  if (other && other !== code && !allowOtherState) return false;
  return rings.some(r => _milesToRing(lat, lng, r) <= edgeMi);
}

// ── Cal OES California Webcams (public ArcGIS layer, via FEMA open data) ─────
// Consolidates ALERTCalifornia + ALERTWildfire mountaintop fire cameras (images
// refresh every ~15 s, 60+ mile views — ideal for watching weather come in),
// tsunami cameras and others. Traffic cameras are skipped (Caltrans covers
// those). Cached 30 min; the image links always point at the latest frame.
const CALOES_LAYER = 'https://services.arcgis.com/BLN4oKB0N1YSgvY8/arcgis/rest/services/CalOES_California_Webcams/FeatureServer/0';
let _caloes = { list: null, ts: 0, pending: null };
function _loadCalOES() {
  if (_caloes.list && Date.now() - _caloes.ts < 30 * 60 * 1000) return Promise.resolve(_caloes.list);
  if (_caloes.pending) return _caloes.pending;
  _caloes.pending = (async () => {
    const out = [];
    for (let offset = 0, page = 0; page < 10; page++) {
      const q = `${CALOES_LAYER}/query?where=${encodeURIComponent("CameraType <> 'Traffic'")}&outFields=Location,Source,Source_URL,Display_Type,View_Direction,Webcam_URL,PopUp_URL,NearBy_Place,CameraType,Thumbnail_Url,Camera_ID,OBJECTID`
        + `&returnGeometry=true&outSR=4326&f=json&resultOffset=${offset}&resultRecordCount=2000`;
      const j = JSON.parse(await fetchTextOverHttp(q));
      if (j.error) throw new Error(j.error.message || 'Cal OES query failed');
      for (const f of j.features || []) {
        const a = f.attributes || {}, g = f.geometry || {};
        if (!Number.isFinite(g.x) || !Number.isFinite(g.y)) continue;
        const url = String(a.Webcam_URL || '').trim(), thumb = String(a.Thumbnail_Url || '').trim();
        const isHls = /\.m3u8(\?|$)/i.test(url);
        const isImg = /^https?:\/\//i.test(url) && (/picture/i.test(a.Display_Type || '') || /\.(jpe?g|png|webp)(\?|$)/i.test(url));
        const img = isImg ? url : (/^https?:\/\//i.test(thumb) ? thumb : null);
        if (!isHls && !img) continue;
        out.push({
          id: 'caloes-' + (a.Camera_ID || a.OBJECTID), name: [a.Location, a.NearBy_Place && a.NearBy_Place !== a.Location ? `(${a.NearBy_Place})` : ''].filter(Boolean).join(' '),
          lat: g.y, lng: g.x, imageUrl: isHls ? null : img, videoUrl: isHls ? url : null, direction: a.View_Direction || null,
          source: 'caloes', provider: a.Source || 'Cal OES', pageUrl: a.PopUp_URL || a.Source_URL || null, cameraType: a.CameraType,
        });
      }
      if (!j.exceededTransferLimit || !(j.features || []).length) break;
      offset += (j.features || []).length;
    }
    console.log(`[Cameras] Cal OES: ${out.length} fire/tsunami/other cameras (traffic skipped)`);
    _caloes.list = out; _caloes.ts = Date.now();
    return out;
  })().catch(e => { console.warn('[Cameras] Cal OES failed:', e.message); return _caloes.list || []; })
      .finally(() => { _caloes.pending = null; });
  return _caloes.pending;
}

// ── PennDOT (static images, agreement on file) — data/penndot-cameras.json ──
let _penndot = null;
function _loadPennDOT() {
  if (_penndot) return _penndot;
  try {
    const j = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'penndot-cameras.json'), 'utf8'));
    _penndot = j.cameras.map(c => ({
      id: 'pa-' + c.id, name: c.n + (c.d ? ` (${c.d})` : ''), lat: c.lat, lng: c.lng,
      imageUrl: c.img, videoUrl: null, direction: c.d || null, source: 'pa',
    }));
    console.log(`[Cameras] PennDOT: ${_penndot.length} cameras loaded from data file`);
  } catch (e) { console.warn('[Cameras] PennDOT data file missing:', e.message); _penndot = []; }
  return _penndot;
}

// ── National Park Service webcams (api.data.gov key: GOV_API_KEY) ───────────
// One call returns every NPS webcam nationwide; cached 12 h and filtered per
// state. Many parks are exactly where weather happens: Hawaiʻi Volcanoes,
// Virgin Islands, Everglades, Cape Hatteras, Gulf Islands, Acadia…
const _nps = { list: null, ts: 0, pending: null };
async function _loadNPSAll() {
  const key = process.env.GOV_API_KEY;
  if (!key) return [];
  if (_nps.list && Date.now() - _nps.ts < 12 * 3600 * 1000) return _nps.list;
  if (_nps.pending) return _nps.pending;
  _nps.pending = (async () => {
    const out = [];
    let start = 0, total = Infinity, noCoords = 0, inactive = 0;
    while (start < total && start < 2000) {
      const j = JSON.parse(await fetchTextOverHttp(
        `https://developer.nps.gov/api/v1/webcams?limit=500&start=${start}`, { 'X-Api-Key': key }));
      const data = j.data || [];
      if (start === 0) console.log(`[Cameras] NPS: ${j.total} webcams listed; fields: ${Object.keys(data[0] || {}).join(',')}`);
      total = Number(j.total) || data.length;
      for (const w of data) {
        if (w.status && /inactive|offline|disabled/i.test(w.status)) { inactive++; continue; }
        const lat = parseFloat(w.latitude), lng = parseFloat(w.longitude);
        if (!isFinite(lat) || !isFinite(lng) || (lat === 0 && lng === 0)) { noCoords++; continue; }
        const parks = w.relatedParks || [];
        const states = [...new Set(parks.flatMap(pk => String(pk.states || '').split(',').map(x => x.trim().toUpperCase())).filter(Boolean))];
        const img = (w.images || []).map(i => i && i.url).find(u => /^https?:\/\//.test(u || ''));
        out.push({
          id: 'nps-' + w.id, name: w.title || 'Park webcam', lat, lng,
          imageUrl: img || null, videoUrl: null, direction: null, source: 'nps',
          pageUrl: w.url || null, isStreaming: !!w.isStreaming,
          statusMessage: (w.statusMessage || '').trim() || null,
          parkName: parks[0] && parks[0].fullName, states,
        });
      }
      if (!data.length) break;
      start += data.length;
    }
    console.log(`[Cameras] NPS: ${out.length} usable (${noCoords} without coordinates, ${inactive} inactive)`);
    _nps.list = out; _nps.ts = Date.now();
    return out;
  })().catch(e => { console.warn('[Cameras] NPS failed:', e.message); return _nps.list || []; })
      .finally(() => { _nps.pending = null; });
  return _nps.pending;
}
// Many NPS webcam entries have no image in the API — the live picture is only
// on the camera's nps.gov page. Read that page (public government content)
// once per 12 h and take either the embedded YouTube stream (plays inside our
// popup) or the webcam image. Cameras where neither is found keep the link.
const _npsPage = new Map();   // id -> { ts, imageUrl, playerUrl }
async function _enrichNPS(cam) {
  const hit = _npsPage.get(cam.id);
  if (hit && Date.now() - hit.ts < 12 * 3600 * 1000) return hit;
  const found = { ts: Date.now(), imageUrl: null, playerUrl: null };
  try {
    const u = new URL(cam.pageUrl);
    if (!/(^|\.)nps\.gov$/i.test(u.hostname)) throw new Error('not nps.gov');
    const html = await fetchTextOverHttp(cam.pageUrl);
    const yt = html.match(/youtube(?:-nocookie)?\.com\/embed\/([A-Za-z0-9_-]{11})/) || html.match(/youtu\.be\/([A-Za-z0-9_-]{11})/)
            || html.match(/youtube\.com\/watch\?v=([A-Za-z0-9_-]{11})/);
    if (yt) found.playerUrl = `https://www.youtube-nocookie.com/embed/${yt[1]}?autoplay=1&mute=1&playsinline=1`;
    // NPS serves every park's live image from /webcams-{park}/… on nps.gov
    // (e.g. /webcams-hale/HaleSummitCamCrater.jpg). The page inserts it with
    // a script, so look for that address pattern anywhere in the page rather
    // than in <img> tags (which only held a broken placeholder).
    const m = html.match(/(?:https?:\/\/(?:www\.)?nps\.gov)?\/webcams-[a-z0-9]+\/[^"'\s<>\\)]+?\.(?:jpe?g|png|gif|webp)/i);
    if (m) found.imageUrl = new URL(m[0], 'https://www.nps.gov').href;
    else {
      // Other hosts sometimes carry the image (e.g. a USGS camera shown on a park page)
      const ext = html.match(/https:\/\/[a-z0-9.-]+\.(?:gov|edu)\/[^"'\s<>]*(?:webcam|cams?)\/[^"'\s<>]+?\.(?:jpe?g|png|gif)/i);
      if (ext) found.imageUrl = ext[0];
    }
  } catch (e) { /* keep the link-only fallback */ }
  _npsPage.set(cam.id, found);
  return found;
}
async function _loadNPS(code) {
  const all = await _loadNPSAll();
  const list = all.filter(c => c.states.includes(code) || (!c.states.length && _inState(code, c.lat, c.lng)));
  // Check EVERY camera's nps.gov page for its LIVE image or stream. The API's
  // own "images" are often representative park photos, not the camera view,
  // so they're only a last resort. 4 pages at a time within ~10 s; results are
  // cached 12 h, so later visits are instant and fill in anything missed.
  const need = list.filter(c => c.pageUrl && !c._checked);
  const deadline = Date.now() + 10000;
  for (let i = 0; i < need.length && Date.now() < deadline; i += 4) {
    await Promise.all(need.slice(i, i + 4).map(async (c) => {
      const f = await _enrichNPS(c);
      c._checked = true;
      if (f.playerUrl) { c.playerUrl = f.playerUrl; c.imageUrl = null; c.live = true; }
      else if (f.imageUrl) { c.imageUrl = f.imageUrl; c.live = true; }
      else if (c.imageUrl) { c.imageUrl = null; c.photoOnly = true; }   // only a park photo — not a live view
    }));
  }
  const viewable = list.filter(c => c.live);
  const pending = list.filter(c => !c._checked).length;
  console.log(`[Cameras] NPS ${code}: ${viewable.length}/${list.length} have a live image or stream` +
    (pending ? ` (${pending} still to check — shown on a later visit)` : '') +
    `; ${list.filter(c => c._checked && !c.live).length} hidden (no live view on their NPS page)`);
  // A dot you can't view is just frustrating — only show cameras with a live picture or stream
  return viewable;
}

// ── USGS Hawaiian Volcano Observatory webcams (public domain, no key) ───────
// Still images that refresh every few minutes. Checked on first use (and
// every 6 h): only cameras that actually return an image are shown, and any
// that don't are logged so the list can be updated.
const USGS_HVO_CAMS = [
  ['V1cam', 'Kīlauea — west Halemaʻumaʻu', 19.4085, -155.2890],
  ['V2cam', 'Kīlauea — east Halemaʻumaʻu', 19.4105, -155.2740],
  ['V3cam', 'Kīlauea — south Halemaʻumaʻu', 19.4000, -155.2820],
  ['KWcam', 'Kīlauea caldera — west rim panorama', 19.4100, -155.2905],
  ['F1cam', 'Kīlauea caldera — thermal (west rim)', 19.4098, -155.2908],
  ['B1cam', 'Kīlauea caldera — down-dropped block', 19.4080, -155.2680],
  ['K2cam', 'Kīlauea caldera from Uēkahuna bluff', 19.4205, -155.2880],
  ['MKcam', 'Mauna Loa from Mauna Kea', 19.8230, -155.4700],
  ['MSTcam', 'Mauna Loa summit — thermal (south rim)', 19.4600, -155.5950],
  ['S1cam', 'Kīlauea upper Southwest Rift Zone', 19.3700, -155.3000],
  ['S2cam', 'Halemaʻumaʻu from the south rim', 19.3950, -155.2830],
  ['MITDcam', 'Kīlauea Southwest Rift Zone from the Kaʻū Desert', 19.3300, -155.3600],
  ['B2cam', 'Halemaʻumaʻu from the east rim', 19.4070, -155.2670],
  ['KOcam', 'Kīlauea upper East Rift Zone from Maunaulu', 19.3600, -155.2100],
  ['MUcam', 'Maunaulu', 19.3630, -155.2150],
  ['PWcam', 'Puʻuʻōʻō west flank', 19.3870, -155.1070],
];
const _usgs = { list: null, ts: 0, pending: null };
async function _loadUSGS() {
  if (_usgs.list && Date.now() - _usgs.ts < 6 * 3600 * 1000) return _usgs.list;
  if (_usgs.pending) return _usgs.pending;
  _usgs.pending = (async () => {
    const checks = await Promise.all(USGS_HVO_CAMS.map(async ([id, name, lat, lng]) => {
      const imageUrl = `https://volcanoes.usgs.gov/observatories/hvo/cams/${id}/images/M.jpg`;
      try {
        const r = await _fetchBinary(imageUrl, { maxBytes: 8 * 1024 * 1024, timeoutMs: 12000 });
        if (r.status !== 200 || !/image/i.test(r.ct)) throw new Error(`HTTP ${r.status} ${r.ct}`);
        // An image that hasn't changed in over a day isn't a live camera any more
        const age = r.lastModified ? Date.now() - Date.parse(r.lastModified) : 0;
        if (age > 24 * 3600 * 1000) throw new Error(`image not updated since ${r.lastModified}`);
        return { id: 'usgs-' + id, name: `${name} (${id})`, lat, lng, imageUrl, videoUrl: null, direction: null,
                 source: 'usgs', pageUrl: `https://www.usgs.gov/observatories/hvo/multimedia/webcams?cam=${id}`, state: 'HI' };
      } catch (e) { console.warn(`[Cameras] USGS ${id} unavailable: ${e.message}`); return null; }
    }));
    const list = checks.filter(Boolean);
    console.log(`[Cameras] USGS HVO: ${list.length}/${USGS_HVO_CAMS.length} webcams responding`);
    _usgs.list = list; _usgs.ts = Date.now();
    return list;
  })().finally(() => { _usgs.pending = null; });
  return _usgs.pending;
}

// ── Community Cams (community-cams.js) ──────────────────────────────────────
function _stateForPoint(lat, lng) {
  const inside = _stateOf(lat, lng);
  if (inside) return inside;
  // On the water / a beach: nearest state outline within ~8 miles
  const near = Object.keys(_stateShapes).find(code => _inState(code, lat, lng, 8));
  if (near) return near;
  // Outside the US: a world region (order matters where boxes overlap)
  if (lat >= 10 && lat <= 27.3 && lng >= -86 && lng <= -59.4) return 'CAR';   // Caribbean
  if (lat >= 5 && lat <= 33 && lng >= -118 && lng <= -77) return 'MEX';       // Mexico & Central America
  if (lat >= 41.6 && lat <= 84 && lng >= -141 && lng <= -52) return 'CAN';    // Canada
  if (lat >= -56 && lat <= 13 && lng >= -82 && lng <= -34) return 'SAM';      // South America
  if (lat >= 34 && lat <= 72 && lng >= -32 && lng <= 45) return 'EUR';        // Europe (incl. Iceland, Turkey)
  if (lat >= -35 && lat <= 42 && lng >= -20 && lng <= 63) return 'MEA';       // Middle East & Africa
  if (lat >= -11 && lat <= 78 && lng >= 45 && lng <= 180) return 'ASI';       // Asia
  if ((lat >= -50 && lat <= 0 && lng >= 110) || (lat >= -30 && lat <= 30 && (lng >= 150 || lng <= -130))) return 'OCE';   // Oceania & Pacific
  return 'WLD';                                                               // anywhere else
}
const community = require('./community-cams')(app, {
  rGet, rSet, fetchTextOverHttp, youtubeKey: process.env.YOUTUBE_API_KEY, stateFor: _stateForPoint, upstreamCount,
});

// WeatherStar "Airport Conditions" + "Departures" data (airports.js).
// Departures need AIRLABS_KEY; airport weather + FAA delays are free.
require('./airports')(app, { rGet, rSet });

// Replaces the old bbox-based endpoint — state-level loading is far more
// performant than loading thousands of cameras across the whole country
// and filtering by viewport on every pan/zoom. Users select the state they
// want to monitor (typically where a storm is active) and see only those
// cameras, which loads fast and doesn't lock up the map.
app.get('/api/cameras/state/:code', async (req, res) => {
  const code = req.params.code.toUpperCase().replace(/[^A-Z]/g, '');
  const REGION = CAMERA_REGIONS.has(code);   // world regions — Community Cams only
  if (code.length !== 2 && !REGION) return res.status(400).json({ error: 'Invalid state code' });

  try {
    // Find the STATE_DOTS entry for this state, if we have one
    const dot = STATE_DOTS.find(d => d.id.toUpperCase() === code);

    const [otcAll, stateDOTraw, windyCams, npsCams, usgsCams, communityCams, calOesCams] = await Promise.all([
      _loadOTC().catch(() => []),
      dot ? _loadStateDOT(dot).catch(() => []) : Promise.resolve([]),
      REGION ? Promise.resolve([]) : _loadWindy(code).catch(() => []),   // too large to grid-search
      REGION ? Promise.resolve([]) : _loadNPS(code).catch(() => []),
      code === 'HI' ? _loadUSGS().catch(() => []) : Promise.resolve([]),
      community.forState(code).catch(() => []),
      REGION ? Promise.resolve([]) : _loadCalOES().then(l => l.filter(c => _inState(code, c.lat, c.lng, 2))).catch(() => []),
    ]);

    // Drop cameras with impossible coordinates (0,0, swapped lat/lng…). One bad
    // Georgia camera made the map zoom out to the whole world. DOT cameras may
    // sit just over a border, so they get ~25 miles of slack.
    const stateDOT = [...stateDOTraw, ...(code === 'PA' ? _loadPennDOT() : [])]
      .filter(c => _inState(code, c.lat, c.lng, 25, true));
    if (stateDOTraw.length && stateDOT.length < stateDOTraw.length) {
      console.log(`[Cameras] ${code}: dropped ${stateDOTraw.length - stateDOT.length} DOT cameras with coordinates outside the state`);
    }

    // Filter OTC to this state
    const otcForState = otcAll.filter(c => c.state === code);

    // Merge priority: STATE_DOTS (traffic) → OTC → Windy (scenic/weather).
    // Deduplicate at 100m so we don't show two cameras from different sources
    // that are essentially at the same location.
    const merged = [...stateDOT];
    for (const cam of [...communityCams, ...usgsCams, ...calOesCams, ...npsCams, ...otcForState, ...windyCams]) {
      const tooClose = merged.some(r => _haversineM(cam.lat, cam.lng, r.lat, r.lng) < 100);
      if (!tooClose) merged.push(cam);
    }

    if (merged.length === 0) {
      return res.json({ cameras: [], total: 0, covered: false,
        message: `No camera feeds available for ${code} yet.` });
    }

    const sourceCounts = {};
    merged.forEach(c => { sourceCounts[c.source] = (sourceCounts[c.source] || 0) + 1; });

    res.set('Cache-Control', 'no-store');
    const bb = STATE_BBOX[code];
    res.json({ cameras: merged, total: merged.length, covered: true, sources: sourceCounts,
               bounds: bb ? [[bb[2], bb[1]], [bb[0], bb[3]]] : null });
  } catch (e) {
    console.error(`[Cameras] State ${code} failed:`, e.message);
    res.status(500).json({ error: 'Camera data unavailable' });
  }
});

// GET /api/aqi?lat=&lng=
// Server-side proxy for AirNow API — keeps AIRNOW_KEY out of client JS.
// Returns current AQI observations within 250 miles of the given lat/lng.
// Cached 30 minutes (AirNow data updates hourly; 30min balances freshness
// vs quota). Set AIRNOW_KEY in Railway environment variables.
const _aqiCache = new Map();
const AQI_TTL = 30 * 60 * 1000;

app.get('/api/aqi', async (req, res) => {
  const key = process.env.AIRNOW_KEY;
  if (!key) return res.status(503).json({ error: 'AirNow API key not configured' });

  // Accept bounding box (preferred — covers the visible map area) or lat/lng fallback
  const hasBbox = req.query.south && req.query.west && req.query.north && req.query.east;
  const south = parseFloat(req.query.south), west  = parseFloat(req.query.west);
  const north = parseFloat(req.query.north), east  = parseFloat(req.query.east);
  const lat   = parseFloat(req.query.lat),   lng   = parseFloat(req.query.lng);

  if (hasBbox && [south,west,north,east].some(isNaN)) return res.status(400).json({ error: 'invalid bbox' });
  if (!hasBbox && (isNaN(lat) || isNaN(lng))) return res.status(400).json({ error: 'lat/lng or bbox required' });

  const cacheKey = hasBbox
    ? `bbox:${south.toFixed(1)},${west.toFixed(1)},${north.toFixed(1)},${east.toFixed(1)}`
    : `${lat.toFixed(2)},${lng.toFixed(2)}`;
  const cached = _aqiCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < AQI_TTL) {
    res.set('Cache-Control', 'public, max-age=1800');
    return res.json(cached.data);
  }

  try {
    // Bounding box endpoint returns all stations within the viewport — much better for national view
    const url = hasBbox
      ? `https://www.airnowapi.org/aq/data/?parameters=PM25,OZONE&BBOX=${west.toFixed(4)},${south.toFixed(4)},${east.toFixed(4)},${north.toFixed(4)}&dataType=A&format=application/json&verbose=1&monitorType=0&includerawconcentrations=0&API_KEY=${key}`
      : `https://www.airnowapi.org/aq/observation/latLong/current/?format=application/json&latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}&distance=250&API_KEY=${key}`;
    const response = await fetch(url, { headers: { 'User-Agent': 'WeatherTV/1.0 (+https://watchweathertv.com)' } });
    if (!response.ok) throw new Error(`AirNow returned ${response.status}`);
    const data = await response.json();
    _aqiCache.set(cacheKey, { data, ts: Date.now() });
    if (_aqiCache.size > 50) {
      const oldest = [..._aqiCache.entries()].sort((a, b) => a[1].ts - b[1].ts)[0];
      if (oldest) _aqiCache.delete(oldest[0]);
    }
    res.set('Cache-Control', 'public, max-age=1800');
    res.json(data);
  } catch(e) {
    console.error('[AQI] Proxy error:', e.message);
    res.status(502).json({ error: 'AirNow unavailable', detail: e.message });
  }
});

// ── Geographic name restoration ──────────────────────────────────────────────
// Federal renaming mandates don't belong in weather safety information.
// Restores traditional geographic names in all NWS text before it reaches
// users. When federal systems revert, these replacements become no-ops.
function restoreGeographicNames(text) {
  if (!text || typeof text !== 'string') return text;
  return text
    .replace(/Gulf of America/gi,     'Gulf of Mexico')
    .replace(/America's Gulf/gi,     'Gulf of Mexico')
    .replace(/the Gulf of America/gi, 'the Gulf of Mexico')
    .replace(/Lake America/gi,        'Lake Ontario')
    .replace(/Mount McKinley/gi,      'Denali'); // restore if reverted
}

// GET /api/forecast?lat=&lon= (or ?zip=)
// Merges Open-Meteo (current + 168h hourly + 7-day daily) + NWS narrative.
//
// SCALE DESIGN (Sep 2026): Open-Meteo's free tier is ~10,000 calls/day,
// non-commercial. Upstream calls must scale with PLACES, not USERS:
//   - Coordinates snap to a shared grid cell (default 0.05° ≈ 5 km; set
//     FORECAST_GRID_DEG to tune). Everyone in the same cell shares ONE cached
//     forecast — Open-Meteo's models are 3–13 km anyway, so neighbors within
//     a cell would get near-identical data. Old key was 0.001° (~110 m), which
//     made nearly every user a cache miss.
//   - 15-min TTL (Open-Meteo's own "current" data refreshes every 15 min, so
//     users see no staler data than before).
//   - Single-flight: 50 simultaneous misses for one cell = 1 upstream call.
//   - LRU cache of 1,000 cells (was 30) with O(1) eviction.
//   - Stale-if-error: if Open-Meteo fails or rate-limits us, serve the last
//     good forecast for that cell (up to 3h old) instead of an error.
//   - Zip→coords cached 30 days; NWS /points lookup cached 24h (the forecast
//     office/grid for a location never changes), halving NWS calls per miss.
//   - Daily upstream call counters at GET /api/admin/upstream-usage.
const _forecastCache = new Map();          // cellKey -> { data, ts }   (insertion order = LRU)
const _forecastInflight = new Map();       // cellKey -> Promise
const FORECAST_TTL = 15 * 60 * 1000;
const FORECAST_STALE_MAX = 3 * 60 * 60 * 1000;
const FORECAST_MAX = 1000;
const FORECAST_GRID = Number(process.env.FORECAST_GRID_DEG) || 0.05;
const _geoCache = new Map();               // zip/query -> { lat, lon, name, ts }
const GEO_TTL = 30 * 24 * 60 * 60 * 1000;
const _nwsPointsCache = new Map();         // cellKey -> { forecastUrl, ts }
const NWS_POINTS_TTL = 24 * 60 * 60 * 1000;

// ── Upstream usage counters (reset daily, UTC) ──
const _upstream = { day: null };
function upstreamCount(name, n = 1) {
  const today = new Date().toISOString().slice(0, 10);
  if (_upstream.day !== today) { for (const k of Object.keys(_upstream)) delete _upstream[k]; _upstream.day = today; }
  _upstream[name] = (_upstream[name] || 0) + n;
}

function _lruSet(map, key, value, max) {
  map.delete(key);
  map.set(key, value);
  while (map.size > max) map.delete(map.keys().next().value);
}

function _snap(v) { return Math.round(v / FORECAST_GRID) * FORECAST_GRID; }

async function _fetchForecastCell(gLat, gLon, cellKey) {
  const omUrl = 'https://api.open-meteo.com/v1/forecast'
    + `?latitude=${gLat.toFixed(4)}&longitude=${gLon.toFixed(4)}`
    + '&timezone=auto&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch'
    + '&current=temperature_2m,apparent_temperature,relative_humidity_2m,dew_point_2m,'
    + 'precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,'
    + 'wind_gusts_10m,surface_pressure,visibility,is_day'
    + '&hourly=temperature_2m,apparent_temperature,precipitation_probability,precipitation,'
    + 'weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,wind_gusts_10m,'
    + 'visibility,cape,lifted_index,freezing_level_height,snowfall,snow_depth,'
    + 'uv_index,is_day,relative_humidity_2m,dew_point_2m'
    + '&daily=weather_code,temperature_2m_max,temperature_2m_min,'
    + 'apparent_temperature_max,apparent_temperature_min,'
    + 'sunrise,sunset,daylight_duration,uv_index_max,'
    + 'precipitation_sum,snowfall_sum,precipitation_hours,'
    + 'precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,'
    + 'wind_direction_10m_dominant'
    + '&forecast_days=7';


  upstreamCount('openMeteoForecast');
  const omText = await fetchTextOverHttp(omUrl);
  const om = JSON.parse(omText);
  if (om.error) throw new Error(`Open-Meteo: ${om.reason || om.error}`);

  let nwsNarrative = null;
  try {
    const NWS_HEADERS = { Accept: 'application/geo+json', 'User-Agent': 'WeatherTV/1.0 (+https://watchweathertv.com)' };
    let forecastUrl;
    const pc = _nwsPointsCache.get(cellKey);
    if (pc && Date.now() - pc.ts < NWS_POINTS_TTL) {
      forecastUrl = pc.forecastUrl;
    } else {
      upstreamCount('nwsPoints');
      const pts = JSON.parse(await fetchTextOverHttp(`https://api.weather.gov/points/${gLat.toFixed(4)},${gLon.toFixed(4)}`, NWS_HEADERS));
      forecastUrl = pts?.properties?.forecast || null;
      _lruSet(_nwsPointsCache, cellKey, { forecastUrl, ts: Date.now() }, 5000);
    }
    if (forecastUrl) {
      upstreamCount('nwsForecast');
      const f = JSON.parse(await fetchTextOverHttp(forecastUrl, NWS_HEADERS));
      nwsNarrative = (f?.properties?.periods || []).slice(0, 14).map(p => ({
        name:      restoreGeographicNames(p.name),
        short:     restoreGeographicNames(p.shortForecast),
        detail:    restoreGeographicNames(p.detailedForecast),
        isDaytime: p.isDaytime, temp: p.temperature, icon: p.icon,
      }));
    }
  } catch(e) { /* NWS unavailable outside CONUS — silent fail */ }

  // Location is attached per-request (below), so a shared cell never
  // shows one user's place name to another user.
  return {
    timezone: om.timezone, timezone_abbreviation: om.timezone_abbreviation,
    utc_offset_seconds: om.utc_offset_seconds,
    current: om.current, current_units: om.current_units,
    hourly: om.hourly, hourly_units: om.hourly_units,
    daily: om.daily, daily_units: om.daily_units,
    nws: nwsNarrative, generated_at: Date.now(),
  };
}

app.get('/api/forecast', async (req, res) => {
  let lat = parseFloat(req.query.lat);
  let lon = parseFloat(req.query.lon);
  let locationName = req.query.name || null;

  if (req.query.zip) {
    const q = req.query.zip.trim().toLowerCase();
    const g = _geoCache.get(q);
    if (g && Date.now() - g.ts < GEO_TTL) {
      upstreamCount('geocodeHit');
      lat = g.lat; lon = g.lon; locationName = locationName || g.name;
    } else {
      try {
        upstreamCount('openMeteoGeocode');
        const geoText = await fetchTextOverHttp(
          `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(req.query.zip.trim())}&count=1&language=en&format=json`
        );
        const geo = JSON.parse(geoText);
        const r = geo.results?.[0];
        if (!r) return res.status(404).json({ error: `No location found for "${req.query.zip}"` });
        lat = r.latitude; lon = r.longitude;
        const name = restoreGeographicNames([r.name, r.admin1].filter(Boolean).join(', '));
        _lruSet(_geoCache, q, { lat, lon, name, ts: Date.now() }, 5000);
        locationName = locationName ? restoreGeographicNames(locationName) : name;
      } catch(e) { return res.status(502).json({ error: 'Geocoding unavailable', detail: e.message }); }
    }
  }

  if (isNaN(lat) || isNaN(lon)) return res.status(400).json({ error: 'lat/lon or zip required' });

  const gLat = _snap(lat), gLon = _snap(lon);
  const cellKey = `${gLat.toFixed(3)},${gLon.toFixed(3)}`;
  const respond = (entry, stale) => {
    res.set('Cache-Control', stale ? 'public, max-age=120' : 'public, max-age=900');
    if (stale) res.set('X-Forecast-Stale', '1');
    res.json({ ...entry.data, location: { lat, lon, name: locationName } });
  };

  const cached = _forecastCache.get(cellKey);
  if (cached && Date.now() - cached.ts < FORECAST_TTL) {
    upstreamCount('forecastCacheHit');
    _lruSet(_forecastCache, cellKey, cached, FORECAST_MAX); // refresh LRU position
    return respond(cached, false);
  }

  try {
    let p = _forecastInflight.get(cellKey);
    if (!p) {
      upstreamCount('forecastCacheMiss');
      p = _fetchForecastCell(gLat, gLon, cellKey)
        .then(data => { const entry = { data, ts: Date.now() }; _lruSet(_forecastCache, cellKey, entry, FORECAST_MAX); return entry; })
        .finally(() => _forecastInflight.delete(cellKey));
      _forecastInflight.set(cellKey, p);
    } else {
      upstreamCount('forecastCoalesced');
    }
    respond(await p, false);
  } catch(e) {
    if (cached && Date.now() - cached.ts < FORECAST_STALE_MAX) {
      upstreamCount('forecastStaleServed');
      console.warn('[Forecast] Upstream failed, serving stale cell', cellKey, '-', e.message);
      return respond(cached, true);
    }
    console.error('[Forecast] Error:', e.message);
    res.status(502).json({ error: 'Forecast unavailable', detail: e.message });
  }
});

// GET /api/forecast/models?lat=&lon=
// Same spot, eight forecast models side by side (Open-Meteo multi-model).
// Shares the forecast grid cells (~5 km), cached 60 min — models only update
// every 6–12 h, so this costs a handful of upstream calls per place per day.
// Only requested when a user opens "Compare models", never on page load.
const MM_MODELS = [
  ['ecmwf_ifs025', 'ECMWF (Euro)'], ['ecmwf_aifs025_single', 'ECMWF AI (AIFS)'],
  ['gfs_seamless', 'GFS (US)'], ['icon_seamless', 'ICON (Germany)'],
  ['gem_seamless', 'GEM (Canada)'], ['ukmo_seamless', 'UK Met Office'],
  ['jma_seamless', 'JMA (Japan)'], ['meteofrance_seamless', 'Météo-France'],
];
const _mmCache = new Map();
const _mmInflight = new Map();
const MM_TTL = 60 * 60 * 1000;

async function _fetchModelCompare(gLat, gLon, ids) {
  const url = 'https://api.open-meteo.com/v1/forecast'
    + `?latitude=${gLat.toFixed(4)}&longitude=${gLon.toFixed(4)}`
    + '&timezone=auto&temperature_unit=fahrenheit&precipitation_unit=inch&forecast_days=7'
    + '&hourly=temperature_2m,precipitation&daily=temperature_2m_max,temperature_2m_min,precipitation_sum'
    + `&models=${ids.join(',')}`;
  upstreamCount('openMeteoModels');
  const j = JSON.parse(await fetchTextOverHttp(url));
  if (j.error) {
    // If Open-Meteo rejects a model id (renamed/retired), drop it and retry once
    const bad = ids.filter(id => String(j.reason || '').includes(id));
    if (bad.length && bad.length < ids.length) return _fetchModelCompare(gLat, gLon, ids.filter(id => !bad.includes(id)));
    throw new Error(`Open-Meteo: ${j.reason || j.error}`);
  }
  const h = j.hourly || {}, d = j.daily || {};
  const models = MM_MODELS.filter(([id]) => ids.includes(id)).map(([id, label]) => ({
    id, label,
    hourly: { temp: h[`temperature_2m_${id}`] || null, precip: h[`precipitation_${id}`] || null },
    daily: { max: d[`temperature_2m_max_${id}`] || null, min: d[`temperature_2m_min_${id}`] || null, precip: d[`precipitation_sum_${id}`] || null },
  })).filter(m => Array.isArray(m.hourly.temp) && m.hourly.temp.some(v => v != null));
  return { utc_offset_seconds: j.utc_offset_seconds || 0, timezone: j.timezone, hourlyTime: h.time || [], dailyTime: d.time || [], models, generated_at: Date.now() };
}

app.get('/api/forecast/models', async (req, res) => {
  const lat = parseFloat(req.query.lat), lon = parseFloat(req.query.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return res.status(400).json({ error: 'lat/lon required' });
  }
  const gLat = _snap(lat), gLon = _snap(lon);
  const key = `${gLat.toFixed(3)},${gLon.toFixed(3)}`;
  const hit = _mmCache.get(key);
  if (hit && Date.now() - hit.ts < MM_TTL) {
    res.set('Cache-Control', 'public, max-age=1800');
    return res.json(hit.data);
  }
  try {
    let p = _mmInflight.get(key);
    if (!p) {
      p = _fetchModelCompare(gLat, gLon, MM_MODELS.map(([id]) => id))
        .then(data => { _lruSet(_mmCache, key, { data, ts: Date.now() }, 500); return data; })
        .finally(() => _mmInflight.delete(key));
      _mmInflight.set(key, p);
    }
    const data = await p;
    res.set('Cache-Control', 'public, max-age=1800');
    res.json(data);
  } catch (e) {
    if (hit) return res.json({ ...hit.data, stale: true });
    console.warn('[ModelCompare]', e.message);
    res.status(502).json({ error: 'Model comparison unavailable' });
  }
});

// GET /api/hms-smoke
// Proxies NOAA OSPO's current HMS smoke KML and converts it to GeoJSON.
// NOAA does NOT publish a GeoJSON format — only KML, Shapefile, and GeoTiff.
// The OSPO KML at ospo.noaa.gov/data/land/fire/smoke.kml is a live-updating
// file with today's smoke polygons. Cached 2 hours.
const _hmsSmokeCache = { data: null, ts: 0 };
const HMS_TTL = 2 * 60 * 60 * 1000;
const HMS_KML_URL = 'https://www.ospo.noaa.gov/Products/land/hms/data/latest_smoke_final.kml';

function parseHMSKML(kml) {
  const features = [];
  const blocks = kml.match(/<Placemark[\s\S]*?<\/Placemark>/g) || [];
  blocks.forEach(block => {
    // Density from styleUrl (#Smoke_Light / #Smoke_Medium / #Smoke_Heavy)
    const styleUrl = (block.match(/<styleUrl>#?([^<]+)<\/styleUrl>/) || [])[1] || '';
    let density = 'Light';
    if (/medium/i.test(styleUrl)) density = 'Medium';
    if (/heavy|thick/i.test(styleUrl)) density = 'Heavy';

    // Parse outer ring coordinates
    const coordsMatch = block.match(/<coordinates>([\s\S]*?)<\/coordinates>/);
    if (!coordsMatch) return;
    const ring = coordsMatch[1].trim().split(/\s+/)
      .map(t => { const p = t.split(',').map(Number); return p; })
      .filter(p => p.length >= 2 && !isNaN(p[0]) && !isNaN(p[1]))
      .map(p => [p[0], p[1]]);
    if (ring.length < 3) return;

    features.push({
      type: 'Feature',
      geometry: { type: 'Polygon', coordinates: [ring] },
      properties: { Density: density },
    });
  });
  return { type: 'FeatureCollection', features };
}

app.get('/api/hms-smoke', async (req, res) => {
  if (_hmsSmokeCache.data && Date.now() - _hmsSmokeCache.ts < HMS_TTL) {
    res.set('Content-Type', 'application/json');
    res.set('Cache-Control', 'public, max-age=7200');
    return res.json(_hmsSmokeCache.data);
  }
  try {
    const kml = await fetchTextOverHttp(HMS_KML_URL);
    if (!/<kml[\s>]/i.test(kml)) throw new Error('Response is not KML');
    // A valid KML with no Placemarks just means no smoke has been analyzed yet
    // (common early in the UTC day, and on smoke-free days) — that's an empty
    // map, not an error. Cache "no smoke" briefly so new analyses show up soon.
    const geojson = parseHMSKML(kml);
    _hmsSmokeCache.data = geojson;
    _hmsSmokeCache.ts = geojson.features.length ? Date.now() : Date.now() - HMS_TTL + 20 * 60 * 1000;
    console.log(`[HMS Smoke] Loaded ${geojson.features.length} smoke polygons from OSPO KML`);
    res.set('Content-Type', 'application/json');
    res.set('Cache-Control', 'public, max-age=7200');
    res.json(geojson);
  } catch(e) {
    console.warn('[HMS Smoke] KML proxy failed:', e.message);
    if (_hmsSmokeCache.data) return res.json(_hmsSmokeCache.data); // serve stale on error
    res.status(502).json({ error: 'HMS smoke unavailable', type: 'FeatureCollection', features: [] });
  }
});

// GET /api/fire-perimeters
// Proxies NIFC active fire perimeter GeoJSON from WFIGS (Wildland Fire
// Interagency Geospatial Services). Tries two known NIFC ArcGIS service
// names since NIFC occasionally renames layers. Cached 30 minutes.
const _fireCache = { data: null, ts: 0 };
const FIRE_TTL = 30 * 60 * 1000;

const NIFC_ENDPOINTS = [
  // Confirmed correct NIFC service name (via NIFC Open Data / Data Basin)
  'https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/Current_WildlandFire_Perimeters/FeatureServer/0/query',
  // YTD perimeters — wider dataset, includes fires from current year
  'https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/WFIGS_Interagency_Perimeters_YTD/FeatureServer/0/query',
  // Fallbacks in case NIFC renames the service
  'https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/WFIGS_Interagency_Perimeters_Current/FeatureServer/0/query',
  'https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/Active_Fires/FeatureServer/0/query',
];
const NIFC_PARAMS = '?where=1%3D1&outFields=IncidentName,GISAcres,PercentContained,FireCause,POOState,FeatureCategory&resultRecordCount=500&f=geojson';

app.get('/api/fire-perimeters', async (req, res) => {
  if (_fireCache.data && Date.now() - _fireCache.ts < FIRE_TTL) {
    res.set('Content-Type', 'application/json');
    res.set('Cache-Control', 'public, max-age=1800');
    return res.send(_fireCache.data);
  }

  let bestResult = null;
  for (const base of NIFC_ENDPOINTS) {
    try {
      const data = await fetchTextOverHttp(base + NIFC_PARAMS);
      const parsed = JSON.parse(data);
      const count = (parsed.features || []).length;
      console.log(`[Fire] ${base.split('/').slice(-3,-1).join('/')} → ${count} features`);
      if (count > 0) {
        _fireCache.data = data;
        _fireCache.ts = Date.now();
        res.set('Content-Type', 'application/json');
        res.set('Cache-Control', 'public, max-age=1800');
        return res.send(data);
      }
      if (!bestResult) bestResult = data; // keep first valid (even if empty)
    } catch(e) {
      console.warn(`[Fire] ${base.split('/').slice(-3,-1).join('/')} failed:`, e.message);
    }
  }

  // All endpoints returned 0 features or failed — send best result (empty GeoJSON)
  console.warn('[Fire] No active fire perimeters found across all NIFC endpoints');
  const empty = bestResult || JSON.stringify({ type:'FeatureCollection', features:[] });
  _fireCache.data = empty;
  _fireCache.ts = Date.now();
  res.set('Content-Type', 'application/json');
  res.send(empty);
});

// ── Camera proxy: safety + cost controls (Sep 2026) ──────────────────────────
// DOT camera servers mostly block direct browser access (CORS / http-only),
// so images and HLS video are relayed through this server. That makes camera
// viewing the one feature whose Railway egress grows per viewer-minute, so:
//   1. Host allowlist. The old proxy relayed ANY public URL — an open proxy
//      anyone could abuse on our bandwidth bill. Allowed hosts are learned
//      automatically from the camera lists this server hands out
//      (/api/cameras/*), plus segment hosts from playlists we already allowed,
//      plus CAMERA_PROXY_HOSTS (comma-separated) for sources the client loads
//      elsewhere. Learned hosts persist in Redis.
//      ROLLOUT: starts in REPORT mode (logs unknown hosts, still serves them).
//      Check GET /api/admin/upstream-usage for `cameraUnknownHosts`, add any
//      legit ones to CAMERA_PROXY_HOSTS, then set CAMERA_PROXY_ENFORCE=true.
//   2. Shared fetches. 50 viewers of one camera = 1 upstream fetch per
//      segment/image (single-flight), not 50.
//   3. Hard limits: size caps (image 5 MB, playlist 1 MB, segment 15 MB),
//      15s timeout, max 3 redirects, private-address check on EVERY redirect
//      hop (old code only checked the first URL — SSRF via redirect).
//   4. HLS cache bounded by BYTES (48 MB), not entry count — 500 video
//      segments could previously pin ~1 GB of RAM.
//   5. Per-IP rate limit (600 proxy requests/min — a normal viewer uses ~30).
//   6. Bytes served are counted daily (upstream-usage) so the real cost is visible.
const CAM_HOSTS_KEY = 'wt:camhosts';
const CAM_ENFORCE = /^(true|1|yes|on)$/i.test(process.env.CAMERA_PROXY_ENFORCE || '');
const _camHosts = new Set((process.env.CAMERA_PROXY_HOSTS || '').split(',').map(h => h.trim().toLowerCase()).filter(Boolean));
const _camUnknown = new Map();   // host -> hits (report mode visibility)
let _camHostsLoaded = null, _camHostsDirty = false;

function _isPrivateHost(hostname) {
  const h = String(hostname).toLowerCase().replace(/^\[|\]$/g, '');
  if (h.includes(':')) return /^(::1?$|fc|fd|fe80|::ffff:(127|10|192\.168|169\.254)\.)/.test(h);
  return /^(localhost$|0\.|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h)
      || h.endsWith('.internal') || h.endsWith('.local') || h.endsWith('.railway.internal');
}

function _registerCamHost(u) {
  try {
    const h = new URL(u).hostname.toLowerCase();
    if (h && !_isPrivateHost(h) && !_camHosts.has(h)) { _camHosts.add(h); _camHostsDirty = true; }
  } catch {}
}

function _collectCamUrls(obj, depth = 0) {
  if (!obj || depth > 6) return;
  if (Array.isArray(obj)) { for (const o of obj) _collectCamUrls(o, depth + 1); return; }
  if (typeof obj !== 'object') return;
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string') { if (/url$/i.test(k) && /^https?:\/\//i.test(v)) _registerCamHost(v); }
    else if (v && typeof v === 'object') _collectCamUrls(v, depth + 1);
  }
}

function _loadCamHosts() {
  if (!_camHostsLoaded) {
    _camHostsLoaded = (async () => {
      try {
        const saved = await rGet(CAM_HOSTS_KEY);
        const arr = Array.isArray(saved) ? saved : (typeof saved === 'string' ? JSON.parse(saved) : []);
        (arr || []).forEach(h => _camHosts.add(String(h).toLowerCase()));
      } catch (e) { console.warn('[CamProxy] host list load failed:', e.message); }
    })();
  }
  return _camHostsLoaded;
}
setInterval(() => {
  if (!_camHostsDirty) return;
  _camHostsDirty = false;
  rSet(CAM_HOSTS_KEY, [..._camHosts]).catch?.(() => {});
}, 60 * 1000).unref();

async function _camHostAllowed(hostname) {
  await _loadCamHosts();
  const h = hostname.toLowerCase();
  if (_camHosts.has(h)) return true;
  _camUnknown.set(h, (_camUnknown.get(h) || 0) + 1);
  if (_camUnknown.size > 500) _camUnknown.delete(_camUnknown.keys().next().value);
  return !CAM_ENFORCE;
}

// Per-IP fixed-window rate limit for the camera proxies
const _camRate = new Map();
const CAM_RATE_PER_MIN = Number(process.env.CAMERA_PROXY_RATE_PER_MIN) || 600;
setInterval(() => _camRate.clear(), 60 * 1000).unref();
function _clientIp(req) {
  return req.headers['cf-connecting-ip'] || (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || '?';
}
function _camRateOk(req) {
  const ip = _clientIp(req);
  const n = (_camRate.get(ip) || 0) + 1;
  _camRate.set(ip, n);
  return n <= CAM_RATE_PER_MIN;
}

// Fetch with redirect re-validation, size cap and timeout
function _fetchBinary(url, { maxBytes = 5 * 1024 * 1024, timeoutMs = 15000, redirects = 3 } = {}) {
  return new Promise((resolve, reject) => {
    let p;
    try { p = new URL(url); } catch (e) { return reject(e); }
    if (!['http:', 'https:'].includes(p.protocol)) return reject(new Error('http/https only'));
    if (_isPrivateHost(p.hostname)) return reject(new Error('private address blocked'));
    const mod = p.protocol === 'https:' ? require('https') : require('http');
    // Browser-style headers: several state 511 sites sit behind firewalls that
    // answer unfamiliar clients with 403/404. Still identifies WeatherTV.
    const opts = { headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; WeatherTV/1.0; +https://watchweathertv.com)',
      'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
      'Referer': p.origin + '/',
    }, timeout: timeoutMs };
    const req = mod.get(url, opts, r => {
      if ([301, 302, 303, 307, 308].includes(r.statusCode)) {
        r.resume();
        if (redirects <= 0) return reject(new Error('too many redirects'));
        const rawLoc = r.headers.location;
        if (!rawLoc) return reject(new Error('redirect with no location'));
        let loc;
        try { loc = new URL(rawLoc, url).href; } catch (_) { return reject(new Error('bad redirect')); }
        return _fetchBinary(loc, { maxBytes, timeoutMs, redirects: redirects - 1 }).then(resolve, reject);
      }
      const declared = Number(r.headers['content-length'] || 0);
      if (declared > maxBytes) { r.destroy(); return reject(new Error('upstream too large')); }
      const chunks = []; let total = 0;
      r.on('data', c => {
        total += c.length;
        if (total > maxBytes) { r.destroy(); reject(new Error('upstream too large')); return; }
        chunks.push(c);
      });
      r.on('end', () => resolve({ buf: Buffer.concat(chunks), ct: r.headers['content-type'] || '', status: r.statusCode,
                                 lastModified: r.headers['last-modified'] || null }));
      r.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('upstream timeout')));
    req.on('error', reject);
  });
}

// GET /api/camera-hls?url=...
// HLS stream proxy — routes M3U8 and .ts segment requests through our server
// so HLS.js XHR calls stay same-origin and never trigger connect-src CSP.
// M3U8 playlists are rewritten to route all segment URLs through this proxy.
const _hlsCache = new Map();       // url -> { buf, ct, ts }   (insertion order = oldest first)
const _hlsInflight = new Map();    // url -> Promise
let _hlsCacheBytes = 0;
const HLS_CACHE_MAX_BYTES = 48 * 1024 * 1024;
const HLS_M3U8_TTL = 4 * 1000;
const HLS_SEG_TTL  = 30 * 1000;

function _hlsCachePut(url, entry) {
  const prev = _hlsCache.get(url);
  if (prev) { _hlsCacheBytes -= prev.buf.length; _hlsCache.delete(url); }
  _hlsCache.set(url, entry);
  _hlsCacheBytes += entry.buf.length;
  while (_hlsCacheBytes > HLS_CACHE_MAX_BYTES && _hlsCache.size) {
    const [k, v] = _hlsCache.entries().next().value;
    _hlsCache.delete(k); _hlsCacheBytes -= v.buf.length;
  }
}

async function _hlsFetch(rawUrl, isM3U8) {
  const { buf, ct, status } = await _fetchBinary(rawUrl, { maxBytes: isM3U8 ? 1024 * 1024 : 15 * 1024 * 1024 });
  if (status && status >= 400) { const e = new Error('upstream ' + status); e.status = status; throw e; }
  let outBuf = buf, outCt = ct;
  if (isM3U8) {
    const baseUrl = rawUrl.substring(0, rawUrl.lastIndexOf('/') + 1);
    const text = buf.toString('utf8');
    const rewritten = text.split('\n').map(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return line;
      let absUrl;
      try { absUrl = trimmed.startsWith('http') ? trimmed : new URL(trimmed, baseUrl).href; }
      catch(_) { return line; }
      _registerCamHost(absUrl);   // segments/variants from an allowed playlist are allowed
      return `/api/camera-hls?url=${encodeURIComponent(absUrl)}`;
    }).join('\n');
    outBuf = Buffer.from(rewritten, 'utf8');
    outCt  = 'application/vnd.apple.mpegurl';
  } else if (!outCt || outCt.includes('text/html')) {
    outCt = 'video/MP2T';
  }
  const entry = { buf: outBuf, ct: outCt, ts: Date.now() };
  _hlsCachePut(rawUrl, entry);
  return entry;
}

app.get('/api/camera-hls', async (req, res) => {
  const rawUrl = (req.query.url || '').trim();
  if (!rawUrl) return res.status(400).send('url required');
  let parsedUrl;
  try { parsedUrl = new URL(rawUrl); } catch { return res.status(400).send('invalid url'); }
  if (!['http:', 'https:'].includes(parsedUrl.protocol)) return res.status(400).send('http/https only');
  if (_isPrivateHost(parsedUrl.hostname)) return res.status(403).send('private addresses not allowed');
  if (!_camRateOk(req)) { upstreamCount('cameraRateLimited'); return res.status(429).send('slow down'); }
  if (!(await _camHostAllowed(parsedUrl.hostname))) { upstreamCount('cameraBlocked'); return res.status(403).send('host not allowed'); }

  const isM3U8 = rawUrl.includes('.m3u8') || rawUrl.includes('playlist');
  const ttl = isM3U8 ? HLS_M3U8_TTL : HLS_SEG_TTL;
  const send = (entry) => {
    upstreamCount('cameraHlsBytes', entry.buf.length);
    res.set('Content-Type', entry.ct);
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Cache-Control', isM3U8 ? 'no-cache' : 'public, max-age=30');
    res.send(entry.buf);
  };

  const cached = _hlsCache.get(rawUrl);
  if (cached && Date.now() - cached.ts < ttl) return send(cached);

  try {
    let p = _hlsInflight.get(rawUrl);
    if (!p) {
      upstreamCount('cameraHlsUpstream');
      p = _hlsFetch(rawUrl, isM3U8).finally(() => _hlsInflight.delete(rawUrl));
      _hlsInflight.set(rawUrl, p);
    }
    send(await p);
  } catch(e) {
    if (e.status) return res.status(e.status).send(e.message);
    console.warn('[HLS Proxy]', e.message);
    res.status(502).send('upstream error');
  }
});

// GET /api/camera-image?url=...
// CORS proxy for camera image URLs — almost all DOT servers block direct
// browser requests with missing CORS headers. We fetch server-side and
// pipe back the bytes with the correct headers. Cached 25s so repeated
// refreshes within a poll cycle don't hammer upstream.
const _imgInflight = new Map();
app.get('/api/camera-image', async (req, res) => {
  const rawUrl = (req.query.url || '').trim();
  if (!rawUrl) return res.status(400).send('url required');

  let parsedUrl;
  try { parsedUrl = new URL(rawUrl); } catch { return res.status(400).send('invalid url'); }
  if (!['http:', 'https:'].includes(parsedUrl.protocol)) return res.status(400).send('http/https only');
  if (_isPrivateHost(parsedUrl.hostname)) return res.status(403).send('private addresses not allowed');
  if (!_camRateOk(req)) { upstreamCount('cameraRateLimited'); return res.status(429).send('slow down'); }
  if (!(await _camHostAllowed(parsedUrl.hostname))) { upstreamCount('cameraBlocked'); return res.status(403).send('host not allowed'); }

  const send = (entry) => {
    upstreamCount('cameraImageBytes', entry.buf.length);
    res.set('Content-Type', entry.ct || 'image/jpeg');
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Cache-Control', 'public, max-age=25');
    res.send(entry.buf);
  };

  const cached = _imgCache.get(rawUrl);
  if (cached && Date.now() - cached.ts < IMG_TTL) return send(cached);

  try {
    let p = _imgInflight.get(rawUrl);
    if (!p) {
      upstreamCount('cameraImageUpstream');
      p = _fetchBinary(rawUrl, { maxBytes: 5 * 1024 * 1024 }).then(r => {
        if (r.status && r.status >= 400) { const e = new Error('upstream ' + r.status); e.status = r.status; throw e; }
        const entry = { buf: r.buf, ct: r.ct, ts: Date.now() };
        _lruSet(_imgCache, rawUrl, entry, 200);
        return entry;
      }).finally(() => _imgInflight.delete(rawUrl));
      _imgInflight.set(rawUrl, p);
    }
    send(await p);
  } catch (e) {
    _noteCamFailure(parsedUrl, e.status || e.message);
    if (e.status) return res.status(e.status).send(e.message);
    res.status(502).send('upstream error');
  }
});

// Per-host camera failure log — shown at /api/admin/upstream-usage, and the
// first failure per host+reason is printed to the Railway log, so a broken
// state feed says exactly what its server answered (404, 403, timeout…).
const _camFailures = new Map();   // host -> { count, reasons: {reason: n}, example, last }
function _noteCamFailure(u, reason) {
  const host = u.hostname;
  const f = _camFailures.get(host) || { count: 0, reasons: {}, example: '', last: 0 };
  const r = String(reason);
  if (!f.reasons[r]) console.warn(`[CameraProxy] ${host} → ${r} (e.g. ${u.pathname}${u.search.replace(/key=[^&]+/i, 'key=…')})`);
  f.count += 1; f.reasons[r] = (f.reasons[r] || 0) + 1;
  f.example = u.pathname + u.search.replace(/key=[^&]+/i, 'key=…'); f.last = Date.now();
  _camFailures.set(host, f);
  if (_camFailures.size > 200) _camFailures.delete(_camFailures.keys().next().value);
}

// GET /api/admin/upstream-usage — today's upstream calls, cache efficiency,
// camera egress, and camera hosts not yet on the allowlist (admin auth).
app.get('/api/admin/upstream-usage', async (req, res) => {
  await _loadCamHosts();
  const mb = (b) => b ? +(b / 1048576).toFixed(1) : 0;
  res.json({
    day: _upstream.day,
    counts: _upstream,
    cameraEgressMB: { hls: mb(_upstream.cameraHlsBytes), images: mb(_upstream.cameraImageBytes) },
    forecastCache: { cells: _forecastCache.size, max: FORECAST_MAX, gridDeg: FORECAST_GRID },
    camera: {
      enforce: CAM_ENFORCE,
      allowedHosts: _camHosts.size,
      unknownHosts: [..._camUnknown.entries()].sort((a, b) => b[1] - a[1]).slice(0, 50).map(([host, hits]) => ({ host, hits })),
      hlsCacheMB: mb(_hlsCacheBytes),
      // Which camera servers are failing, and what they answered
      failures: [..._camFailures.entries()].sort((a, b) => b[1].count - a[1].count).slice(0, 40)
        .map(([host, f]) => ({ host, count: f.count, reasons: f.reasons, example: f.example, last: new Date(f.last).toISOString() })),
    },
  });
});



// Admin — map a Spotter Network chaser ID to one of our channel IDs
app.post('/api/admin/chasers/map', (req, res) => {
  const { spotterNetworkId, channelId } = req.body;
  if (!spotterNetworkId) return res.status(400).json({ error: 'spotterNetworkId required' });
  const data = loadData();
  if (!data.chaserMap) data.chaserMap = {};
  if (channelId) {
    data.chaserMap[spotterNetworkId] = channelId;
  } else {
    delete data.chaserMap[spotterNetworkId]; // unmap
  }
  saveData(data);
  res.json({ ok: true });
});

// Admin — dismiss a single (spotterNetworkId, channelId) suggestion pair as
// "not a match." Stored permanently so it never resurfaces in Suggestions
// again, even though the same name-similarity will keep recomputing on
// every refresh. Scoped to the pair, not the whole chaser, since the same
// person might still be a fuzzy match candidate against a DIFFERENT channel
// later (e.g. if they're later confirmed as someone else entirely).
app.post('/api/admin/chasers/dismiss-suggestion', (req, res) => {
  const { spotterNetworkId, channelId } = req.body;
  if (!spotterNetworkId || !channelId) return res.status(400).json({ error: 'spotterNetworkId and channelId required' });
  const data = loadData();
  if (!data.dismissedSuggestions) data.dismissedSuggestions = [];
  const key = spotterNetworkId + '::' + channelId;
  if (!data.dismissedSuggestions.includes(key)) data.dismissedSuggestions.push(key);
  saveData(data);
  res.json({ ok: true });
});

// Admin — dismiss a chaser entirely from "New Chasers Found" (e.g. a
// self-reported YouTube link that turns out to be unrelated, a duplicate,
// or just not someone you want to add). Stored permanently — the chaser
// stays excluded from that list even though they'll keep appearing in the
// knownChasers registry and the live feed/radar dots.
app.post('/api/admin/chasers/dismiss-new', (req, res) => {
  const { spotterNetworkId } = req.body;
  if (!spotterNetworkId) return res.status(400).json({ error: 'spotterNetworkId required' });
  const data = loadData();
  if (!data.dismissedNewChasers) data.dismissedNewChasers = [];
  if (!data.dismissedNewChasers.includes(spotterNetworkId)) data.dismissedNewChasers.push(spotterNetworkId);
  saveData(data);
  res.json({ ok: true });
});

// Admin — auto-maps every current "exact" tier match in one call. Exact
// matches are normalized-identical names or full-token-subset matches (see
// matchConfidence above), which is a low false-positive-risk bar — these
// don't need a human click each. Fuzzy matches are intentionally excluded
// and still require manual confirmation in the Suggestions tab.
app.post('/api/admin/chasers/auto-map-exact', (req, res) => {
  const data = loadData();
  if (!data.chaserMap) data.chaserMap = {};
  const knownChasers = data.knownChasers || {};
  const allChannels = [];
  (data.groups || []).forEach(g => {
    (g.channels || []).forEach(ch => allChannels.push({ id: ch.id, name: ch.name }));
  });

  let mapped = 0;
  const mappedNames = [];
  Object.entries(knownChasers).forEach(([spotterNetworkId, c]) => {
    if (data.chaserMap[spotterNetworkId]) return; // already mapped
    for (const ch of allChannels) {
      if (matchConfidence(c.name, ch.name) === 'exact') {
        data.chaserMap[spotterNetworkId] = ch.id;
        mapped++;
        mappedNames.push({ spotterName: c.name, channelName: ch.name });
        break; // first exact match wins — exact tier is narrow enough that
                // multiple exact matches for one chaser should be rare
      }
    }
  });

  if (mapped > 0) saveData(data);
  res.json({ ok: true, mapped, mappedNames });
});

// Admin — suggested matches: compares Spotter Network names against our
// existing channel names (case-insensitive substring match) so the admin
// doesn't have to manually search 400+ chasers for matches by hand.
// Compares a Spotter Network name against a channel name and returns a
// confidence tier: 'exact' (normalized names are identical — safe to
// auto-map), 'fuzzy' (one contains the other, or they share both first and
// last token — needs human review), or null (no meaningful match).
function matchConfidence(spotterName, channelName) {
  const norm = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const sNorm = norm(spotterName);
  const cNorm = norm(channelName);
  if (!sNorm || !cNorm) return null;

  if (sNorm === cNorm) return 'exact';

  const sTokens = spotterName.toLowerCase().split(/\s+/).filter(Boolean);
  const cTokens = channelName.toLowerCase().split(/\s+/).filter(Boolean);

  // Suffix case: every token of the shorter name appears, in order, at the
  // start of the longer name's token list — e.g. "Brandon Copic" vs.
  // "Brandon Copic Live" / "Brandon Copic Archive". This only checks a
  // leading prefix match (not "any shared tokens"), so it can't be
  // triggered by two people merely sharing a first name.
  const [shorter, longer] = sTokens.length <= cTokens.length ? [sTokens, cTokens] : [cTokens, sTokens];
  if (shorter.length >= 2 && longer.length > shorter.length) {
    const isPrefixMatch = shorter.every((t, i) => longer[i] === t);
    if (isPrefixMatch) return 'exact';
  }

  // Last-name token must match for any further comparison — this is what
  // prevents "John Brown" from fuzzy-matching "John Smith" just because
  // they share a common first name. Without this guard, common first names
  // (John, Mike, etc.) across hundreds of live chasers would flood the
  // fuzzy review list with false positives.
  const sLast = sTokens[sTokens.length - 1];
  const cLast = cTokens[cTokens.length - 1];
  if (sTokens.length < 2 || cTokens.length < 2 || sLast !== cLast) {
    // No reliable last-name anchor — only allow a match if one full
    // normalized name is contained in the other (e.g. single-word channel
    // brand names that happen to embed the full spotter name).
    if (cNorm.includes(sNorm) || sNorm.includes(cNorm)) return 'fuzzy';
    return null;
  }

  // Last names match — first name token must also match for 'exact',
  // otherwise fuzzy (covers nicknames/initials on the first name only).
  const sFirst = sTokens[0];
  const cFirst = cTokens[0];
  if (sFirst === cFirst) return 'exact';
  return 'fuzzy';
}

app.get('/api/admin/chasers/suggestions', (req, res) => {
  const data = loadData();
  const chaserMap = data.chaserMap || {};
  const knownChasers = data.knownChasers || {};
  const dismissed = new Set(data.dismissedSuggestions || []);
  const allChannels = [];
  (data.groups || []).forEach(g => {
    (g.channels || []).forEach(ch => allChannels.push({ id: ch.id, name: ch.name }));
  });

  const exact = [];
  const fuzzy = [];
  Object.entries(knownChasers).forEach(([spotterNetworkId, c]) => {
    if (chaserMap[spotterNetworkId]) return; // already mapped
    allChannels.forEach(ch => {
      if (dismissed.has(spotterNetworkId + '::' + ch.id)) return; // admin already said no
      const confidence = matchConfidence(c.name, ch.name);
      if (!confidence) return;
      const entry = {
        spotterNetworkId,
        spotterName: c.name,
        channelId: ch.id,
        channelName: ch.name,
        lastSeenAt: c.lastSeenAt
      };
      if (confidence === 'exact') exact.push(entry); else fuzzy.push(entry);
    });
  });

  res.json({ exact, fuzzy, suggestions: fuzzy }); // `suggestions` kept for backward compat — fuzzy tier only
});

// Admin — chasers with a self-reported YouTube link in their Note field who
// are NOT yet mapped to one of our channels. Surfaces new chasers to add.
// Runs against the persisted knownChasers registry, not just the current
// 2-minute live snapshot, so this accumulates everyone we've ever spotted
// reporting a link rather than only whoever happens to be active right now.
app.get('/api/admin/chasers/unmapped-youtube', (req, res) => {
  const data = loadData();
  const chaserMap = data.chaserMap || {};
  const knownChasers = data.knownChasers || {};
  const dismissedNew = new Set(data.dismissedNewChasers || []);

  const found = Object.entries(knownChasers)
    .filter(([spotterNetworkId, c]) => c.youtubeUrl && !chaserMap[spotterNetworkId] && !dismissedNew.has(spotterNetworkId))
    .map(([spotterNetworkId, c]) => {
      // Pull current live status from the cache if they're active right
      // now; otherwise fall back to "last seen" since they may not be
      // broadcasting in this exact poll window.
      const live = chaserCache.chasers.find(lc => lc.id === spotterNetworkId);
      return {
        spotterNetworkId,
        name: c.name,
        youtubeUrl: c.youtubeUrl,
        lat: live ? live.lat : null,
        lng: live ? live.lng : null,
        status: live ? live.status : 'offline',
        lastSeenAt: c.lastSeenAt
      };
    });

  res.json({ unmapped: found });
});

// Resolves a YouTube URL (handle, /channel/UC..., /c/name, /user/name, or a
// video URL) into a channel ID + display name + thumbnail via the YouTube
// Data API. Used by the "Add as Channel" button on the New Chasers Found
// tab, since chasers self-report arbitrary YouTube URL formats in their
// Spotter Network Note field, not raw channel IDs.
function parseYouTubeUrlParts(url) {
  try {
    const u = new URL(url);
    const path = u.pathname.replace(/\/+$/, ''); // strip trailing slash

    let m;
    if ((m = path.match(/^\/channel\/(UC[\w-]{10,})/))) return { type: 'id', value: m[1] };
    if ((m = path.match(/^\/@([\w.-]+)/)))              return { type: 'handle', value: '@' + m[1] };
    if ((m = path.match(/^\/c\/([\w.-]+)/)))             return { type: 'custom', value: m[1] };
    if ((m = path.match(/^\/user\/([\w.-]+)/)))          return { type: 'legacy', value: m[1] };
    // Video URL — resolve via the video's channelId instead
    if (path === '/watch' && u.searchParams.get('v'))   return { type: 'video', value: u.searchParams.get('v') };
    if (u.hostname.includes('youtu.be'))                 return { type: 'video', value: path.slice(1) };
  } catch(e) {}
  return null;
}

async function resolveYouTubeChannel(url) {
  const parts = parseYouTubeUrlParts(url);
  if (!parts) {
    const err = new Error('Could not parse a recognizable YouTube URL format from: ' + url);
    err.code = 'unparseable_url';
    throw err;
  }
  const key = getApiKey();

  let apiUrl = null;
  if (parts.type === 'id') {
    apiUrl = `https://www.googleapis.com/youtube/v3/channels?key=${key}&id=${parts.value}&part=snippet`;
  } else if (parts.type === 'handle') {
    apiUrl = `https://www.googleapis.com/youtube/v3/channels?key=${key}&forHandle=${encodeURIComponent(parts.value)}&part=snippet`;
  } else if (parts.type === 'custom' || parts.type === 'legacy') {
    // Legacy /c/ and /user/ URLs aren't directly resolvable by the v3 API —
    // fall back to a search, which costs more quota but covers the format.
    apiUrl = `https://www.googleapis.com/youtube/v3/search?key=${key}&q=${encodeURIComponent(parts.value)}&type=channel&part=snippet&maxResults=1`;
  } else if (parts.type === 'video') {
    const videoData = await ytFetch(`https://www.googleapis.com/youtube/v3/videos?key=${key}&id=${parts.value}&part=snippet`);
    if (checkQuotaError(videoData)) { markQuotaExceeded(true); const e = new Error('quota_exceeded'); e.code = 'quota_exceeded'; throw e; }
    const channelId = videoData.items && videoData.items[0] && videoData.items[0].snippet.channelId;
    if (!channelId) {
      const err = new Error('Video lookup returned no channelId (video may be private, deleted, or ID is wrong). Raw API response: ' + JSON.stringify(videoData).slice(0, 300));
      err.code = 'video_lookup_empty';
      throw err;
    }
    apiUrl = `https://www.googleapis.com/youtube/v3/channels?key=${key}&id=${channelId}&part=snippet`;
  }

  if (!apiUrl) {
    const err = new Error('Internal: no API URL constructed for parsed type "' + parts.type + '"');
    err.code = 'internal_no_url';
    throw err;
  }

  const data = await ytFetch(apiUrl);
  if (checkQuotaError(data)) { markQuotaExceeded(true); const e = new Error('quota_exceeded'); e.code = 'quota_exceeded'; throw e; }

  // Surface the API's own error payload rather than swallowing it — this is
  // what was previously hidden behind a generic "Could not resolve" message,
  // making it impossible to tell a bad handle apart from an API-level
  // rejection (e.g. forHandle not recognizing a channel that exists but
  // hasn't claimed a handle, or a transient API error).
  if (data.error) {
    const err = new Error('YouTube API error: ' + (data.error.message || JSON.stringify(data.error)));
    err.code = 'api_error';
    throw err;
  }

  const item = data.items && data.items[0];
  if (!item) {
    const err = new Error(
      `No channel found for ${parts.type} "${parts.value}". This can happen if the channel was deleted/suspended, ` +
      `the handle was never claimed by this exact string, or (for older accounts) the channel has no handle set at all. ` +
      `Use the channel ID override below if you have it.`
    );
    err.code = 'not_found';
    throw err;
  }

  const channelId = item.id?.channelId || item.id; // search results nest id.channelId
  const snippet = item.snippet || {};
  return {
    channelId,
    name: snippet.title || parts.value,
    thumbnail: snippet.thumbnails?.default?.url || null
  };
}

// Admin — resolve a YouTube URL to a channel ID/name without adding it yet.
// Lets the admin preview what will be added before confirming.
app.post('/api/admin/chasers/resolve-youtube', async (req, res) => {
  const { youtubeUrl } = req.body;
  if (!youtubeUrl) return res.status(400).json({ error: 'youtubeUrl required' });
  try {
    const resolved = await resolveYouTubeChannel(youtubeUrl);
    res.json(resolved);
  } catch(e) {
    if (e.code === 'quota_exceeded') return res.status(429).json({ error: 'quota_exceeded' });
    res.status(404).json({ error: e.message, code: e.code || 'unknown' });
  }
});

// Admin — one-click flow for the New Chasers Found tab: resolves the
// chaser's self-reported YouTube URL to a channel ID, adds it as a new
// channel in the Storm Chasers group (alphabetized), and immediately maps
// the Spotter Network ID to the new channel. All three steps happen
// server-side in one call so the UI doesn't need multiple round trips.
//
// If `manualChannelId` is provided, resolution is skipped entirely and that
// ID is used directly — this is the workaround for chasers whose handle
// won't resolve via forHandle (deleted/renamed channel, handle never
// claimed, transient API quirk, etc.) but whose channel ID the admin found
// by hand (e.g. via the page source or a third-party ID lookup tool).
// channelName is required alongside manualChannelId since there's no API
// call to fetch a display name from in this path.
app.post('/api/admin/chasers/add-and-map', async (req, res) => {
  const { spotterNetworkId, youtubeUrl, groupId, manualChannelId, manualChannelName } = req.body;
  if (!spotterNetworkId) {
    return res.status(400).json({ error: 'spotterNetworkId required' });
  }
  if (!youtubeUrl && !manualChannelId) {
    return res.status(400).json({ error: 'youtubeUrl or manualChannelId required' });
  }

  try {
    let resolved;
    if (manualChannelId) {
      const trimmedId = manualChannelId.trim();
      if (!/^UC[\w-]{10,}$/.test(trimmedId)) {
        return res.status(400).json({ error: 'That doesn\'t look like a valid YouTube channel ID — it should start with "UC" (e.g. UCcJ8bLvmhJgK_cCGESPjzxQ).' });
      }
      if (!manualChannelName || !manualChannelName.trim()) {
        return res.status(400).json({ error: 'A display name is required when adding by channel ID manually.' });
      }
      resolved = { channelId: trimmedId, name: manualChannelName.trim(), thumbnail: null };
    } else {
      resolved = await resolveYouTubeChannel(youtubeUrl);
    }

    const data = loadData();
    const targetGroupId = groupId || 'chasers';
    const group = (data.groups || []).find(g => g.id === targetGroupId);
    if (!group) return res.status(404).json({ error: 'Target group not found: ' + targetGroupId });

    // Skip if this channel ID is already in the group (avoid duplicates)
    const exists = (group.channels || []).some(ch => ch.id === resolved.channelId);
    if (!exists) {
      group.channels = group.channels || [];
      group.channels.push({
        id: resolved.channelId,
        name: resolved.name,
        hasLive: true,
        enabled: true
      });
      // Re-alphabetize the group by name, case-insensitive — matches the
      // existing sort order convention used across all channel groups.
      group.channels.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
    }

    if (!data.chaserMap) data.chaserMap = {};
    data.chaserMap[spotterNetworkId] = resolved.channelId;

    saveData(data);
    res.json({ ok: true, channelId: resolved.channelId, channelName: resolved.name, alreadyExisted: exists });
  } catch(e) {
    if (e.code === 'quota_exceeded') return res.status(429).json({ error: 'quota_exceeded' });
    res.status(404).json({ error: e.message, code: e.code || 'unknown' });
  }
});

// Refresh the chaser cache every 45 seconds — close to Spotter Network's own
// ~30-60s device ping cadence, so we're not adding much extra staleness on
// top of their source data. This is a public, unauthenticated feed; if
// Spotter Network ever wants this slowed down they'll let us know (rate
// limit response, blocked IP, etc.) and we can back off then.
setInterval(refreshChaserCache, 45 * 1000);
// Initial fetch shortly after boot
setTimeout(refreshChaserCache, 5000);

// ── WebSub subscription lease tracker ───────────────────────────────────────
// Tracks per-channel subscription status and lease expiry.
const websubLeases = {}; // { channelId: { subscribedAt, expiresAt, status } }

// ── Failed fetch error log ────────────────────────────────────────────────────
// Circular buffer of last 50 fetch errors — visible in admin panel.
// ── Event log — captures errors, quota hits, fetches, admin actions ──────────
// type: 'error' | 'quota' | 'fetch' | 'admin' | 'info'
// severity: 'error' | 'warn' | 'info'
const eventLog = [];
const MAX_EVENT_LOG = 200;

function logEvent({ type = 'info', severity = 'info', source = 'system', channelId = null, channelName = null, message, detail = null }) {
  const entry = { type, severity, source, channelId, channelName, message, detail, timestamp: Date.now() };
  eventLog.unshift(entry);
  if (eventLog.length > MAX_EVENT_LOG) eventLog.pop();
  if (severity === 'error') console.error(`[WeatherTV][${type}] ${message}`, detail || '');
  else if (severity === 'warn') console.warn(`[WeatherTV][${type}] ${message}`, detail || '');
}

// Back-compat shim — existing logFetchError calls still work
function logFetchError(channelId, channelName, errorMsg) {
  logEvent({ type: 'error', severity: 'error', source: 'fetch', channelId, channelName, message: errorMsg });
}

// ── Daily live-check quota tracker ──────────────────────────────────────────
// Each WebSub-triggered check now uses videos.list (1 unit) not search (100 units).
// Cap raised to 500 checks/day = ~500 units max (vs old 40 × 100 = 4,000 units).
// The 100-unit search fallback (no video ID) still counts against this limit.
const quotaTracker = { date: "", liveChecks: 0 };
const DAILY_LIVE_CHECK_LIMIT = 2000; // videos.list at 1 unit each — 2,000 max/day uses ~2,000 of 60,000 available units

function getLiveChecksToday() {
  const today = new Date().toISOString().split('T')[0];
  if (quotaTracker.date !== today) { quotaTracker.date = today; quotaTracker.liveChecks = 0; }
  return quotaTracker.liveChecks;
}

function recordLiveCheck() {
  const today = new Date().toISOString().split('T')[0];
  if (quotaTracker.date !== today) { quotaTracker.date = today; quotaTracker.liveChecks = 0; }
  quotaTracker.liveChecks++;
}

// ── Channel activity tracking ────────────────────────────────────────────────
// Tracks per-channel last video upload date and last confirmed live date.
// Used to assign channels to fetch tiers so quota is spent on active creators.

async function updateChannelActivity(channelId, updates) {
  const existing = cache.channelActivity[channelId] || {};
  const updated = { ...existing, ...updates };
  cache.channelActivity[channelId] = updated;
  await rSet('wt:activity:' + channelId, updated, REDIS_TTL.channelActivity);
}

// Tier 1 (fetch daily): last video < 14 days OR hasLive + last live < 30 days
// Tier 2 (fetch every 14 days): hasLive but not live in 30+ days
// Tier 3 (fetch every 14 days, offset): no hasLive, last video 14+ days
function getChannelTier(ch) {
  const act = cache.channelActivity[ch.id] || {};
  const now = Date.now();
  const DAY = 86400000;

  const hasVideoHistory = !!act.lastVideoDate;
  const hasLiveHistory  = !!act.lastLiveDate;

  // Bootstrap case — no activity data ever recorded for this channel.
  // Use hasLive as a proxy: live-capable channels are almost certainly active,
  // non-live channels can wait for a 14-day check without losing much freshness.
  if (!hasVideoHistory && !hasLiveHistory) {
    return ch.hasLive ? 1 : 3;
  }

  const lastVideoAge = hasVideoHistory ? (now - act.lastVideoDate) / DAY : 999;
  const lastLiveAge  = hasLiveHistory  ? (now - act.lastLiveDate)  / DAY : 999;

  if (lastVideoAge < 14) return 1;              // recently posted video
  if (ch.hasLive && lastLiveAge < 30) return 1; // recently confirmed live
  if (ch.hasLive) return 2;                      // has live capability, but inactive
  return 3;                                      // no live, inactive video poster
}

// Should a Tier 2/3 channel be fetched today?
// Tier 2 (inactive live) fetches on days 1,3,5... of a 14-day rolling window
// Tier 3 (inactive video) fetches on days 8,10,12... (7-day offset from Tier 2)
// This staggers them so they never both hit on the same day.
function shouldFetchTodayByTier(ch, tier) {
  const act = cache.channelActivity[ch.id] || {};
  if (act.nextFetchDue && Date.now() < act.nextFetchDue) return false;
  return true; // due date passed or never set — fetch it
}

// Alternates fetch order daily so different channels get priority when quota runs out
function getChannelFetchOrder(channels) {
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
  const reversed = dayOfYear % 2 === 1;
  return reversed ? [...channels].reverse() : [...channels];
}

const REDIS_TTL = {
  recentVideos:         7 * 24 * 60 * 60,  // 7 days  (was 25h — survives quota gaps)
  recentVideosInactive: 14 * 24 * 60 * 60, // 14 days for inactive-tier channels
  liveStatus:           5 * 24 * 60 * 60,  // 5 days  (was 24h — keeps last known state)
  playlist:             49 * 60 * 60,       // 49 hours (unchanged)
  channelActivity:      60 * 24 * 60 * 60, // 60 days — long-term per-channel activity
};

async function rSet(key, value, ttl) {
  if (!redis) return;
  try {
    if (ttl) await redis.setex(key, ttl, JSON.stringify(value));
    else await redis.set(key, JSON.stringify(value));
  } catch(e) { console.error('[Redis] SET error ' + key + ':', e.message); }
}

async function rGet(key) {
  if (!redis) return null;
  try {
    const v = await redis.get(key);
    return v ? JSON.parse(v) : null;
  } catch(e) { console.error('[Redis] GET error ' + key + ':', e.message); return null; }
}

async function rDel(key) {
  if (!redis) return;
  try { await redis.del(key); } catch(e) {}
}

async function rKeys(pattern) {
  if (!redis) return [];
  try { return await redis.keys(pattern); } catch(e) { return []; }
}

// Restore cache from Redis on startup — survives deploys and restarts
async function restoreCacheFromRedis() {
  if (!redis) return;
  try {
    console.log('[Redis] Restoring cache from Redis...');

    // Metadata
    const lastFetch = await rGet('wt:lastFetch');
    if (lastFetch) cache.lastRecentFetch = lastFetch;
    const lastLive = await rGet('wt:lastLive');
    if (lastLive) cache.lastLiveCheck = lastLive;
    const lastNotification = await rGet('wt:lastNotification');
    if (lastNotification) cache.lastNotificationReceived = lastNotification;
    const websubActive = await rGet('wt:websubActive');
    if (websubActive !== null) cache.websubActive = websubActive;

    // Live statuses
    const liveKeys = await rKeys('wt:live:*');
    for (const key of liveKeys) {
      const val = await rGet(key);
      if (val) cache.liveStatuses[key.replace('wt:live:', '')] = val;
    }

    // Recent videos
    const recentKeys = await rKeys('wt:recent:*');
    for (const key of recentKeys) {
      const val = await rGet(key);
      if (val) cache.recentVideos[key.replace('wt:recent:', '')] = val;
    }

    // Playlist
    const plKeys = await rKeys('wt:playlist:*');
    for (const key of plKeys) {
      const val = await rGet(key);
      if (val) cache.playlist[key.replace('wt:playlist:', '')] = val;
    }

    // Channel activity (tier tracking)
    const activityKeys = await rKeys('wt:activity:*');
    for (const key of activityKeys) {
      const val = await rGet(key);
      if (val) cache.channelActivity[key.replace('wt:activity:', '')] = val;
    }

    console.log('[Redis] Restored — ' + recentKeys.length + ' video caches, ' + liveKeys.length + ' live statuses, ' + activityKeys.length + ' activity records');
  } catch(e) {
    console.error('[Redis] Restore error:', e.message);
  }
}

// Intervals are configurable via admin panel — stored in channels.json config
// Defaults shown here, overridden by loadData().config values
const CACHE_TTL = {
  recentVideos: 24 * 60 * 60 * 1000,  // 24 hours default
  playlist:     48 * 60 * 60 * 1000,  // 48 hours (not configurable — rarely changes)
  liveCheck:    2 * 60 * 60 * 1000,   // 2 hours default — reduce to 15min after quota increase
};

function getLiveCheckInterval() {
  try {
    const cfg = loadData().config;
    if (cfg.liveCheckIntervalHours) return cfg.liveCheckIntervalHours * 60 * 60 * 1000;
  } catch(e) {}
  return CACHE_TTL.liveCheck;
}

function getRecentFetchHour() {
  try {
    const cfg = loadData().config;
    if (cfg.recentFetchHourEST !== undefined) return cfg.recentFetchHourEST;
  } catch(e) {}
  return 12; // noon EST default -- most forecasters have their daily forecast posted by then
}

// ── Helper: get channels eligible for live check based on time (EST) ──
// Forecasters: checked 6am-2am EST (stop 2am-6am)
// Chasers/Creators: checked 6am-midnight EST (stop midnight-6am)
function getLiveChannels() {
  const channels = [];
  try {
    const data = loadData();
    if (!data.groups) return channels;

    // Current hour in EST
    const estNow = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }));
    const estHour = estNow.getHours(); // 0-23

    // Forecaster group ID — only they get the extended 2am window
    const FORECASTER_GROUP = 'forecasters';

    data.groups.forEach(g => {
      g.channels.forEach(ch => {
        if (!ch.hasLive || ch.enabled === false) return;

        if (g.id === FORECASTER_GROUP) {
          // Forecasters: active 6am-2am EST (pause 2am-6am)
          const active = estHour >= 6 || estHour < 2;
          if (active) channels.push({ ...ch, _group: g.id });
        } else {
          // All others: active 6am-midnight EST (pause midnight-6am)
          const active = estHour >= 6 && estHour < 24;
          if (active) channels.push({ ...ch, _group: g.id });
        }
      });
    });
  } catch(e) {}
  return channels;
}

// ── Helper: get all enabled channels ──
function getAllChannels() {
  const channels = [];
  try {
    const data = loadData();
    if (data.groups) {
      data.groups.forEach(g => {
        g.channels.forEach(ch => {
          if (ch.enabled !== false) channels.push(ch);
        });
      });
    }
  } catch(e) {}
  return channels;
}

// ════════════════════════════════════════════
// LIVE STATUS — channels endpoint (1 unit each vs 100 for search)
// Uses YouTube's channels API to check if a channel has an active
// live broadcast — costs 1 unit per channel instead of 100
// ════════════════════════════════════════════
async function checkLiveStatus(channelId) {
  const key = getApiKey();
  // Use search with eventType=live — the only reliable live detection method
  // Costs 100 units per channel but is accurate
  const url = 'https://www.googleapis.com/youtube/v3/search?key=' + key +
    '&channelId=' + channelId + '&part=id&eventType=live&type=video';
  const data = await ytFetch(url);
  if (checkQuotaError(data)) { markQuotaExceeded(true); throw new Error('quota_exceeded'); }
  return !!(data.items && data.items.length > 0);
}

// ── Scheduled Live Check ──
// WebSub handles real-time live detection on Railway (zero quota cost)
// This poll runs every 4 hours as a safety net catch-all
// Uses search?eventType=live (100 units/channel) — accurate but expensive
// Time-aware: chasers/creators stop at midnight EST, forecasters at 2am EST
// IMPORTANT: Submit quota increase request at console.cloud.google.com
async function scheduledLiveCheck() {
  if (cache.websubActive) {
    console.log('[WeatherTV] WebSub active — skipping poll-based live check');
    return;
  }
  if (primaryQuotaExceeded) {
    console.log('[WeatherTV] Skipping live check — primary key quota exceeded');
    return;
  }

  const key = getApiKey();
  if (!key || key === 'YOUR_YOUTUBE_API_KEY') return;

  const channels = getLiveChannels();
  if (channels.length === 0) {
    console.log('[WeatherTV] No channels configured yet for live check');
    return;
  }

  const estHour = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })).getHours();
  console.log('[WeatherTV] Running live check (' + channels.length + ' channels, 100 units each = ' + (channels.length * 100) + ' units) — EST hour: ' + estHour + '...');
  let liveCount = 0;

  for (const ch of channels) {
    try {
      const isLive = await checkLiveStatus(ch.id);
      const liveEntry = { isLive, checkedAt: Date.now(), source: 'poll' };
      cache.liveStatuses[ch.id] = liveEntry;
      rSet('wt:live:' + ch.id, liveEntry, REDIS_TTL.liveStatus);
      if (isLive) liveCount++;
      await new Promise(r => setTimeout(r, 100));
    } catch(e) {
      if (e.message === 'quota_exceeded') break;
      console.error('[WeatherTV] Live check error for ' + ch.id + ':', e.message);
    }
  }

  cache.lastLiveCheck = Date.now();
  await rSet('wt:lastLive', cache.lastLiveCheck);
  console.log('[WeatherTV] Live check complete — ' + liveCount + ' channel(s) live (' + (channels.length * 100) + ' units used)');

  // No automatic rescheduling — this function is called manually via admin panel only
  // WebSub handles ongoing live detection
}

// Scheduled live polling removed — WebSub handles real-time live detection at zero quota cost
// YouTube notifies us instantly when a channel goes live via WebSub push
// Use the manual 'Check Now' button in admin panel if you need to verify live status
// The scheduledLiveCheck function is still available for the manual Check Now button
console.log('[WeatherTV] Live detection via WebSub only — no scheduled polling');

// Startup live check — only checks channels with no cached status in Redis
// Catches channels that were already live before server subscribed to WebSub
// Disabled until quota increase approved — set STARTUP_LIVE_CHECK=true to enable
if (process.env.STARTUP_LIVE_CHECK === 'true') {
  setTimeout(async () => {
    if (primaryQuotaExceeded) return;
    const channels = getLiveChannels();
    const unchecked = channels.filter(ch => !cache.liveStatuses[ch.id]);
    if (unchecked.length === 0) {
      console.log('[WeatherTV] Startup live check — all channels already have cached status');
      return;
    }
    console.log('[WeatherTV] Startup live check for ' + unchecked.length + ' unchecked channels (' + (unchecked.length * 100) + ' units)...');
    const key = getApiKey();
    if (!key) return;
    for (const ch of unchecked) {
      if (primaryQuotaExceeded) break;
      try {
        const isLive = await checkLiveStatus(ch.id);
        const liveEntry = { isLive, checkedAt: Date.now(), source: 'startup' };
        cache.liveStatuses[ch.id] = liveEntry;
        rSet('wt:live:' + ch.id, liveEntry, REDIS_TTL.liveStatus);
        if (isLive) console.log('[WeatherTV] Startup check — ' + ch.name + ' is LIVE');
        await new Promise(r => setTimeout(r, 150));
      } catch(e) {
        if (e.message === 'quota_exceeded') break;
      }
    }
    cache.lastLiveCheck = Date.now();
    rSet('wt:lastLive', cache.lastLiveCheck);
    console.log('[WeatherTV] Startup live check complete');
  }, 5000);
}

// ════════════════════════════════════════════
// WEBSUB / PUBSUBHUBBUB
// YouTube pushes notifications when a channel goes live or posts a video
// Zero quota cost — YouTube calls us instead of us calling YouTube
// Requires a public URL (Railway) — not available on localhost
// ════════════════════════════════════════════
const WEBSUB_HUB = 'https://pubsubhubbub.appspot.com/subscribe';
const WEBSUB_LEASE = 9 * 24 * 60 * 60; // 9 days in seconds (max is 10)
const rawBodyParser = express.raw({ type: 'application/atom+xml', limit: '1mb' });

// Subscribe a single channel to WebSub
async function websubSubscribe(channelId) {
  const baseUrl = process.env.APP_URL;
  if (!baseUrl) return; // Not deployed yet

  const callbackUrl = baseUrl + '/websub/callback/' + channelId;
  const topicUrl = 'https://www.youtube.com/xml/feeds/videos.xml?channel_id=' + channelId;

  const body = new URLSearchParams({
    'hub.callback':     callbackUrl,
    'hub.topic':        topicUrl,
    'hub.verify':       'async',
    'hub.mode':         'subscribe',
    'hub.lease_seconds': String(WEBSUB_LEASE),
    'hub.secret':       process.env.WEBSUB_SECRET || 'weathertv-secret'
  });

  return new Promise((resolve, reject) => {
    const postData = body.toString();
    const opts = {
      hostname: 'pubsubhubbub.appspot.com',
      path: '/subscribe',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    const req = https.request(opts, res => {
      const now = Date.now();
      const status = res.statusCode >= 200 && res.statusCode < 300 ? 'active' : 'failed';
      const expiresAt = now + WEBSUB_LEASE * 1000;
      websubLeases[channelId] = {
        subscribedAt: now,
        expiresAt,
        status,
        statusCode: res.statusCode,
      };
      // Persist expiry so restarts don't re-subscribe still-valid channels
      if (res.statusCode >= 200 && res.statusCode < 300) rSet('wt:ws:' + channelId, expiresAt);
      console.log('[WebSub] Subscribe response for ' + channelId + ': ' + res.statusCode);
      if (status === 'failed') {
        const ch = getAllChannels().find(c => c.id === channelId);
        logFetchError(channelId, ch ? ch.name : channelId, 'WebSub subscribe failed — HTTP ' + res.statusCode);
      }
      resolve(res.statusCode);
    });
    req.on('error', e => {
      websubLeases[channelId] = { subscribedAt: Date.now(), expiresAt: null, status: 'error', error: e.message };
      const ch = getAllChannels().find(c => c.id === channelId);
      logFetchError(channelId, ch ? ch.name : channelId, 'WebSub subscribe error — ' + e.message);
      reject(e);
    });
    req.write(postData);
    req.end();
  });
}

// ── Live Verifier — zero-quota secondary live check ──────────────────────────
// Loads youtube.com/channel/{id}/live directly to confirm live status, catching
// streams WebSub misses and clearing stale lives. Uses getLiveChannels(), so it
// follows the same hasLive flag and overnight quiet hours as the rest of live
// detection. Admin page: /admin/live-verifier (behind adminAuth via app.use('/admin')).
// Enable with LIVE_VERIFIER=true; interval via LIVE_VERIFIER_INTERVAL_MIN (default 4).
const liveVerifier = createLiveVerifier({
  // lastLiveDate drives how often each channel is checked (see TIERS in live-verifier.js)
  getChannels: async () => getLiveChannels().map(ch => ({ id: ch.id, name: ch.name, lastLiveDate: (cache.channelActivity[ch.id] || {}).lastLiveDate || null })),
  // Severe weather → check every channel every sweep: any active Tornado or
  // Extreme Wind Warning, or a named Atlantic storm (from the NHC proxy cache)
  isSevereActive: async () => {
    const warnings = (radar.getActiveStormWarnings() || {}).list || [];
    if (warnings.some(w => w.event === 'Tornado Warning' || w.event === 'Extreme Wind Warning')) return true;
    const nhc = _nhcCache.data && Date.now() - _nhcCache.ts < 6 * 3600 * 1000 ? _nhcCache.data.activeStorms || [] : [];
    return nhc.some(st => /^al/i.test(st.id || '') && /^(HU|TS)$/i.test(st.classification || ''));
  },
  // "Known" = WTV is already showing THIS stream (same videoId when both are known)
  isKnownLive: async (channelId, videoId) => {
    const s = cache.liveStatuses[channelId];
    return !!(s && s.isLive && (!videoId || !s.videoId || s.videoId === videoId));
  },
  onLive: async (r) => {
    const entry = { isLive: true, videoId: r.videoId, checkedAt: Date.now(), source: r.wasKnown ? (cache.liveStatuses[r.channelId]?.source || 'verifier') : 'verifier' };
    cache.liveStatuses[r.channelId] = entry;   // refreshing checkedAt keeps 12h auto-expiry from killing long streams
    cache.lastLiveCheck = Date.now();
    rSet('wt:live:' + r.channelId, entry, REDIS_TTL.liveStatus);
    rSet('wt:lastLive', cache.lastLiveCheck);
    if (!r.wasKnown) {
      updateChannelActivity(r.channelId, { lastLiveDate: Date.now() });
      console.log('[LiveVerifier] LIVE (missed by WebSub): ' + r.channelId + ' video: ' + r.videoId);
    }
  },
  onOffline: async (channelId) => {
    const entry = { isLive: false, videoId: null, checkedAt: Date.now(), source: 'verifier' };
    cache.liveStatuses[channelId] = entry;
    rSet('wt:live:' + channelId, entry, REDIS_TTL.liveStatus);
    console.log('[LiveVerifier] OFFLINE (stale live cleared): ' + channelId);
  },
  store: { get: rGet, set: rSet },
  sweepIntervalMs: (Number(process.env.LIVE_VERIFIER_INTERVAL_MIN) || 4) * 60 * 1000,
});
liveVerifier.mountAdmin(app); // /admin/live-verifier, /admin/live-verifier/data, /run, /check/:channelId

// ── Startup sequence ──
// Restore app data and cache from Redis first
(async () => {
  await restoreAppDataFromRedis();  // groups, channels, collections
  await restoreCacheFromRedis();    // video cache, live statuses

  // Start verifier only after live statuses are restored — otherwise run #1
  // would count every already-live channel as a WebSub miss
  // Case-insensitive value: true / TRUE / 1 / yes / on all enable it
  if (/^(true|1|yes|on)$/i.test((process.env.LIVE_VERIFIER || '').trim())) liveVerifier.start();
  else console.log('[LiveVerifier] Disabled — LIVE_VERIFIER is "' + (process.env.LIVE_VERIFIER || '(unset)') + '" (variable name must be all caps: LIVE_VERIFIER=true)');

  // Check if today's scheduled fetch was missed
  // Compare dates not just timestamps to prevent double-fetching on same day
  const fetchHour = getRecentFetchHour();
  const estNow = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const estHour = estNow.getHours();
  const lastFetch = cache.lastRecentFetch;

  let missedFetch = false;
  if (estHour >= fetchHour) {
    if (!lastFetch) {
      // Never fetched — run now
      missedFetch = true;
    } else {
      // Check if last fetch was before today's scheduled fetch time
      const lastFetchEST = new Date(new Date(lastFetch).toLocaleString('en-US', { timeZone: 'America/New_York' }));
      const fetchedTodayAfterSchedule = 
        lastFetchEST.toDateString() === estNow.toDateString() && 
        lastFetchEST.getHours() >= fetchHour;
      missedFetch = !fetchedTodayAfterSchedule;
    }
  }

  if (missedFetch) {
    console.log('[WeatherTV] Missed scheduled fetch detected — running now (last fetch: ' + (lastFetch ? new Date(lastFetch).toLocaleString() : 'never') + ')');
    fetchAllRecentVideos(); // don't await — run in background
  } else {
    const minsAgo = lastFetch ? Math.round((Date.now() - lastFetch) / 60000) : null;
    console.log('[WeatherTV] No missed fetch — ' + (minsAgo ? 'last fetch ' + minsAgo + 'm ago' : 'before scheduled time'));
  }
  scheduleNextRecentFetch();
})();

// Subscribe all hasLive channels on startup (only when APP_URL is set)
async function subscribeAllChannels() {
  if (!process.env.APP_URL) {
    console.log('[WebSub] APP_URL not set — WebSub disabled (expected on localhost)');
    return;
  }

  const channels = getLiveChannels();
  const RENEW_WINDOW = 24 * 60 * 60 * 1000; // re-subscribe if expiring within 24h
  const now = Date.now();

  // Check Redis for existing valid subscriptions — skip channels that don't
  // need re-subscribing. This makes restarts after recent deploys near-instant
  // instead of blocking for 60+ seconds re-subscribing every channel.
  const toSubscribe = [];
  let skipped = 0;
  for (const ch of channels) {
    try {
      const stored = await rGet('wt:ws:' + ch.id);
      if (stored !== null && stored !== undefined) {
        const expiresAt = typeof stored === 'number' ? stored : parseInt(String(stored), 10);
        if (!isNaN(expiresAt) && expiresAt - now > RENEW_WINDOW) {
          websubLeases[ch.id] = { subscribedAt: null, expiresAt, status: 'active' };
          skipped++;
          continue;
        }
      }
    } catch(_) { /* Redis unavailable — subscribe to be safe */ }
    toSubscribe.push(ch);
  }

  if (toSubscribe.length === 0) {
    cache.websubActive = true;
    rSet('wt:websubActive', true);
    console.log(`[WebSub] All ${channels.length} subscriptions still valid — skipped hub calls`);
    return;
  }

  console.log(`[WebSub] Subscribing ${toSubscribe.length}/${channels.length} channels (${skipped} still valid)...`);

  for (const ch of toSubscribe) {
    try {
      await websubSubscribe(ch.id);
      await new Promise(r => setTimeout(r, 500));
    } catch(e) {
      console.error('[WebSub] Subscribe error for ' + ch.name + ':', e.message);
    }
  }

  cache.websubActive = true;
  rSet('wt:websubActive', true);
  console.log('[WebSub] Subscription refresh complete — push notifications active');
}

// WebSub verification handshake — YouTube calls this to confirm subscription
app.get('/websub/callback/:channelId', (req, res) => {
  const challenge = req.query['hub.challenge'];
  const mode = req.query['hub.mode'];
  console.log('[WebSub] Verification for ' + req.params.channelId + ' mode=' + mode);
  if (challenge) {
    res.status(200).send(challenge);
  } else {
    res.status(400).send('No challenge');
  }
});

// WebSub notification — YouTube pushes this when a channel posts or goes live
// Rate limit: only do API live check if we haven't checked this channel in last 10 minutes
const websubLastCheck = {}; // channelId -> timestamp
const WEBSUB_RATE_LIMIT_MS = 10 * 60 * 1000; // 10 minutes

app.post('/websub/callback/:channelId', rawBodyParser, (req, res) => {
  res.status(200).send('OK'); // Always respond quickly

  const channelId = req.params.channelId;
  const body = req.body ? req.body.toString() : '';

  // Track that YouTube pushed a notification to us (free, 0 units)
  cache.lastNotificationReceived = Date.now();
  rSet('wt:lastNotification', cache.lastNotificationReceived);

  // Step 1: Parse Atom feed — free, no quota cost
  // Extract video ID and live status directly from the feed XML
  const videoIdMatch = body.match(/<yt:videoId>([^<]+)<\/yt:videoId>/);
  const feedVideoId = videoIdMatch ? videoIdMatch[1].trim() : null;
  const feedIsLive     = body.includes('<yt:liveBroadcastContent>live</yt:liveBroadcastContent>');
  const feedIsUpcoming = body.includes('<yt:liveBroadcastContent>upcoming</yt:liveBroadcastContent>');

  // Step 2: If feed explicitly says LIVE — trust it, mark immediately, no API call (0 units)
  if (feedIsLive && feedVideoId) {
    const wasLive = cache.liveStatuses[channelId] && cache.liveStatuses[channelId].isLive;
    const wsEntry = { isLive: true, videoId: feedVideoId, checkedAt: Date.now(), source: 'websub_feed' };
    cache.liveStatuses[channelId] = wsEntry;
    cache.lastLiveCheck = Date.now();
    rSet('wt:live:' + channelId, wsEntry, REDIS_TTL.liveStatus);
    rSet('wt:lastLive', cache.lastLiveCheck);
    updateChannelActivity(channelId, { lastLiveDate: Date.now() });
    websubLastCheck[channelId] = Date.now();
    if (!wasLive) console.log('[WebSub] LIVE (feed confirmed, 0 units): ' + channelId + ' video: ' + feedVideoId);
    delete cache.recentVideos[channelId];
    rDel('wt:recent:' + channelId);
    return;
  }

  // Step 3: If feed says UPCOMING — note it, no API call needed
  if (feedIsUpcoming) {
    console.log('[WebSub] ' + channelId + ' has upcoming stream (0 units)');
    delete cache.recentVideos[channelId];
    rDel('wt:recent:' + channelId);
    return;
  }

  // Step 4: Feed is ambiguous (regular video post, no live indicator)
  // Invalidate recent video cache — content changed
  delete cache.recentVideos[channelId];
  rDel('wt:recent:' + channelId);

  // Step 5: Rate limit — skip confirmation API call if we checked this channel recently
  const lastCheck = websubLastCheck[channelId] || 0;
  const timeSinceCheck = Date.now() - lastCheck;
  const recentlyChecked = timeSinceCheck < WEBSUB_RATE_LIMIT_MS;
  if (recentlyChecked) {
    console.log('[WebSub] ' + channelId + ' posted content (checked ' + Math.round(timeSinceCheck/60000) + 'm ago — skipping confirmation)');
    return;
  }

  // Step 6: Ambiguous — use videos.list?part=liveStreamingDetails for 1 unit (not 100)
  // This checks if the specific video from the notification is an active live stream
  const liveChecksToday = getLiveChecksToday();
  if (!primaryQuotaExceeded && liveChecksToday < DAILY_LIVE_CHECK_LIMIT) {
    const key = getApiKey();
    if (key && key !== 'YOUR_YOUTUBE_API_KEY' && feedVideoId) {
      websubLastCheck[channelId] = Date.now();
      recordLiveCheck();
      trackBurn(true, 1); // videos.list costs 1 unit, not 100
      console.log('[WebSub] Live detail check (1 unit) for ' + channelId + ' video: ' + feedVideoId);
      const url = 'https://www.googleapis.com/youtube/v3/videos?key=' + key +
        '&id=' + feedVideoId + '&part=liveStreamingDetails&fields=items/liveStreamingDetails';
      ytFetch(url).then(data => {
        if (checkQuotaError(data)) { markQuotaExceeded(true); return; }
        const details = data.items && data.items[0] && data.items[0].liveStreamingDetails;
        // Active live stream: has actualStartTime but no actualEndTime
        const isLive = !!(details && details.actualStartTime && !details.actualEndTime);
        const wasLive = cache.liveStatuses[channelId] && cache.liveStatuses[channelId].isLive;
        const wsEntry = { isLive, videoId: isLive ? feedVideoId : null, checkedAt: Date.now(), source: 'websub_details' };
        cache.liveStatuses[channelId] = wsEntry;
        cache.lastLiveCheck = Date.now();
        rSet('wt:live:' + channelId, wsEntry, REDIS_TTL.liveStatus);
        rSet('wt:lastLive', cache.lastLiveCheck);
        if (isLive) updateChannelActivity(channelId, { lastLiveDate: Date.now() });
        if (isLive && !wasLive)  console.log('[WebSub] LIVE CONFIRMED (1 unit): ' + channelId);
        else if (!isLive && wasLive) console.log('[WebSub] OFFLINE: ' + channelId + ' stream ended');
        else console.log('[WebSub] ' + channelId + ' posted content (not live)');
      }).catch(e => console.error('[WebSub] Detail check error for ' + channelId + ':', e.message));
    } else if (!feedVideoId) {
      // No video ID in notification — fall back to search (100 units) as last resort
      const key = getApiKey();
      if (key && key !== 'YOUR_YOUTUBE_API_KEY') {
        websubLastCheck[channelId] = Date.now();
        recordLiveCheck();
        trackBurn(true, 100);
        console.log('[WebSub] No video ID — fallback search check for ' + channelId);
        const url = 'https://www.googleapis.com/youtube/v3/search?key=' + key +
          '&channelId=' + channelId + '&part=id&eventType=live&type=video';
        ytFetch(url).then(data => {
          if (checkQuotaError(data)) { markQuotaExceeded(true); return; }
          const isLive = !!(data.items && data.items.length > 0);
          const videoId = isLive && data.items[0].id ? data.items[0].id.videoId : null;
          const wasLive = cache.liveStatuses[channelId] && cache.liveStatuses[channelId].isLive;
          const wsEntry = { isLive, videoId, checkedAt: Date.now(), source: 'websub_search' };
          cache.liveStatuses[channelId] = wsEntry;
          cache.lastLiveCheck = Date.now();
          rSet('wt:live:' + channelId, wsEntry, REDIS_TTL.liveStatus);
          rSet('wt:lastLive', cache.lastLiveCheck);
          if (isLive) updateChannelActivity(channelId, { lastLiveDate: Date.now() });
          if (isLive && !wasLive) console.log('[WebSub] LIVE CONFIRMED (search): ' + channelId);
          else if (!isLive && wasLive) console.log('[WebSub] OFFLINE: ' + channelId);
        }).catch(e => console.error('[WebSub] Search error for ' + channelId + ':', e.message));
      }
    }
  } else {
    console.log('[WebSub] ' + channelId + ' posted — skipping check (daily limit reached or quota exceeded)');
  }
});

// Re-subscribe all channels every 8 days (before 9-day lease expires)
setInterval(() => {
  if (process.env.APP_URL) {
    console.log('[WebSub] Renewing subscriptions...');
    subscribeAllChannels();
  }
}, 8 * 24 * 60 * 60 * 1000);

// Admin endpoint to manually trigger re-subscription
app.post('/api/admin/websub/subscribe', async (req, res) => {
  if (!process.env.APP_URL) {
    return res.status(400).json({ error: 'APP_URL not configured — WebSub requires a public URL' });
  }
  await subscribeAllChannels();
  res.json({ ok: true, message: 'WebSub subscriptions renewed for all channels' });
});

// Admin endpoint to resubscribe a single channel — for fixing one FAILED row
// in the WebSub Health panel without resubscribing all 200+ channels (each
// full resubscribe takes ~500ms/channel and risks rate limiting from the hub).
app.post('/api/admin/websub/subscribe/:channelId', async (req, res) => {
  if (!process.env.APP_URL) {
    return res.status(400).json({ error: 'APP_URL not configured — WebSub requires a public URL' });
  }
  const { channelId } = req.params;
  try {
    const statusCode = await websubSubscribe(channelId);
    const lease = websubLeases[channelId];
    res.json({ ok: true, statusCode, status: lease ? lease.status : 'unknown' });
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

// Start WebSub subscriptions after boot (10s delay)
setTimeout(subscribeAllChannels, 10000);

// ════════════════════════════════════════════
// SCHEDULED RECENT VIDEO FETCHER
// Runs twice daily (noon + 6pm EST) — fetches recent videos for all channels.
// Uses playlistItems.list at 1 unit/channel (vs. search.list at 100 units).
// At 146 channels: ~146 units per run × 2 runs = ~292 units/day on primary.
// Archive key (YOUTUBE_API_KEY_2) activates only if primary quota is exceeded.
// All users served from cache — zero additional quota per request.
// ════════════════════════════════════════════

// Derive a channel's uploads playlist ID from its channel ID.
// YouTube uploads playlist is always 'UU' + channelId.slice(2)
// e.g. UCxxxxxx → UUxxxxxx — no extra API call required.
function getUploadsPlaylistId(channelId) {
  if (!channelId || !channelId.startsWith('UC')) return null;
  return 'UU' + channelId.slice(2);
}

async function fetchAllRecentVideos() {
  // Each key's quotaExceeded flag auto-clears via its own midnight-Pacific
  // timer (set in markQuotaExceeded). If BOTH keys are currently exhausted,
  // there's nothing this cycle can do -- reschedule for next time.
  if (primaryQuotaExceeded && archiveQuotaExceeded) {
    console.log('[WeatherTV] Skipping recent video fetch -- both API keys exhausted');
    scheduleNextRecentFetch();
    return;
  }

  const primaryKey = getApiKey();
  const archiveKey = getArchiveApiKey();

  const allChannels = getAllChannels();
  if (allChannels.length === 0) return;

  // Assign tiers
  const tier1 = [], tier2 = [], tier3 = [];
  for (const ch of allChannels) {
    const tier = getChannelTier(ch);
    if (tier === 1) tier1.push(ch);
    else if (tier === 2) tier2.push(ch);
    else tier3.push(ch);
  }

  // Stagger Tier 2 and Tier 3 using day of year -- 7-day natural offset between them
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
  const fetchTier2Today = dayOfYear % 2 === 0;
  const fetchTier3Today = dayOfYear % 2 === 1;

  const tier2Due = fetchTier2Today ? tier2.filter(ch => shouldFetchTodayByTier(ch, 2)) : [];
  const tier3Due = fetchTier3Today ? tier3.filter(ch => shouldFetchTodayByTier(ch, 3)) : [];

  // Extend TTL on inactive channels not being fetched today
  const notFetchingToday = [
    ...(fetchTier2Today ? [] : tier2),
    ...(fetchTier3Today ? [] : tier3),
    ...(fetchTier2Today ? tier2.filter(ch => !shouldFetchTodayByTier(ch, 2)) : []),
    ...(fetchTier3Today ? tier3.filter(ch => !shouldFetchTodayByTier(ch, 3)) : []),
  ];
  for (const ch of notFetchingToday) {
    if (cache.recentVideos[ch.id] && cache.recentVideos[ch.id].items) {
      await rSet('wt:recent:' + ch.id, cache.recentVideos[ch.id], REDIS_TTL.recentVideosInactive);
    }
  }

  // Tier 1 first (priority), then due Tier 2 and 3 -- alternate A-Z / Z-A daily
  const priorityChannels = getChannelFetchOrder([...tier1, ...tier2Due, ...tier3Due]);

  console.log('[WeatherTV] Fetch -- Tier1: ' + tier1.length +
    ', Tier2 today: ' + tier2Due.length + '/' + tier2.length +
    ', Tier3 today: ' + tier3Due.length + '/' + tier3.length +
    ' | Order: ' + (dayOfYear % 2 === 0 ? 'A to Z' : 'Z to A'));

  let fetched = 0, skipped = 0;
  const fetchedIds = new Set();

  for (let i = 0; i < priorityChannels.length; i++) {
    const ch = priorityChannels[i];

    // Use primary key; fall back to archive key if primary is exhausted
    let useKey = null;
    let isPrimary = true;
    if (!primaryQuotaExceeded && primaryKey && primaryKey !== 'YOUR_YOUTUBE_API_KEY') {
      useKey = primaryKey;
      isPrimary = true;
    } else if (!archiveQuotaExceeded && archiveKey && archiveKey !== 'YOUR_YOUTUBE_API_KEY' && archiveKey !== primaryKey) {
      useKey = archiveKey;
      isPrimary = false;
      if (i === 0) console.warn('[WeatherTV] Primary key exhausted — falling back to archive key for recent fetch');
    }

    if (!useKey) {
      skipped++;
      continue;
    }

    // Use playlistItems.list (1 unit) via the channel's uploads playlist
    // instead of search.list (100 units) — 100x more efficient.
    const playlistId = getUploadsPlaylistId(ch.id);
    if (!playlistId) {
      skipped++;
      console.warn('[WeatherTV] Cannot derive uploads playlist for ' + ch.id + ' — skipping');
      continue;
    }

    try {
      const url = 'https://www.googleapis.com/youtube/v3/playlistItems?key=' + useKey +
        '&playlistId=' + playlistId + '&part=snippet&maxResults=10';
      const data = await ytFetch(url);

      if (checkQuotaError(data)) {
        markQuotaExceeded(isPrimary);
        skipped++;
        console.warn('[WeatherTV] ' + (isPrimary ? 'Primary' : 'Archive') + ' key quota hit at channel ' + (i + 1) + '/' + priorityChannels.length);
        continue;
      }

      trackBurn(isPrimary, 1); // playlistItems.list costs 1 unit (vs. 100 for search.list)

      const rawItems = data.items || [];

      // Normalize playlistItems snippet to match the shape search.list returned,
      // so downstream cache consumers (recent video panel, etc.) don't need changes.
      // playlistItems snippet.resourceId.videoId → simulate id.videoId
      const newItems = rawItems.map(item => ({
        id: { videoId: item.snippet?.resourceId?.videoId || '' },
        snippet: {
          title: item.snippet?.title || '',
          description: item.snippet?.description || '',
          publishedAt: item.snippet?.publishedAt || '',
          channelTitle: item.snippet?.channelTitle || '',
          channelId: item.snippet?.channelId || ch.id,
          liveBroadcastContent: item.snippet?.liveBroadcastContent || 'none',
          thumbnails: item.snippet?.thumbnails || {},
        },
      }));

      // Free live detection from snippet data (same as before)
      const liveItem = newItems.find(item => item.snippet && item.snippet.liveBroadcastContent === 'live');
      if (liveItem) {
        const videoId = liveItem.id && liveItem.id.videoId ? liveItem.id.videoId : null;
        const liveEntry = { isLive: true, videoId, checkedAt: Date.now(), source: 'recent_fetch' };
        cache.liveStatuses[ch.id] = liveEntry;
        rSet('wt:live:' + ch.id, liveEntry, REDIS_TTL.liveStatus);
        updateChannelActivity(ch.id, { lastLiveDate: Date.now() });
        console.log('[WeatherTV] Live detected during fetch: ' + ch.id + (videoId ? ' (' + videoId + ')' : ''));
      }

      // Update last video date for tier tracking
      if (newItems.length > 0 && newItems[0].snippet && newItems[0].snippet.publishedAt) {
        const lastVideoDate = new Date(newItems[0].snippet.publishedAt).getTime();
        await updateChannelActivity(ch.id, { lastVideoDate });
      }

      const tier = getChannelTier(ch);
      const ttl = tier === 1 ? REDIS_TTL.recentVideos : REDIS_TTL.recentVideosInactive;

      if (newItems.length > 0) {
        cache.recentVideos[ch.id] = { items: newItems, cachedAt: Date.now() };
        await rSet('wt:recent:' + ch.id, cache.recentVideos[ch.id], ttl);
        if (tier !== 1) await updateChannelActivity(ch.id, { nextFetchDue: Date.now() + 14 * 86400000 });
        fetched++;
        fetchedIds.add(ch.id);
      } else if (cache.recentVideos[ch.id] && cache.recentVideos[ch.id].items && cache.recentVideos[ch.id].items.length > 0) {
        cache.recentVideos[ch.id].cachedAt = Date.now();
        await rSet('wt:recent:' + ch.id, cache.recentVideos[ch.id], ttl);
        if (tier !== 1) await updateChannelActivity(ch.id, { nextFetchDue: Date.now() + 14 * 86400000 });
        fetched++;
        fetchedIds.add(ch.id);
      } else {
        console.log('[WeatherTV] No videos found for ' + ch.id + ' -- may have wrong channel ID or empty uploads playlist');
        fetchedIds.add(ch.id);
      }

      await new Promise(r => setTimeout(r, 100)); // lighter stagger since 1-unit calls are far cheaper
    } catch(e) {
      console.error('[WeatherTV] Fetch error for ' + ch.id + ':', e.message);
      logFetchError(ch.id, ch.name, e.message);
    }
  }

  cache.lastRecentFetch = Date.now();
  await rSet('wt:lastFetch', cache.lastRecentFetch);

  // Preserve caches for any channel we didn't reach this cycle
  for (const ch of priorityChannels) {
    if (!fetchedIds.has(ch.id)) {
      const cached = cache.recentVideos[ch.id];
      if (cached && cached.items && cached.items.length > 0) {
        await rSet('wt:recent:' + ch.id, cached, REDIS_TTL.recentVideosInactive);
      }
    }
  }

  if (skipped > 0) {
    console.log('[WeatherTV] Fetch complete -- ' + fetched + '/' + priorityChannels.length + ' updated, ' + skipped + ' skipped (key quota), caches preserved');
  } else {
    console.log('[WeatherTV] Fetch complete -- ' + fetched + '/' + priorityChannels.length + ' channels updated (~' + fetched + ' units used)');
  }

  scheduleNextRecentFetch();
}
function getSecondFetchHour() {
  try {
    const cfg = loadData().config;
    if (cfg.recentFetchHour2EST !== undefined) return cfg.recentFetchHour2EST;
  } catch(e) {}
  return 18; // 6pm EST default -- catches afternoon/evening storm content and late daily forecasts
}

function scheduleNextRecentFetch() {
  const fetchHour1 = getRecentFetchHour();  // noon EST (default)
  const fetchHour2 = getSecondFetchHour();  // 6pm EST (default)

  const now = new Date();
  const estNow = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));

  // Build candidate times for today
  const next1 = new Date(estNow); next1.setHours(fetchHour1, 0, 0, 0);
  const next2 = new Date(estNow); next2.setHours(fetchHour2, 0, 0, 0);

  // Find the next upcoming fetch time; if both have passed today, use noon tomorrow
  let nextFetch = null;
  if (estNow < next1) {
    nextFetch = next1;
  } else if (estNow < next2) {
    nextFetch = next2;
  } else {
    nextFetch = new Date(next1);
    nextFetch.setDate(nextFetch.getDate() + 1);
  }

  const msUntilNext = nextFetch - estNow;
  const minsUntilNext = Math.round(msUntilNext / 60000);
  console.log('[WeatherTV] Next recent video fetch in ' + minsUntilNext + ' minutes (' + nextFetch.getHours() + ':00 EST)');
  setTimeout(fetchAllRecentVideos, msUntilNext);
}



// ── API Routes ──

// Live status — served from cache, no API call per request
app.get('/api/yt/live/:channelId', (req, res) => {
  const cached = cache.liveStatuses[req.params.channelId];
  if (cached) {
    return res.json({
      items: cached.isLive ? [{ id: cached.videoId || 'live' }] : [],
      _cached: true,
      _checkedAt: cached.checkedAt
    });
  }
  res.json({ items: [], _cached: false });
});

// All live statuses at once — lets frontend get everything in one call
app.get('/api/yt/live-all', (req, res) => {
  const LIVE_STATUS_MAX_AGE = 12 * 60 * 60 * 1000; // 12 hours
  const now = Date.now();

  // Auto-expire stale live statuses — YouTube does not notify us when streams end.
  // Any isLive:true status older than 12 hours is assumed ended.
  // Active streams get checkedAt refreshed by WebSub notifications and the daily recent-videos fetch.
  Object.entries(cache.liveStatuses).forEach(([channelId, status]) => {
    if (status.isLive && status.checkedAt && (now - status.checkedAt) > LIVE_STATUS_MAX_AGE) {
      const hoursOld = Math.round((now - status.checkedAt) / 3600000);
      console.log('[WeatherTV] Auto-expiring stale live status for ' + channelId + ' (' + hoursOld + 'h old)');
      const expired = { isLive: false, videoId: null, checkedAt: now, source: 'auto_expired' };
      cache.liveStatuses[channelId] = expired;
      rSet('wt:live:' + channelId, expired, REDIS_TTL.liveStatus);
    }
  });

  res.json({
    statuses: cache.liveStatuses,
    lastChecked: cache.lastLiveCheck,
    lastNotification: cache.lastNotificationReceived,
    quotaExceeded: primaryQuotaExceeded // live status uses the primary key
  });
});

// Recent videos — serve from cache whenever possible; only fetch when cache is empty and quota is available
app.get('/api/yt/recent/:channelId', async (req, res) => {
  const channelId = req.params.channelId;
  const cached = cache.recentVideos[channelId];

  // Rule: old data is always better than no data.
  // Serve cached data immediately if we have it, regardless of age or quota status.
  if (cached && cached.items && cached.items.length > 0) {
    const cacheAge = Date.now() - cached.cachedAt;
    const stale = cacheAge > CACHE_TTL.recentVideos;
    // If cache is fresh or quota is exceeded, just serve it — no API call needed
    if (!stale || archiveQuotaExceeded) {
      return res.json({ items: cached.items, _cached: true, _stale: stale });
    }
    // Cache is stale but quota is available — fall through to fetch fresh data below
    // We'll still serve stale if the fresh fetch fails
  }

  // No usable cache or stale cache with quota available — try fetching fresh
  if (archiveQuotaExceeded) {
    // Empty cache, quota exceeded — nothing we can do
    return res.status(429).json({ error: 'quota_exceeded', message: 'Daily YouTube quota reached — resets at midnight Pacific' });
  }

  const key = getArchiveApiKey();
  if (!key) return res.status(500).json({ error: 'No API key configured' });

  try {
    const url = `https://www.googleapis.com/youtube/v3/search?key=${key}&channelId=${channelId}&part=snippet&order=date&type=video&maxResults=10`;
    const data = await ytFetch(url);
    if (checkQuotaError(data)) {
      markQuotaExceeded();
      // Serve stale cache if available rather than returning an error
      if (cached && cached.items && cached.items.length > 0) {
        return res.json({ items: cached.items, _cached: true, _stale: true });
      }
      return res.status(429).json({ error: 'quota_exceeded', message: 'Daily YouTube quota reached — resets at midnight Pacific' });
    }
    const newItems = data.items || [];
    if (newItems.length > 0) {
      const entry = { items: newItems, cachedAt: Date.now() };
      cache.recentVideos[channelId] = entry;
      await rSet('wt:recent:' + channelId, entry, REDIS_TTL.recentVideos);
      res.json(data);
    } else if (cached && cached.items && cached.items.length > 0) {
      res.json({ items: cached.items, _cached: true, _preserved: true });
    } else {
      res.json({ items: [] });
    }
  } catch(e) {
    // Serve stale cache on any error rather than failing completely
    if (cached && cached.items && cached.items.length > 0) {
      return res.json({ items: cached.items, _cached: true, _stale: true });
    }
    res.status(500).json({ error: e.message });
  }
});

// Playlist items — cached for 6 hours
app.get('/api/yt/playlist/:playlistId', async (req, res) => {
  const playlistId = req.params.playlistId;

  // Serve from cache if fresh
  const cached = cache.playlist[playlistId];
  if (cached && (Date.now() - cached.cachedAt) < CACHE_TTL.playlist) {
    return res.json({ items: cached.items, _cached: true });
  }

  if (archiveQuotaExceeded) {
    return res.status(429).json({ error: 'quota_exceeded', message: 'Daily YouTube quota reached — resets at midnight Pacific' });
  }

  const key = getApiKey();
  if (!key) return res.status(500).json({ error: 'No API key configured' });

  try {
    const url = `https://www.googleapis.com/youtube/v3/playlistItems?key=${key}&playlistId=${playlistId}&part=snippet&maxResults=50`;
    const data = await ytFetch(url);
    if (checkQuotaError(data)) {
      markQuotaExceeded();
      return res.status(429).json({ error: 'quota_exceeded', message: 'Daily YouTube quota reached — resets at midnight Pacific' });
    }
    // Filter out deleted and private videos — they return with generic titles
    const allItems = data.items || [];
    const validItems = allItems.filter(item => {
      const title = item.snippet && item.snippet.title;
      if (!title) return false;
      if (title === 'Deleted video' || title === 'Private video') return false;
      // Also filter if thumbnail is missing (another sign of deleted/private)
      const thumb = item.snippet && item.snippet.thumbnails;
      if (!thumb || Object.keys(thumb).length === 0) return false;
      return true;
    });
    if (allItems.length !== validItems.length) {
      console.log('[WeatherTV] Playlist: filtered ' + (allItems.length - validItems.length) + ' deleted/private videos (' + validItems.length + ' valid)');
    }
    const plEntry = { items: validItems, cachedAt: Date.now() };
    cache.playlist[playlistId] = plEntry;
    rSet('wt:playlist:' + playlistId, plEntry, REDIS_TTL.playlist);
    res.json({ ...data, items: validItems });
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

// Quota status
app.get('/api/yt/quota-status', (req, res) => {
  res.json({
    quotaExceeded: primaryQuotaExceeded || archiveQuotaExceeded, // combined, for back-compat
    primaryQuotaExceeded,
    archiveQuotaExceeded,
    lastLiveCheck: cache.lastLiveCheck,
    lastNotificationReceived: cache.lastNotificationReceived,
    lastRecentFetch: cache.lastRecentFetch,
    liveChecksToday: getLiveChecksToday(),
    liveCheckLimit: DAILY_LIVE_CHECK_LIMIT,
    archiveKeyConfigured: !!(process.env.YOUTUBE_API_KEY_2),
    archiveKeyRole: 'emergency-standby',
    primaryQuotaLimit: 60000,
    archiveQuotaLimit: 10000,
  });
});

// Manual trigger for live check — for diagnostics
app.post('/api/admin/trigger-live-check', async (req, res) => {
  res.json({ ok: true, message: 'Live check triggered' });
  await scheduledLiveCheck();
});

// Manual trigger for live status check
app.post('/api/admin/trigger-live-check', async (req, res) => {
  if (primaryQuotaExceeded) {
    return res.status(429).json({ error: 'quota_exceeded', message: 'Primary key quota exceeded — resets at midnight Pacific' });
  }
  const channels = getLiveChannels();
  const cost = channels.length * 100;
  res.json({ ok: true, message: 'Live check started for ' + channels.length + ' channels (~' + cost + ' units)' });
  scheduledLiveCheck(); // run in background, don't await
});

// Manual trigger for recent video fetch — use from admin panel after deploys
app.post('/api/admin/trigger-recent-fetch', async (req, res) => {
  if (primaryQuotaExceeded && archiveQuotaExceeded) {
    return res.status(429).json({ error: 'quota_exceeded', message: 'Both API keys exhausted — resets at midnight Pacific. Try again tomorrow.' });
  }
  // Double-check by testing a single API call before committing to full fetch
  const key = getApiKey();
  if (!key || key === 'YOUR_YOUTUBE_API_KEY') {
    return res.status(500).json({ error: 'No API key configured' });
  }
  logEvent({ type: 'admin', severity: 'info', source: 'admin-panel', message: 'Manual recent video fetch triggered via admin panel' });
  res.json({ ok: true, message: 'Recent video fetch started — check cache status in ~1 minute' });
  fetchAllRecentVideos(); // don't await — let it run in background
});

// Manual live override — mark a channel live when you know the video ID
// Use when a stream has been live for hours and WebSub didn't catch it

// ── Diagnostic endpoints ──────────────────────────────────────────────────────

// Server info — uptime, start time, Node version
app.get('/api/admin/server-info', (req, res) => {
  res.json({
    startTime: SERVER_START_TIME,
    uptimeMs: Date.now() - SERVER_START_TIME,
    nodeVersion: process.version,
    platform: process.platform,
    memoryMB: Math.round(process.memoryUsage().rss / 1048576),
  });
});

// Quota burn rate — units used today per key
app.get('/api/admin/quota-burn', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  res.json({
    date: burnTracker.date || today,
    primaryUnits: burnTracker.date === today ? burnTracker.primaryUnits : 0,
    archiveUnits: burnTracker.date === today ? burnTracker.archiveUnits : 0,
    primaryLimit: 10000,
    archiveLimit: process.env.YOUTUBE_API_KEY_2 ? 10000 : 0,
    liveChecksToday: getLiveChecksToday(),
    liveCheckLimit: DAILY_LIVE_CHECK_LIMIT,
  });
});

// WebSub health — per-channel subscription status and lease expiry
app.get('/api/admin/websub-health', (req, res) => {
  const channels = getAllChannels().filter(ch => ch.hasLive);
  const now = Date.now();
  const leases = channels.map(ch => {
    const lease = websubLeases[ch.id];
    const hoursUntilExpiry = lease && lease.expiresAt ? (lease.expiresAt - now) / 3600000 : null;
    return {
      id: ch.id, name: ch.name,
      status: lease ? lease.status : 'unknown',
      subscribedAt: lease ? lease.subscribedAt : null,
      expiresAt: lease ? lease.expiresAt : null,
      hoursUntilExpiry: hoursUntilExpiry !== null ? Math.round(hoursUntilExpiry * 10) / 10 : null,
      expiringSoon: hoursUntilExpiry !== null && hoursUntilExpiry < 24,
      expired: hoursUntilExpiry !== null && hoursUntilExpiry < 0,
    };
  });
  leases.sort((a, b) => (a.hoursUntilExpiry ?? 999) - (b.hoursUntilExpiry ?? 999));
  res.json({
    total: channels.length,
    active: leases.filter(l => l.status === 'active').length,
    failed: leases.filter(l => l.status === 'failed' || l.status === 'error').length,
    unknown: leases.filter(l => l.status === 'unknown').length,
    expiringSoon: leases.filter(l => l.expiringSoon && !l.expired).length,
    leases,
  });
});

// Event log (errors, quota hits, fetches, admin actions)
app.get('/api/admin/fetch-errors', (req, res) => {
  const { type, severity } = req.query;
  let entries = eventLog;
  if (type) entries = entries.filter(e => e.type === type);
  if (severity) entries = entries.filter(e => e.severity === severity);
  // Back-compat: also expose as `errors` for old callers
  res.json({ errors: entries, events: entries, total: entries.length });
});

// View recent videos cache without triggering a fetch
app.get('/api/admin/cache/recent/view', (req, res) => {
  const summary = [];
  for (const [channelId, data] of Object.entries(cache.recentVideos)) {
    if (!data || !data.items) continue;
    const ch = getAllChannels().find(c => c.id === channelId);
    summary.push({
      channelId,
      channelName: ch ? ch.name : channelId,
      group: ch ? ch.group : 'unknown',
      videoCount: data.items.length,
      cachedAt: data.cachedAt || null,
      videos: data.items.slice(0, 3).map(v => ({ id: v.id?.videoId || v.id, title: v.snippet?.title, published: v.snippet?.publishedAt })),
    });
  }
  summary.sort((a, b) => (b.cachedAt || 0) - (a.cachedAt || 0));
  res.json({ channels: summary, total: summary.length, generatedAt: Date.now() });
});

// Redis memory usage
app.get('/api/admin/redis-memory', async (req, res) => {
  if (!redis) return res.json({ available: false, message: 'Redis not configured' });
  try {
    const info = await redis.info('memory');
    const lines = info.split('\r\n');
    const get = key => { const l = lines.find(x => x.startsWith(key + ':')); return l ? l.split(':')[1].trim() : null; };
    res.json({
      available: true,
      usedMemoryHuman: get('used_memory_human'),
      usedMemoryPeakHuman: get('used_memory_peak_human'),
      usedMemoryBytes: parseInt(get('used_memory') || '0'),
      maxMemoryBytes: parseInt(get('maxmemory') || '0'),
      maxMemoryHuman: get('maxmemory_human'),
      keyCount: await redis.dbsize(),
    });
  } catch(e) { res.json({ available: false, error: e.message }); }
});

// Channel ID validator
app.post('/api/admin/validate-channel', async (req, res) => {
  const { channelId } = req.body || {};
  if (!channelId) return res.status(400).json({ error: 'channelId required' });
  const key = getApiKey();
  if (!key || key === 'YOUR_YOUTUBE_API_KEY') return res.status(500).json({ error: 'No API key configured' });
  try {
    trackBurn(true, 1);
    const url = 'https://www.googleapis.com/youtube/v3/channels?key=' + key +
      '&id=' + channelId + '&part=snippet&fields=items/snippet/title,items/snippet/thumbnails,items/snippet/customUrl';
    const data = await ytFetch(url);
    if (checkQuotaError(data)) { markQuotaExceeded(); return res.status(429).json({ error: 'quota_exceeded' }); }
    if (!data.items || data.items.length === 0) return res.json({ valid: false, error: 'Channel not found — check the channel ID' });
    const s = data.items[0].snippet;
    res.json({ valid: true, name: s.title, customUrl: s.customUrl || null,
      thumbnail: s.thumbnails ? (s.thumbnails.default || s.thumbnails.medium || {}).url : null });
  } catch(e) { res.json({ valid: false, error: e.message }); }
});

// Live stream lookup — check if a channel is currently live and optionally mark it
app.post('/api/admin/lookup-live', async (req, res) => {
  const { channelId, markLive } = req.body || {};
  if (!channelId) return res.status(400).json({ error: 'channelId required' });
  const key = getApiKey();
  if (!key || key === 'YOUR_YOUTUBE_API_KEY') return res.status(500).json({ error: 'No API key configured' });
  if (primaryQuotaExceeded) return res.status(429).json({ error: 'quota_exceeded' });
  try {
    trackBurn(true, 100);
    recordLiveCheck();
    const url = 'https://www.googleapis.com/youtube/v3/search?key=' + key +
      '&channelId=' + channelId + '&part=id,snippet&eventType=live&type=video&maxResults=1';
    const data = await ytFetch(url);
    if (checkQuotaError(data)) { markQuotaExceeded(); return res.status(429).json({ error: 'quota_exceeded' }); }
    const isLive = !!(data.items && data.items.length > 0);
    const videoId = isLive && data.items[0].id ? data.items[0].id.videoId : null;
    const title = isLive && data.items[0].snippet ? data.items[0].snippet.title : null;
    if (markLive && isLive && videoId) {
      const entry = { isLive: true, videoId, checkedAt: Date.now(), source: 'admin_lookup' };
      cache.liveStatuses[channelId] = entry;
      await rSet('wt:live:' + channelId, entry, REDIS_TTL.liveStatus);
      await updateChannelActivity(channelId, { lastLiveDate: Date.now() });
      cache.lastLiveCheck = Date.now();
      rSet('wt:lastLive', cache.lastLiveCheck);
    } else if (!isLive) {
      const entry = { isLive: false, videoId: null, checkedAt: Date.now(), source: 'admin_lookup' };
      cache.liveStatuses[channelId] = entry;
      await rSet('wt:live:' + channelId, entry, REDIS_TTL.liveStatus);
      cache.lastLiveCheck = Date.now();
      rSet('wt:lastLive', cache.lastLiveCheck);
    }
    res.json({ isLive, videoId, title, channelId, marked: !!(markLive && isLive) });
  } catch(e) { res.json({ isLive: false, error: e.message }); }
});

app.post('/api/admin/mark-live', async (req, res) => {
  const { channelId, videoId } = req.body || {};
  if (!channelId) return res.status(400).json({ error: 'channelId required' });
  const entry = { isLive: true, videoId: videoId || null, checkedAt: Date.now(), source: 'manual' };
  cache.liveStatuses[channelId] = entry;
  await rSet('wt:live:' + channelId, entry, REDIS_TTL.liveStatus);
  await updateChannelActivity(channelId, { lastLiveDate: Date.now() });
  console.log('[Admin] Manually marked live: ' + channelId + (videoId ? ' video: ' + videoId : ''));
  res.json({ ok: true, channelId, videoId, message: 'Channel marked live' });
});

// Manual clear-live — mark a channel offline
app.post('/api/admin/mark-offline', async (req, res) => {
  const { channelId } = req.body || {};
  if (!channelId) return res.status(400).json({ error: 'channelId required' });
  const entry = { isLive: false, videoId: null, checkedAt: Date.now(), source: 'manual' };
  cache.liveStatuses[channelId] = entry;
  await rSet('wt:live:' + channelId, entry, REDIS_TTL.liveStatus);
  console.log('[Admin] Manually marked offline: ' + channelId);
  res.json({ ok: true, channelId, message: 'Channel marked offline' });
});

// Channel health report — full per-channel diagnostic for admin panel
app.get('/api/admin/channel-health', (req, res) => {
  const channels = getAllChannels();
  const now = Date.now();

  const report = channels.map(ch => {
    const act = cache.channelActivity[ch.id] || {};
    const live = cache.liveStatuses[ch.id] || {};
    const recent = cache.recentVideos[ch.id] || {};
    const tier = getChannelTier(ch);
    const onSkip = tier !== 1 && act.nextFetchDue && now < act.nextFetchDue;

    return {
      id: ch.id,
      name: ch.name,
      group: ch.group || '',
      hasLive: !!ch.hasLive,
      tier,
      lastLiveDate: act.lastLiveDate || null,
      lastVideoDate: act.lastVideoDate || null,
      lastFetchDate: recent.cachedAt || null,
      lastLiveCheck: live.checkedAt || null,
      liveCheckSource: live.source || null,
      nextFetchDue: act.nextFetchDue || null,
      isCurrentlyLive: !!live.isLive,
      onLiveSkip: tier === 2 && onSkip,
      onVideoSkip: tier === 3 && onSkip,
      hasRecentCache: !!(recent.items && recent.items.length > 0),
    };
  });

  report.sort((a, b) => a.name.localeCompare(b.name));
  res.json({
    channels: report,
    generatedAt: now,
    summary: {
      total: report.length,
      tier1: report.filter(c => c.tier === 1).length,
      tier2: report.filter(c => c.tier === 2).length,
      tier3: report.filter(c => c.tier === 3).length,
      live: report.filter(c => c.isCurrentlyLive).length,
      noCache: report.filter(c => !c.hasRecentCache).length,
      liveChecksToday: getLiveChecksToday(),
      liveCheckLimit: DAILY_LIVE_CHECK_LIMIT,
      quotaExceeded: primaryQuotaExceeded || archiveQuotaExceeded,
      primaryQuotaExceeded,
      archiveQuotaExceeded,
      lastNotification: cache.lastNotificationReceived,
      lastLiveCheck: cache.lastLiveCheck,
      lastVideoFetch: cache.lastRecentFetch,
      archiveKeyConfigured: !!(process.env.YOUTUBE_API_KEY_2),
    }
  });
});
app.get('/api/admin/test-connectivity', async (req, res) => {
  const testUrl = key => 'https://www.googleapis.com/youtube/v3/channels?key=' + key +
    '&id=UCvBVK2ymNzPLRJrgip2GeQQ&part=snippet&fields=items/snippet/title';
  const primaryKey = getApiKey();
  const archiveKey = process.env.YOUTUBE_API_KEY_2;
  const testKey = async (key, label) => {
    if (!key || key === 'YOUR_YOUTUBE_API_KEY') return { ok: false, label, error: 'Not configured' };
    try {
      const data = await ytFetch(testUrl(key));
      if (checkQuotaError(data)) return { ok: false, label, error: 'Quota exceeded' };
      const title = data.items && data.items[0] && data.items[0].snippet && data.items[0].snippet.title;
      return { ok: true, label, channel: title || 'Connected' };
    } catch(e) { return { ok: false, label, error: e.message }; }
  };
  const [primary, archive] = await Promise.all([
    testKey(primaryKey, 'Primary (Live)'),
    archiveKey
      ? testKey(archiveKey, 'Archive (Videos)')
      : Promise.resolve({ ok: null, label: 'Archive (Videos)', error: 'YOUTUBE_API_KEY_2 not set — using primary key as fallback' }),
  ]);
  res.json({ primary, archive });
});

// Cache management — admin only
app.post('/api/admin/cache/clear-playlist', async (req, res) => {
  cache.playlist = {};
  const plKeys = await rKeys('wt:playlist:*');
  for (const key of plKeys) await rDel(key);
  console.log('[WeatherTV] Playlist cache cleared by admin');
  res.json({ ok: true, message: 'Playlist cache cleared — will fetch fresh on next request' });
});

app.post('/api/admin/cache/clear-recent', async (req, res) => {
  cache.recentVideos = {};
  const keys = await rKeys('wt:recent:*');
  for (const key of keys) await rDel(key);
  console.log('[WeatherTV] Recent videos cache cleared by admin');
  res.json({ ok: true, message: 'Recent videos cache cleared — will fetch fresh on next request' });
});

function getCacheStatus() {
  const playlistCached = Object.keys(cache.playlist).length;
  const recentCached = Object.keys(cache.recentVideos).length;
  const liveCached = Object.keys(cache.liveStatuses).length;

  // Derive lastFetch from most recently cached video if global timestamp is missing
  let lastFetch = cache.lastRecentFetch;
  if (!lastFetch && recentCached > 0) {
    const timestamps = Object.values(cache.recentVideos)
      .map(v => v.cachedAt).filter(Boolean);
    if (timestamps.length > 0) lastFetch = Math.max(...timestamps);
  }

  // Derive lastLiveCheck from most recently checked live status if global is missing
  let lastLiveCheck = cache.lastLiveCheck;
  if (!lastLiveCheck && liveCached > 0) {
    const timestamps = Object.values(cache.liveStatuses)
      .map(v => v.checkedAt).filter(Boolean);
    if (timestamps.length > 0) lastLiveCheck = Math.max(...timestamps);
  }

  return {
    playlist: { entries: playlistCached, ttlHours: 48 },
    recentVideos: { entries: recentCached, ttlHours: 168, lastFetch },
    liveStatuses: {
      entries: liveCached,
      lastChecked: lastLiveCheck,
      lastNotification: cache.lastNotificationReceived,
    },
    websubActive: cache.websubActive,
    quotaExceeded: primaryQuotaExceeded || archiveQuotaExceeded,
    primaryQuotaExceeded,
    archiveQuotaExceeded,
    liveChecksToday: getLiveChecksToday(),
    liveCheckLimit: DAILY_LIVE_CHECK_LIMIT,
    archiveKeyConfigured: !!(process.env.YOUTUBE_API_KEY_2),
  };
}

app.get('/api/admin/cache/status', (req, res) => {
  res.json(getCacheStatus());
});

// Public, read-only mirror of the cache status above — the main site's
// status bar (live/video update times, notification time) polls this on
// every page load. It MUST NOT be under /api/admin: that path requires
// HTTP Basic Auth, and a 401 response with WWW-Authenticate triggers the
// browser's native login prompt on first page load for ALL visitors.
// Same read-only data, no admin actions exposed.
app.get('/api/cache/status', (req, res) => {
  res.json(getCacheStatus());
});

// ── WS4KP static data — must be before catch-all ──
// WS4KP fetches these as absolute paths (/data/..., /scripts/...)
// regardless of where it's hosted, so we intercept here.
app.use('/data', express.static(path.join(__dirname, 'public', 'weatherstar', 'data')));
app.use('/scripts', express.static(path.join(__dirname, 'public', 'weatherstar', 'scripts')));

// ── WS4KP Local Radar background tiles ─────────────────────────────────────
// radar-tiles.mjs is the ONE place in WS4KP that uses an ABSOLUTE path
// (`/images/maps/radar/...`) instead of a relative one. Every other image
// reference is relative (resolves correctly to /weatherstar/images/...).
// This absolute path resolves to the site ROOT instead, hitting the
// ── Lightning Strike Relay ─────────────────────────────────────────────────────
// Maintains a single persistent WebSocket connection to lightningmaps.org
// (Blitzortung network). Clients poll /api/lightning — no Blitzortung servers
// are ever hit by browsers. Rolling 10-minute buffer, max 10,000 strikes.
// Attribution: Lightning data © Blitzortung.org and contributors (CC BY-SA 4.0)

// Blitzortung WebSocket relay — updated protocol (2024+):
//   URL:       wss://ws{N}.blitzortung.org  (port 443, standard)
//   Handshake: send {"a": 111} on open — without this, server sends nothing
//   Encoding:  LZW-compressed — must decode before JSON.parse
// Server IDs confirmed active: 1, 2, 7, 8
// Source: https://www.gkbrk.com/blitzortung + https://www.limaps.org/live-data.html
const LIGHTNING_SERVER_IDS = [1, 2, 7, 8];
const LIGHTNING_MAX_AGE_MS = 10 * 60 * 1000;
const LIGHTNING_MAX_STRIKES = 10000;

let _lightningBuffer = [];
let _lightningConnected = false;
let _lightningWS = null;

// LZW decompression — Blitzortung obfuscates their WebSocket stream with this.
// Ported from the Python decoder at https://www.gkbrk.com/blitzortung
function blitzortungDecode(raw) {
  const str = Buffer.isBuffer(raw) ? raw.toString() : String(raw);
  if (!str.length) return null;
  const d = [...str];
  const e = {};
  let c = d[0], f = c;
  const g = [c];
  const h = 256;
  let o = h;
  for (let i = 1; i < d.length; i++) {
    const code = d[i].charCodeAt(0);
    let a = code < h ? d[i] : (e[code] !== undefined ? e[code] : f + c);
    g.push(a);
    c = a[0];
    e[o++] = f + c;
    f = a;
  }
  return g.join('');
}

function startLightningRelay() {
  function connect() {
    const id = LIGHTNING_SERVER_IDS[Math.floor(Math.random() * LIGHTNING_SERVER_IDS.length)];
    const url = `wss://ws${id}.blitzortung.org/`;
    console.log(`[Lightning] Connecting to ${url}`);

    _lightningWS = new WebSocket(url, {
      headers: {
        'User-Agent': 'WeatherTV/1.0 (+https://watchweathertv.com)',
        'Origin': 'https://www.blitzortung.org',
      },
    });

    _lightningWS.on('open', () => {
      _lightningConnected = true;
      console.log('[Lightning] Connected — streaming strikes');
      // Required handshake — server sends nothing until it receives this
      _lightningWS.send(JSON.stringify({ a: 111 }));
    });

    _lightningWS.on('message', raw => {
      try {
        const decoded = blitzortungDecode(raw);
        if (!decoded) return;
        const msg = JSON.parse(decoded);
        const now = Date.now();

        if (msg.lat !== undefined && msg.lon !== undefined) {
          const lat = +msg.lat, lon = +msg.lon;
          if (!isNaN(lat) && !isNaN(lon)) {
            _lightningBuffer.push({ ts: now, lat, lon });
            const cutoff = now - LIGHTNING_MAX_AGE_MS;
            if (_lightningBuffer.length > LIGHTNING_MAX_STRIKES ||
                (_lightningBuffer[0]?.ts ?? now) < cutoff) {
              _lightningBuffer = _lightningBuffer.filter(s => s.ts > cutoff);
              if (_lightningBuffer.length > LIGHTNING_MAX_STRIKES) {
                _lightningBuffer = _lightningBuffer.slice(-LIGHTNING_MAX_STRIKES);
              }
            }
          }
        }
      } catch(e) { /* ignore malformed / non-strike messages */ }
    });

    _lightningWS.on('close', (code, reason) => {
      _lightningConnected = false;
      const delay = 5000 + Math.random() * 5000;
      console.log(`[Lightning] Disconnected (code=${code}) from ${url} — retrying in ${Math.round(delay / 1000)}s`);
      setTimeout(connect, delay);
    });

    _lightningWS.on('error', e => {
      console.warn(`[Lightning] WS error on ${url}:`, e.message, e.code || '');
    });
  }

  connect();
}

// Start relay immediately on server startup
startLightningRelay();

// GET /api/lightning — GeoJSON FeatureCollection of recent strikes
// Each feature's `age` property (ms) drives the client-side fade animation.
app.get('/api/lightning', (req, res) => {
  const now = Date.now();
  const cutoff = now - LIGHTNING_MAX_AGE_MS;
  const strikes = _lightningBuffer.filter(s => s.ts > cutoff);

  res.set('Cache-Control', 'no-store');
  res.json({
    type: 'FeatureCollection',
    connected: _lightningConnected,
    count: strikes.length,
    generatedAt: now,
    features: strikes.map(s => ({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: [s.lon, s.lat] },
      properties: { ts: s.ts, age: now - s.ts },
    })),
  });
});

// catch-all and returning index.html — hence the broken map tiles on the
// Local Radar display. Map it directly to where the files actually live.
app.use('/images/maps/radar', express.static(path.join(__dirname, 'public', 'weatherstar', 'images', 'maps', 'radar')));

// ── WeatherStar missing-image handler ─────────────────────────────────────────
// WeatherStar 3000/4000 are fully self-hosted. This used to redirect missing
// images to netbymatt.com; now a missing file is a plain 404 and gets logged
// once, so it can be added to /public/weatherstar/images instead.
const _wsMissingLogged = new Set();
app.get(['/weatherstar/images/*', '/weatherstar3000/images/*'], (req, res) => {
  if (!_wsMissingLogged.has(req.path) && _wsMissingLogged.size < 200) {
    _wsMissingLogged.add(req.path);
    console.warn('[WeatherStar] Missing image (add it to public):', req.path);
  }
  res.status(404).send('Not found');
});

// ── Serve index for all other routes ──
// Mount radar push notification routes BEFORE the catch-all —
// radar.js registers GET routes that would otherwise be swallowed by app.get('*')
radar.routes(app);

// ── Shop (Fourthwall Storefront API) ─────────────────────────────────────────
// GET /api/shop/products — the public product list for /shop.html, cached 10
// min (and at Cloudflare's edge). Checkout happens on Fourthwall, so buyers'
// names, addresses and payment details never touch WeatherTV.
// Env: FOURTHWALL_STOREFRONT_TOKEN (required), FOURTHWALL_SHOP_DOMAIN (e.g.
// weathertv.fourthwall.com — used for the checkout link), FOURTHWALL_COLLECTION
// (collection handle to show, e.g. "weathertv"; defaults to "all"). The
// Fourthwall store is the shared Altruistic Apps shop, so each app's site
// shows only its own collection.
const FW_API = 'https://storefront-api.fourthwall.com/v1';
let _shopCache = { data: null, ts: 0 };
const SHOP_TTL = 10 * 60 * 1000;
const SIZE_ORDER = ['XXS','XS','S','M','L','XL','XXL','2XL','XXXL','3XL','4XL','5XL'];

function _fwText(html, max = 400) {
  const t = String(html || '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n').replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\n{3,}/g, '\n\n').trim();
  return t.length > max ? t.slice(0, max - 1).trimEnd() + '…' : t;
}
function _fwMoney(m) { const v = m && (m.value ?? m.amount); return typeof v === 'number' ? v : (v != null ? Number(v) : null); }
function _fwProduct(p) {
  // Every product photo, including Fourthwall's model/lifestyle previews, plus
  // any extra per-variant photos (deduped). Capped so one product can't bloat the list.
  const images = [...new Set([
    ...(p.images || []).map(i => i.transformedUrl || i.url),
    ...(p.variants || []).flatMap(v => (v.images || []).map(i => i.transformedUrl || i.url)),
  ].filter(Boolean))].slice(0, 16);
  const variants = (p.variants || []).map(v => {
    const stock = v.stock || {};
    return {
      id: v.id,
      name: v.name || '',
      size: v.attributes?.size?.name || null,
      color: v.attributes?.color?.name || null,
      swatch: v.attributes?.color?.swatch || null,
      price: _fwMoney(v.unitPrice || v.price),
      currency: (v.unitPrice || v.price || {}).currency || 'USD',
      available: !(stock.type === 'LIMITED' && Number(stock.inStock ?? stock.quantity ?? 0) <= 0),
      image: (v.images || [])[0]?.url || null,
    };
  }).filter(v => v.id);
  variants.sort((a, b) => (SIZE_ORDER.indexOf((a.size || '').toUpperCase()) - SIZE_ORDER.indexOf((b.size || '').toUpperCase())));
  const prices = variants.map(v => v.price).filter(n => Number.isFinite(n));
  return {
    slug: p.slug, name: p.name || 'WeatherTV merch', description: _fwText(p.description),
    images, variants,
    minPrice: prices.length ? Math.min(...prices) : null, maxPrice: prices.length ? Math.max(...prices) : null,
    currency: variants[0]?.currency || 'USD',
  };
}
async function _fwShopDomain(token) {
  if (process.env.FOURTHWALL_SHOP_DOMAIN) return process.env.FOURTHWALL_SHOP_DOMAIN.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  try {   // fall back to the shop info endpoint if the variable isn't set
    const shop = JSON.parse(await fetchTextOverHttp(`${FW_API}/shop?storefront_token=${encodeURIComponent(token)}`));
    const d = shop.publicDomain || shop.domain || shop.primaryDomain || (shop.url || '').replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    return d || null;
  } catch (_) { return null; }
}
app.get('/api/shop/products', async (req, res) => {
  const token = process.env.FOURTHWALL_STOREFRONT_TOKEN;
  if (!token) return res.json({ enabled: false, products: [] });
  if (_shopCache.data && Date.now() - _shopCache.ts < SHOP_TTL) {
    res.set('Cache-Control', 'public, max-age=600');
    return res.json(_shopCache.data);
  }
  try {
    const products = [];
    for (let page = 0; page < 10; page++) {
      const coll = encodeURIComponent((process.env.FOURTHWALL_COLLECTION || 'all').trim().toLowerCase());
      const j = JSON.parse(await fetchTextOverHttp(`${FW_API}/collections/${coll}/products?storefront_token=${encodeURIComponent(token)}&page=${page}&size=50`));
      if (!j.results && j.code) console.warn(`[Shop] Fourthwall: collection "${decodeURIComponent(coll)}" — ${j.code} (does it exist and is it public?)`);
      (j.results || []).forEach(p => products.push(_fwProduct(p)));
      if (!j.paging || !j.paging.hasNextPage) break;
    }
    const data = { enabled: true, shopDomain: await _fwShopDomain(token), collection: process.env.FOURTHWALL_COLLECTION || 'all', products, fetchedAt: Date.now() };
    // An empty result is usually a setup issue (collection missing / not public) —
    // cache it for 1 minute only, so fixing it in Fourthwall shows up quickly.
    const ttl = products.length ? SHOP_TTL : 60 * 1000;
    _shopCache = { data, ts: Date.now() - (SHOP_TTL - ttl) };
    res.set('Cache-Control', `public, max-age=${Math.round(ttl / 1000)}`);
    res.json(data);
  } catch (e) {
    console.warn('[Shop] Fourthwall fetch failed:', e.message);
    if (_shopCache.data) return res.json({ ..._shopCache.data, stale: true });
    res.status(502).json({ enabled: true, error: 'Shop temporarily unavailable', products: [] });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── HTTP server + Lightning WebSocket proxy ────────────────────────────────
// Blitzortung's policy requires third-party apps to proxy data through their
// own server rather than having browsers connect to Blitzortung directly.
// We maintain ONE upstream Blitzortung connection and fan strike data out to
// all connected WeatherTV browsers simultaneously.
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws/lightning' });

let blitzSocket = null;
let blitzPending = false;
let blitzClients = new Set();
let blitzEndpointIdx = 0;
let blitzRetryTimer = null;

const BLITZ_ENDPOINTS = [
  'wss://ws.blitzortung.org/',
  'wss://ws1.blitzortung.org/',
  'wss://ws8.blitzortung.org/',
];

function connectBlitz() {
  if (blitzSocket || blitzPending) return;
  if (blitzClients.size === 0) return;
  blitzPending = true;
  const url = BLITZ_ENDPOINTS[blitzEndpointIdx % BLITZ_ENDPOINTS.length];
  console.log(`[Lightning] Connecting to ${url} (${blitzClients.size} clients waiting)`);
  try {
    const ws = new WebSocket(url);
    ws.on('open', () => {
      blitzPending = false;
      blitzSocket = ws;
      blitzEndpointIdx = 0;
      ws.send(JSON.stringify({ a: 111 }));
      console.log('[Lightning] Connected to Blitzortung');
    });
    ws.on('message', (data) => {
      const msg = data.toString();
      blitzClients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          try { client.send(msg); } catch(e) {}
        }
      });
    });
    ws.on('error', (err) => {
      blitzPending = false;
      blitzSocket = null;
      console.warn('[Lightning] Blitzortung error:', err.message);
      scheduleBlitzReconnect();
    });
    ws.on('close', () => {
      blitzPending = false;
      blitzSocket = null;
      if (blitzClients.size > 0) {
        console.log('[Lightning] Blitzortung disconnected — reconnecting');
        scheduleBlitzReconnect();
      }
    });
  } catch(e) {
    blitzPending = false;
    scheduleBlitzReconnect();
  }
}

function scheduleBlitzReconnect() {
  if (blitzRetryTimer) return;
  blitzEndpointIdx++;
  const delay = Math.min(30000, 3000 * Math.pow(1.5, Math.min(blitzEndpointIdx, 8)));
  blitzRetryTimer = setTimeout(() => { blitzRetryTimer = null; connectBlitz(); }, delay);
}

function disconnectBlitz() {
  if (blitzRetryTimer) { clearTimeout(blitzRetryTimer); blitzRetryTimer = null; }
  if (blitzSocket) { try { blitzSocket.close(); } catch(e) {} blitzSocket = null; }
  blitzPending = false;
}

wss.on('connection', (clientWs) => {
  blitzClients.add(clientWs);
  console.log(`[Lightning] Browser connected (${blitzClients.size} total)`);
  connectBlitz();
  clientWs.on('close', () => {
    blitzClients.delete(clientWs);
    console.log(`[Lightning] Browser disconnected (${blitzClients.size} remaining)`);
    if (blitzClients.size === 0) {
      console.log('[Lightning] No clients — closing Blitzortung connection');
      disconnectBlitz();
    }
  });
  clientWs.on('error', () => blitzClients.delete(clientWs));
});

// Listen on 0.0.0.0 so Railway can reach the server
server.listen(PORT, '0.0.0.0', async () => {
  console.log(`WeatherTV server running on port ${PORT}`);
  console.log(`App: http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin`);

  // Init radar module with Redis client once server is up
  if (redis) {
    radar.init(redis);
  } else {
    console.warn('[Radar] Redis not available — push notifications disabled');
  }
});
