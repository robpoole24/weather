// WeatherTV airports module — updated 2026-10-09 build.1791720000
// Data for the WeatherStar "Airport Conditions" and "Departures" screens.
//
// Everything is collected by the SERVER on a schedule and stored. Viewer
// requests only read what's stored — no viewer ever triggers an upstream call,
// however many people are watching.
//
//   Every 5 min   FAA airport status (one request covers every airport)
//   Every 15 min  NWS latest observation for each major airport station
//   Every 60 min  AirLabs departures for each airport on the board list
//                 (needs AIRLABS_KEY; the cycle stretches itself if a full
//                 hourly cycle would go over the monthly request cap)
//
//   GET /api/airports/conditions?lat=&lon=   3 nearest major airports (weather + FAA delay)
//   GET /api/airports/departures?lat=&lon=   stored boards for the nearest major airport(s)
//   GET /api/airports/status                 schedule, budget and last-run details
//
// "Major" = the 97 U.S. airports OurAirports classes as large with scheduled
// airline service (data/major-airports.json). Hobby fields such as
// Oshkosh/Wittman are not on the list.

const AIRPORTS = require('./data/major-airports.json');
const BY_IATA = Object.fromEntries(AIRPORTS.map((a) => [a.iata, a]));

// ── Settings (Railway env vars override) ────────────────────────────────────
const env = (k, d) => (process.env[k] != null && process.env[k] !== '' ? process.env[k] : d);
const BOARD_RADIUS_MI   = +env('AIRPORT_BOARD_RADIUS_MI', 100);   // nearest major airport must be this close for a board
const SECOND_BOARD_MI   = +env('AIRPORT_SECOND_BOARD_MI', 30);    // a 2nd board only when another one is this close (NYC, Chicago, DC…)
const MAX_BOARDS        = +env('AIRPORT_MAX_BOARDS', 2);
const WEATHER_RADIUS_MI = +env('AIRPORT_WEATHER_RADIUS_MI', 300); // farther than this isn't "nearby" weather
const BOARD_EVERY_MIN   = +env('AIRLABS_INTERVAL_MIN', 60);       // how often to pull departure boards
const AIRLABS_MONTHLY   = +env('AIRLABS_MONTHLY_CAP', 950);       // free plan is 1,000 requests/month
const AIRLABS_LIMIT     = +env('AIRLABS_PAGE_LIMIT', 50);         // free keys max 50 rows; paid keys up to 1000
// Which airports get departure boards. "ALL" = every major airport (97 per cycle).
// A short list, e.g. "MKE,ORD,MDW", keeps a small plan inside its monthly cap.
const BOARD_LIST = String(env('AIRPORT_BOARD_LIST', 'ALL')).toUpperCase() === 'ALL'
  ? AIRPORTS.map((a) => a.iata)
  : String(env('AIRPORT_BOARD_LIST', '')).toUpperCase().split(/[\s,]+/).filter((c) => BY_IATA[c]);
const WINDOW_H = 3;                       // departures shown: next 3 hours
const BOARD_MAX_AGE_H = 6;                // never show a board older than this

const UA = { 'User-Agent': 'WeatherTV/1.0 (+https://watchweathertv.com)', Accept: 'application/json' };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Airline display names (IATA code -> what travelers call it)
const AIRLINES = {
  AA: 'American', DL: 'Delta', UA: 'United', WN: 'Southwest', B6: 'JetBlue', AS: 'Alaska', NK: 'Spirit',
  F9: 'Frontier', G4: 'Allegiant', SY: 'Sun Country', HA: 'Hawaiian', MX: 'Breeze', XP: 'Avelo', '3M': 'Silver',
  AC: 'Air Canada', WS: 'WestJet', AM: 'Aeromexico', Y4: 'Volaris', VB: 'VivaAerobus', CM: 'Copa', AV: 'Avianca',
  BA: 'British', VS: 'Virgin Atl', AF: 'Air France', KL: 'KLM', LH: 'Lufthansa', LX: 'Swiss', IB: 'Iberia',
  EI: 'Aer Lingus', AY: 'Finnair', SK: 'SAS', TP: 'TAP', TK: 'Turkish', EK: 'Emirates', QR: 'Qatar', EY: 'Etihad',
  JL: 'JAL', NH: 'ANA', KE: 'Korean', OZ: 'Asiana', CX: 'Cathay', BR: 'EVA Air', CI: 'China Air', SQ: 'Singapore',
  QF: 'Qantas', NZ: 'Air NZ', LA: 'LATAM', ET: 'Ethiopian', AT: 'Royal Air Maroc', PD: 'Porter',
  '9K': 'Cape Air', ZW: 'Air Wisconsin', OO: 'SkyWest', YX: 'Republic', '9E': 'Endeavor', MQ: 'Envoy',
  OH: 'PSA', YV: 'Mesa', QX: 'Horizon', G7: 'GoJet', C5: 'CommuteAir', PT: 'Piedmont',
};
// U.S. brands travelers book under — preferred when one flight is listed under several codes
const BRANDS = ['DL', 'AA', 'UA', 'WN', 'B6', 'AS', 'NK', 'F9', 'G4', 'SY', 'HA', 'MX', 'XP'];
const REGIONALS = new Set(['OO', 'YX', '9E', 'MQ', 'OH', 'YV', 'QX', 'G7', 'C5', 'PT', 'ZW']);

// ── Geometry ────────────────────────────────────────────────────────────────
function miles(lat1, lon1, lat2, lon2) {
  const r = Math.PI / 180, R = 3958.8;
  const a = Math.sin((lat2 - lat1) * r / 2) ** 2
          + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin((lon2 - lon1) * r / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
function nearest(lat, lon, n, pool = AIRPORTS) {
  return pool.map((a) => ({ ...a, mi: miles(lat, lon, a.lat, a.lon) }))
    .sort((x, y) => x.mi - y.mi).slice(0, n);
}
// Boards: nearest major airport within BOARD_RADIUS_MI, plus others within
// SECOND_BOARD_MI. Greendale → Mitchell only (O'Hare ~70 mi); Manhattan →
// LaGuardia + Newark; downtown Chicago → Midway + O'Hare.
function boardAirports(lat, lon, pool = AIRPORTS) {
  const list = nearest(lat, lon, MAX_BOARDS + 2, pool);
  if (!list.length || list[0].mi > BOARD_RADIUS_MI) return [];
  return [list[0], ...list.slice(1).filter((a) => a.mi <= SECOND_BOARD_MI)].slice(0, MAX_BOARDS);
}

// ── FAA airport status parsing ──────────────────────────────────────────────
function toMinutes(text) {
  if (!text) return null;
  const h = /(\d+)\s*hour/i.exec(text), m = /(\d+)\s*min/i.exec(text);
  const total = (h ? +h[1] * 60 : 0) + (m ? +m[1] : 0);
  return total || null;
}
const tag = (s, t) => { const m = new RegExp(`<${t}>([\\s\\S]*?)</${t}>`, 'i').exec(s); return m ? m[1].trim() : ''; };
const blocks = (s, t) => s.match(new RegExp(`<${t}[ >][\\s\\S]*?</${t}>`, 'gi')) || [];

function parseFaa(xml) {
  const map = {};
  const put = (code, entry) => {           // keep the most serious status per airport
    const rank = { closed: 4, stop: 3, gdp: 2, delay: 1 };
    if (!map[code] || rank[entry.kind] > rank[map[code].kind]
      || (rank[entry.kind] === rank[map[code].kind] && (entry.min || 0) > (map[code].min || 0))) map[code] = entry;
  };
  blocks(xml, 'Ground_Delay').forEach((b) => {
    put(tag(b, 'ARPT'), { kind: 'gdp', min: toMinutes(tag(b, 'Avg')), reason: tag(b, 'Reason') });
  });
  blocks(xml, 'Ground_Stop_List').forEach((list) => blocks(list, 'Program').forEach((b) => {
    put(tag(b, 'ARPT'), { kind: 'stop', reason: tag(b, 'Reason') });
  }));
  blocks(xml, 'Arrival_Departure_Delay_List').forEach((list) => blocks(list, 'Delay').forEach((b) => {
    const max = Math.max(0, ...blocks(b, 'Arrival_Departure').map((ad) => toMinutes(tag(ad, 'Max')) || toMinutes(tag(ad, 'Min')) || 0));
    if (max) put(tag(b, 'ARPT'), { kind: 'delay', min: max, reason: tag(b, 'Reason') });
  }));
  // Closures: most listed ones only shut the field to private/charter planes
  // ("CLSD TO NON SKED TRANSIENT GA ACFT"). Only a full closure matters to travelers.
  blocks(xml, 'Airport_Closure_List').forEach((list) => blocks(list, 'Airport').forEach((b) => {
    const reason = tag(b, 'Reason');
    if (/NON\s*SKED|TRANSIENT|\bGA\b|WINGSPAN|\bPPR\b|\bEXC\b|EXCEPT/i.test(reason)) return;
    put(tag(b, 'ARPT'), { kind: 'closed', reason });
  }));
  return map;
}
function delayText(st) {
  if (!st) return 'None';
  if (st.kind === 'closed') return 'Closed';
  if (st.kind === 'stop') return 'Gnd Stop';
  return st.min ? `${st.min} min` : 'Delays';
}

// ── NWS observation parsing ─────────────────────────────────────────────────
// Last few reports, newest first: special/partial reports often carry a
// temperature but no sky condition, so take each from the newest that has it.
function parseObservations(features) {
  const obs = (features || []).map((f) => f.properties || {});
  const withTemp = obs.find((o) => o.temperature && o.temperature.value != null);
  const withSky = obs.find((o) => o.icon) || {};
  const c = withTemp ? withTemp.temperature.value : null;
  return {
    tempF: c == null ? null : Math.round(c * 9 / 5 + 32),
    icon: withSky.icon || null,
    text: withSky.textDescription || '',
    night: /\/night\//.test(withSky.icon || ''),
    time: withTemp ? withTemp.timestamp : null,
  };
}

// ── AirLabs board parsing ───────────────────────────────────────────────────
// One physical flight is often listed under several codes (codeshares).
// Keep one row per flight, preferring the U.S. brand a traveler booked.
function pickBoardRows(rows) {
  const groups = new Map();
  rows.forEach((f) => {
    const key = `${f.dep_time_ts || f.dep_time}|${f.arr_iata || ''}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(f);
  });
  const score = (f) => {
    const b = BRANDS.indexOf(f.airline_iata);
    return (b >= 0 ? 100 - b : 0) + (f.cs_flight_iata ? 0 : 5) - (REGIONALS.has(f.airline_iata) ? 50 : 0);
  };
  return [...groups.values()].map((g) => g.sort((a, b) => score(b) - score(a))[0]);
}
function toBoard(rows) {
  return pickBoardRows(rows).map((f) => ({
    ts: f.dep_time_ts || null,                       // scheduled, unix seconds
    est: f.dep_estimated_ts || null,
    out: f.dep_actual_ts || null,
    local: f.dep_time || '',                         // "YYYY-MM-DD HH:MM" airport local time
    airline: f.airline_iata || '',
    num: f.flight_number || (f.flight_iata || '').replace(/^[A-Z0-9]{2}/, ''),
    to: f.arr_iata || '',
    delay: +f.dep_delayed || 0,
    status: f.status || 'scheduled',
  })).filter((f) => f.ts);
}
// Rows for the next WINDOW_H hours as of NOW (not as of the fetch), so a board
// pulled an hour ago still drops flights that have since left.
function upcoming(board, nowSec = Date.now() / 1000) {
  return (board ? board.flights : [])
    .filter((f) => f.status !== 'landed' && f.status !== 'active' && !f.out)
    .filter((f) => Math.max(f.ts, f.est || 0) >= nowSec - 5 * 60 && f.ts <= nowSec + WINDOW_H * 3600)
    .sort((a, b) => a.ts - b.ts)
    .map((f) => {
      const hm = /(\d{1,2}):(\d{2})/.exec(f.local.split(' ')[1] || '');
      let time = '';
      if (hm) { const h = +hm[1]; time = `${(h % 12) || 12}:${hm[2]}${h < 12 ? 'a' : 'p'}`; }
      const late = Math.max(f.delay, f.est ? Math.round((f.est - f.ts) / 60) : 0);
      const status = f.status === 'cancelled' ? 'Cancelled' : late >= 15 ? 'Delayed' : 'On Time';
      return { time, carrier: AIRLINES[f.airline] || f.airline, code: f.airline, num: f.num, to: f.to, status, delay: late };
    });
}

// ── Service ─────────────────────────────────────────────────────────────────
module.exports = function attachAirports(app, { rGet, rSet }) {
  const store = {
    faa: { ts: 0, map: {} },
    obs: {},                 // icao -> { ts, ...observation }
    boards: {},              // iata -> { ts, flights }
  };
  const jobs = {
    faa: { lastRun: null, lastError: null },
    weather: { lastRun: null, lastError: null, ok: 0, failed: 0 },
    boards: { lastRun: null, nextRun: null, lastError: null, ok: 0, failed: 0, skipped: null, intervalMin: null },
  };

  // FAA — one request covers every airport
  async function pollFaa() {
    try {
      const r = await fetch('https://nasstatus.faa.gov/api/airport-status-information', { headers: { ...UA, Accept: 'application/xml' } });
      if (!r.ok) throw new Error(`FAA ${r.status}`);
      store.faa = { ts: Date.now(), map: parseFaa(await r.text()) };
      jobs.faa.lastError = null;
    } catch (e) {
      jobs.faa.lastError = e.message;               // keep the last good map
      console.warn('[Airports] FAA:', e.message);
    }
    jobs.faa.lastRun = new Date().toISOString();
  }

  // NWS — one station at a time, spaced out, every major airport
  async function pollWeather() {
    let ok = 0, failed = 0;
    for (const a of AIRPORTS) {
      try {
        const r = await fetch(`https://api.weather.gov/stations/${a.icao}/observations?limit=4`, { headers: { ...UA, Accept: 'application/geo+json' } });
        if (!r.ok) throw new Error(`NWS ${r.status}`);
        store.obs[a.icao] = { ts: Date.now(), ...parseObservations((await r.json()).features) };
        ok += 1;
      } catch (e) {
        failed += 1;                                 // keep the last good reading
        jobs.weather.lastError = `${a.icao}: ${e.message}`;
      }
      await sleep(400);
    }
    Object.assign(jobs.weather, { lastRun: new Date().toISOString(), ok, failed });
    if (!failed) jobs.weather.lastError = null;
    await rSet('airports:obs', store.obs, 6 * 3600);
  }

  // AirLabs — one request per board airport per cycle, counted against the cap
  const ym = () => new Date().toISOString().slice(0, 7);
  async function usedThisMonth() { return +(await rGet(`airlabs:used:${ym()}`)) || 0; }
  // A full cycle costs BOARD_LIST.length requests. If running it every
  // BOARD_EVERY_MIN would pass the monthly cap, stretch the gap between cycles.
  function cycleMinutes() {
    const perMonthAtTarget = BOARD_LIST.length * (30 * 24 * 60) / BOARD_EVERY_MIN;
    if (perMonthAtTarget <= AIRLABS_MONTHLY) return BOARD_EVERY_MIN;
    return Math.ceil((BOARD_LIST.length * 30 * 24 * 60) / AIRLABS_MONTHLY);
  }
  async function fetchBoard(iata) {
    const url = `https://airlabs.co/api/v9/schedules?dep_iata=${iata}&limit=${AIRLABS_LIMIT}`
      + '&_fields=airline_iata,flight_iata,flight_number,dep_time,dep_time_ts,dep_estimated_ts,dep_actual_ts,dep_delayed,status,arr_iata,cs_airline_iata,cs_flight_iata'
      + `&api_key=${encodeURIComponent(process.env.AIRLABS_KEY)}`;
    const r = await fetch(url, { headers: UA });
    const body = await r.json().catch(() => ({}));
    if (!r.ok || body.error) throw new Error(`AirLabs ${r.status} ${body.error ? JSON.stringify(body.error).slice(0, 160) : ''}`);
    return { ts: Date.now(), flights: toBoard(Array.isArray(body.response) ? body.response : []) };
  }
  let boardsRunning = false;
  async function pollBoards() {
    if (!process.env.AIRLABS_KEY || boardsRunning) return;
    boardsRunning = true;
    try {
      const used = await usedThisMonth();
      if (used + BOARD_LIST.length > AIRLABS_MONTHLY) {
        jobs.boards.skipped = `monthly cap reached (${used}/${AIRLABS_MONTHLY}); showing last boards`;
        console.warn('[Airports] AirLabs', jobs.boards.skipped);
        return;
      }
      jobs.boards.skipped = null;
      let ok = 0, failed = 0, spent = 0;
      for (const iata of BOARD_LIST) {
        try {
          spent += 1;
          store.boards[iata] = await fetchBoard(iata);
          await rSet(`airlabs:board:${iata}`, store.boards[iata], BOARD_MAX_AGE_H * 3600);
          ok += 1;
        } catch (e) {
          failed += 1;
          jobs.boards.lastError = `${iata}: ${e.message}`;
          if (/401|403|invalid|key|limit/i.test(e.message)) { console.warn('[Airports] AirLabs stopped:', e.message); break; }
        }
        await sleep(1200);
      }
      await rSet(`airlabs:used:${ym()}`, used + spent, 40 * 86400);
      Object.assign(jobs.boards, { lastRun: new Date().toISOString(), ok, failed });
      if (!failed) jobs.boards.lastError = null;
      await rSet('airlabs:lastCycle', Date.now(), 40 * 86400);
      console.log(`[Airports] departures: ${ok} boards, ${failed} failed, ${used + spent}/${AIRLABS_MONTHLY} requests used this month`);
    } finally {
      boardsRunning = false;
    }
  }

  // ── Scheduling ────────────────────────────────────────────────────────────
  // Restart-safe: stored boards/readings are reloaded from Redis, and the
  // departure cycle resumes on its schedule instead of re-pulling on every
  // deploy (a deploy must never spend extra AirLabs requests).
  async function start() {
    const savedObs = await rGet('airports:obs');
    if (savedObs && typeof savedObs === 'object') store.obs = savedObs;
    await Promise.all(BOARD_LIST.map(async (iata) => {
      const b = await rGet(`airlabs:board:${iata}`);
      if (b && b.ts) store.boards[iata] = b;
    }));

    pollFaa(); setInterval(pollFaa, 5 * 60 * 1000);
    pollWeather(); setInterval(pollWeather, 15 * 60 * 1000);

    if (!process.env.AIRLABS_KEY) {
      console.log('[Airports] AIRLABS_KEY not set — Departures screen stays off');
      return;
    }
    const every = cycleMinutes() * 60 * 1000;
    jobs.boards.intervalMin = cycleMinutes();
    if (jobs.boards.intervalMin !== BOARD_EVERY_MIN) {
      console.warn(`[Airports] ${BOARD_LIST.length} airports every ${BOARD_EVERY_MIN} min would pass the ${AIRLABS_MONTHLY}/month cap — running every ${jobs.boards.intervalMin} min instead`);
    }
    const last = +(await rGet('airlabs:lastCycle')) || 0;
    const wait = Math.max(0, last + every - Date.now());
    const run = () => { jobs.boards.nextRun = new Date(Date.now() + every).toISOString(); pollBoards(); };
    jobs.boards.nextRun = new Date(Date.now() + wait).toISOString();
    setTimeout(() => { run(); setInterval(run, every); }, wait);
  }
  start().catch((e) => console.error('[Airports] start failed:', e.message));

  // ── Viewer endpoints: read only ───────────────────────────────────────────
  const point = (req) => {
    const lat = parseFloat(req.query.lat), lon = parseFloat(req.query.lon ?? req.query.lng);
    return Number.isFinite(lat) && Number.isFinite(lon) ? { lat, lon } : null;
  };

  app.get('/api/airports/conditions', (req, res) => {
    const p = point(req);
    if (!p) return res.status(400).json({ error: 'lat/lon required' });
    const list = nearest(p.lat, p.lon, 3).filter((a) => a.mi <= WEATHER_RADIUS_MI);
    res.set('Cache-Control', 'public, max-age=300');
    res.json({
      airports: list.map((a) => {
        const o = store.obs[a.icao];
        const fresh = o && Date.now() - o.ts < 3 * 3600 * 1000;
        const st = store.faa.map[a.iata];
        return {
          iata: a.iata, short: a.short, name: a.name, mi: Math.round(a.mi),
          tempF: fresh ? o.tempF : null, icon: fresh ? o.icon : null, night: fresh ? o.night : false, sky: fresh ? o.text : '',
          delay: delayText(st), delayKind: st ? st.kind : null,
        };
      }),
      updated: { faa: store.faa.ts || null, weather: jobs.weather.lastRun },
      source: 'NWS observations · FAA NAS Status',
    });
  });

  app.get('/api/airports/departures', (req, res) => {
    const p = point(req);
    if (!p) return res.status(400).json({ error: 'lat/lon required' });
    const pool = AIRPORTS.filter((a) => BOARD_LIST.includes(a.iata));
    const boards = boardAirports(p.lat, p.lon, pool).map((a) => {
      const b = store.boards[a.iata];
      if (!b || Date.now() - b.ts > BOARD_MAX_AGE_H * 3600 * 1000) return null;
      return { iata: a.iata, short: a.short, name: a.name, mi: Math.round(a.mi),
        updated: b.ts, delay: delayText(store.faa.map[a.iata]), flights: upcoming(b) };
    }).filter(Boolean);
    res.set('Cache-Control', 'public, max-age=300');
    res.json({ boards, windowHours: WINDOW_H, source: 'AirLabs' });
  });

  app.get('/api/airports/status', async (req, res) => {
    const used = await usedThisMonth();
    const cycle = cycleMinutes();
    res.json({
      airlabsConfigured: !!process.env.AIRLABS_KEY,
      boardAirports: BOARD_LIST.length,
      targetIntervalMin: BOARD_EVERY_MIN,
      actualIntervalMin: cycle,
      requestsPerMonthAtThisInterval: Math.round(BOARD_LIST.length * (30 * 24 * 60) / cycle),
      monthlyCap: AIRLABS_MONTHLY,
      usedThisMonth: used,
      boardsStored: Object.keys(store.boards).length,
      jobs,
    });
  });
};

module.exports._internals = { parseFaa, parseObservations, toBoard, upcoming, nearest, boardAirports, miles, delayText, toMinutes };
